import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { AnalysisReport } from "@/components/AnalysisReport";
import { SignalActions } from "@/components/SignalActions";
import { getAnalysisBySlug, incrementViews } from "@/lib/server/analyses";
import { OUTCOME_META, biasMeta, timeAgo } from "@/lib/format";
import type { AnalysisResult } from "@/lib/types";

export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  try {
    const data = await getAnalysisBySlug(slug);
    if (!data) return { title: "Signal not found" };
    const report = data.report;
    return {
      title: `${report.instrument} ${report.timeframe} — ${report.finalSignal.headline}`,
      description: report.finalSignal.sentence,
      openGraph: { title: `${report.instrument} ${report.timeframe} · FXWizzy signal`, description: report.finalSignal.sentence },
    };
  } catch {
    return { title: "FXWizzy signal" };
  }
}

export default async function AnalysisPage({ params }: PageProps) {
  const { slug } = await params;
  let data: Awaited<ReturnType<typeof getAnalysisBySlug>> = null;
  try {
    data = await getAnalysisBySlug(slug);
  } catch (error) {
    console.error("analysis page failed", error);
  }
  if (!data) notFound();
  if (data.meta.isPublic) await incrementViews(slug);

  const report: AnalysisResult = data.report;
  const bias = biasMeta(report.bias);
  const outcome = OUTCOME_META[data.meta.outcome];

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="relative overflow-hidden">
        <div className="pointer-events-none absolute -left-24 top-0 h-72 w-72 glow-magenta" aria-hidden />
        <div className="pointer-events-none absolute right-0 top-24 h-72 w-72 glow-gold" aria-hidden />
        <div className="shell relative py-8">
          <nav className="flex flex-wrap items-center gap-2 text-[0.68rem] font-semibold text-muted">
            <Link href="/" className="hover:text-gold">Home</Link>
            <span>/</span>
            <Link href="/signals" className="hover:text-gold">Signal Room</Link>
            <span>/</span>
            <span className="text-cream/70">{report.instrument} · {report.timeframe}</span>
          </nav>

          <div className="mt-3 flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className={`rounded-md border px-2 py-0.5 text-[0.65rem] font-bold ${bias.className}`}>{bias.label}</span>
                <span className={`rounded-md border px-2 py-0.5 text-[0.65rem] font-bold ${outcome.className}`}>
                  {outcome.label}
                  {data.meta.outcomeR !== null ? ` · ${data.meta.outcomeR > 0 ? "+" : ""}${data.meta.outcomeR.toFixed(2)}R` : ""}
                </span>
                {!data.meta.isPublic ? (
                  <span className="rounded-md border border-white/20 bg-white/5 px-2 py-0.5 text-[0.65rem] font-bold text-muted">
                    Unlisted link
                  </span>
                ) : null}
              </div>
              <h1 className="mt-2 font-display text-3xl font-extrabold leading-tight text-cream sm:text-4xl">
                {report.instrument} · {report.timeframe} — {report.setupModel}
              </h1>
              <p className="mt-1.5 text-sm text-muted">
                Published by <span className="font-semibold text-cream/80">{data.meta.authorName}</span> ·{" "}
                {timeAgo(data.meta.createdAt)} · {data.meta.views} analyst views
              </p>
            </div>
            <Link href="/analyzer" className="btn btn-primary text-xs">
              Analyze your chart →
            </Link>
          </div>

          <div className="mt-6">
            <AnalysisReport report={report} meta={{ ...data.meta }} />
          </div>

          <div className="mt-6">
            <SignalActions
              slug={slug}
              outcome={data.meta.outcome}
              rr1={report.levels.rr1}
              rr2={report.levels.rr2}
              rr3={report.levels.rr3}
            />
          </div>

          <div className="card mt-6 flex flex-wrap items-center justify-between gap-4 p-5">
            <div>
              <p className="font-display text-base font-bold text-cream">Want this read on your own chart?</p>
              <p className="mt-1 max-w-xl text-xs leading-relaxed text-muted">
                The analyzer is public and free. Screenshot your chart, choose the pair and risk, and get the same
                structure-first breakdown — including a WAIT verdict when there is no edge.
              </p>
            </div>
            <Link href="/analyzer" className="btn btn-primary text-xs">Open the analyzer</Link>
          </div>

          <p className="mt-4 text-[0.66rem] leading-relaxed text-muted">
            Educational analysis, not financial advice. Levels are calculated from a screenshot and may differ from your
            broker&apos;s live market. Always use a hard stop.
          </p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { CandleChart } from "@/components/CandleChart";
import { SignalCard } from "@/components/SignalCard";
import { Logo } from "@/components/Logo";
import { analyzeChart } from "@/lib/analysis";
import { getInstrument, formatPrice } from "@/lib/instruments";
import { SAMPLE_CHARTS } from "@/lib/market";
import { ensureSeeded, getSignalStats, listPublicSignals } from "@/lib/server/analyses";
import type { SignalStats, } from "@/lib/server/analyses";
import type { SignalSummary } from "@/lib/types";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "FXWizzy — Forex & Gold Chart Analyzer",
  description:
    "Screenshot any forex or gold chart and get a mentor-grade read: market structure, liquidity zones, candle behaviour, entry, stop loss and three take-profit targets.",
};

const FEATURES = [
  {
    icon: "◧",
    title: "Screenshot vision",
    body: "Upload, paste or snap a chart. The browser extracts candle geometry — highs, lows, bodies, dominance — without shipping your image anywhere.",
  },
  {
    icon: "⌁",
    title: "Market structure engine",
    body: "Swing highs and lows, break of structure, change of character, equal highs/lows and range position are all calculated from your candles.",
  },
  {
    icon: "◉",
    title: "Liquidity map",
    body: "Range edges, stop clusters and unfilled imbalances are labelled so you know where price is being drawn before you commit.",
  },
  {
    icon: "▤",
    title: "Candle behaviour read",
    body: "Engulfing, rejection wicks, inside bars, body dominance and momentum — translated into what buyers and sellers actually proved.",
  },
  {
    icon: "◎",
    title: "Multi-target trade plans",
    body: "One entry zone, one hard invalidation, TP1/TP2/TP3 with live risk-to-reward and staged management instructions.",
  },
  {
    icon: "▣",
    title: "Position sizing built in",
    body: "Set balance and risk %, get lot size, stop distance and pip value for gold, FX, indices and crypto — including the min-lot reality check.",
  },
];

const STEPS = [
  {
    title: "Drop the chart",
    body: "Take a screenshot on your phone or desktop, or pick one of six sample charts. Paste anywhere with Ctrl/⌘ + V.",
  },
  {
    title: "Give it context",
    body: "Choose XAUUSD, EURUSD, indices or crypto, the timeframe, the last visible price, your balance and risk percentage.",
  },
  {
    title: "Trade the plan, not emotion",
    body: "You get one model, one invalidation and staged targets — plus a checklist that tells you when to stand aside.",
  },
];

const PRICING = [
  {
    name: "Explorer",
    price: "Free",
    cadence: "forever",
    blurb: "Everything you need to read charts properly and start reviewing your own trades.",
    features: [
      "Unlimited screenshot analyses (fair-use rate limits)",
      "3 targets + R:R on every plan",
      "Position size calculator",
      "Publish to the public Signal Room",
      "Full mentor playbook",
    ],
    cta: "Analyze a chart",
    href: "/analyzer",
    highlight: true,
  },
  {
    name: "Pro Trader",
    price: "$29",
    cadence: "/ month",
    blurb: "For the trader who wants a repeatable review loop and a private signal history.",
    features: [
      "Everything in Explorer",
      "Private signal library with outcome tracking",
      "Priority engine queue",
      "Multi-timeframe confluence notes",
      "Trade journal exports",
    ],
    cta: "Start with the free analyzer",
    href: "/analyzer",
    highlight: false,
  },
  {
    name: "Desk",
    price: "$99",
    cadence: "/ month",
    blurb: "For prop desks and educators who need public track records their students can audit.",
    features: [
      "Everything in Pro",
      "Team handles and branded share pages",
      "Bulk chart reviews",
      "Public performance dashboard",
      "Direct mentor Q&A channel",
    ],
    cta: "Talk to the desk",
    href: "/signals",
    highlight: false,
  },
];

const FAQ = [
  {
    q: "Is FXWizzy a signal service that guarantees profit?",
    a: "No. Nothing in trading is 100% — anyone promising that is selling fantasy. FXWizzy grades conviction, maps structure and enforces risk. It also tells you to WAIT when the chart has no edge, which is where most accounts are saved.",
  },
  {
    q: "Does it really read my screenshot?",
    a: "Yes. Your browser scans the image for bullish and bearish candle pixels, clusters them into columns, reconstructs highs, lows, opens and closes, then sends only that price geometry to the analysis engine. The raw image never leaves your device.",
  },
  {
    q: "What if my chart uses white/black candles or a strange theme?",
    a: "Read quality drops. Use standard green/red or teal/red candles and crop to the candle panel. If the reader cannot isolate enough candles it will tell you, and let you run a reference-structure analysis instead — clearly labelled, never disguised as a real read.",
  },
  {
    q: "Which markets are supported?",
    a: "Gold (XAUUSD), EURUSD, GBPUSD, USDJPY, GBPJPY, AUDUSD, USDCAD, BTCUSD, US30 and NAS100 across M5 to D1. The pip size, contract value and typical range are configured per market.",
  },
  {
    q: "Do I need an account?",
    a: "No. The analyzer is public and free to use. If you publish a signal, a manage token is stored on your device so only you can mark its outcome — that is how the public track record stays honest.",
  },
  {
    q: "Is this financial advice?",
    a: "No. FXWizzy is an educational analysis tool. You are responsible for your execution, your risk and your decisions. Always use a hard stop and never risk money you cannot afford to lose.",
  },
];

function pricePreviewCandles() {
  const sample = SAMPLE_CHARTS[0];
  const spec = getInstrument(sample.instrument);
  const report = analyzeChart({
    instrument: sample.instrument,
    timeframe: sample.timeframe,
    style: "intraday",
    accountSize: 5000,
    riskPercent: 1,
    anchorPrice: Number((spec.priceRef + sample.anchorPriceOffset).toFixed(spec.digits)),
    candles: sample.candles,
    source: "sample",
    visionConfidence: 98,
  });
  return report;
}

export default async function HomePage() {
  let stats: SignalStats = {
    total: 0,
    graded: 0,
    wins: 0,
    losses: 0,
    pending: 0,
    winRate: 0,
    avgR: 0,
    totalViews: 0,
    items: [],
  };
  let signals: SignalSummary[] = [];
  try {
    await ensureSeeded();
    [stats, signals] = await Promise.all([getSignalStats(), listPublicSignals({ limit: 3 })]);
  } catch (error) {
    console.error("home data unavailable", error);
  }

  const preview = pricePreviewCandles();
  const f = (value: number) => formatPrice(value, preview.digits);

  return (
    <div className="min-h-screen">
      <SiteHeader />

      {/* HERO */}
      <main>
        <section className="relative overflow-hidden border-b border-white/8">
          <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" aria-hidden />
          <div className="pointer-events-none absolute -left-40 top-10 h-96 w-96 glow-magenta" aria-hidden />
          <div className="pointer-events-none absolute -right-24 top-32 h-96 w-96 glow-gold" aria-hidden />

          <div className="shell relative grid gap-10 py-14 lg:grid-cols-[1.02fr_0.98fr] lg:items-center lg:py-20">
            <div className="rise-in">
              <span className="pill border-gold/40 bg-gold/10 text-gold">
                <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-mint" />
                Forex · Gold · Indices · Crypto
              </span>
              <h1 className="mt-4 font-display text-[2.45rem] font-extrabold leading-[1.03] tracking-tight text-cream sm:text-6xl">
                Read the chart like
                <span className="block hot-text">smart money.</span>
              </h1>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-cream/75">
                FXWizzy is the public chart analyzer and mentor for forex and gold. Screenshot your chart and get
                structure, liquidity, candle behaviour and a complete trade plan — entry, hard stop and three targets
                with exact risk-to-reward.
              </p>

              <div className="mt-7 flex flex-wrap gap-3">
                <Link href="/analyzer" className="btn btn-primary">
                  Analyze my chart — free
                  <span aria-hidden>→</span>
                </Link>
                <Link href="/signals" className="btn btn-ghost">
                  Browse the Signal Room
                </Link>
              </div>

              <dl className="mt-8 grid max-w-lg grid-cols-3 gap-3">
                {[
                  { label: "Public signals", value: stats.total > 0 ? stats.total.toString() : "Live" },
                  { label: "Graded win rate", value: stats.graded > 0 ? `${stats.winRate}%` : "Audited" },
                  { label: "Avg R per trade", value: stats.graded > 0 ? `${stats.avgR > 0 ? "+" : ""}${stats.avgR}R` : "Tracked" },
                ].map((item) => (
                  <div key={item.label} className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5">
                    <dd className="font-display text-xl font-bold text-gold">{item.value}</dd>
                    <dt className="mt-0.5 text-[0.6rem] font-bold uppercase tracking-[0.12em] text-muted">{item.label}</dt>
                  </div>
                ))}
              </dl>

              <p className="mt-4 max-w-xl text-xs leading-relaxed text-muted/80">
                No signup. Every plan carries a hard invalidation and a WAIT verdict when the edge is not there. Trading
                is risk — FXWizzy is education, not a promise of profit.
              </p>
            </div>

            {/* LIVE PREVIEW CARD */}
            <div className="rise-in">
              <div className="card card-gold relative overflow-hidden p-4 sm:p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="pill border-mint/40 bg-mint/10 text-mint">Live engine output</p>
                    <h2 className="mt-2 font-display text-lg font-bold text-cream">
                      {preview.instrument} · {preview.timeframe} · {preview.setupModel.split("—")[0].trim()}
                    </h2>
                  </div>
                  <div className="text-right">
                    <p className={`font-display text-2xl font-extrabold ${preview.finalSignal.action === "BUY" ? "text-mint" : preview.finalSignal.action === "SELL" ? "text-rose" : "text-gold"}`}>
                      {preview.finalSignal.action}
                    </p>
                    <p className="text-[0.6rem] font-bold uppercase tracking-widest text-muted">
                      Grade {preview.grade} · {preview.confidence}%
                    </p>
                  </div>
                </div>

                <div className="mt-3 overflow-hidden rounded-xl border border-white/10">
                  <CandleChart
                    candles={preview.chart}
                    digits={preview.digits}
                    height={230}
                    compact
                    levels={[
                      { label: "ENTRY", value: preview.levels.entry, color: "#e9b949", dashed: false },
                      { label: "SL", value: preview.levels.stop, color: "#f25a73" },
                      { label: "TP2", value: preview.levels.tp2, color: "#2fd39a" },
                    ]}
                  />
                </div>

                <div className="mt-3 grid grid-cols-2 gap-1.5 font-mono text-[0.7rem] sm:grid-cols-4">
                  {[
                    { label: "Entry", value: f(preview.levels.entry), tone: "text-gold" },
                    { label: "Stop", value: f(preview.levels.stop), tone: "text-rose" },
                    { label: "TP3", value: f(preview.levels.tp3), tone: "text-mint" },
                    { label: "To TP2", value: `1:${preview.levels.rr2.toFixed(2)}`, tone: "text-cream" },
                  ].map((item) => (
                    <div key={item.label} className="rounded-lg border border-white/10 bg-ink/50 px-2 py-1.5">
                      <p className="text-[0.55rem] font-bold uppercase tracking-wider text-muted">{item.label}</p>
                      <p className={`mt-0.5 ${item.tone}`}>{item.value}</p>
                    </div>
                  ))}
                </div>

                <p className="mt-3 text-[0.7rem] leading-relaxed text-cream/70">
                  <span className="font-bold text-gold">Mentor:</span> {preview.narrative.mentor}
                </p>
                <Link href="/analyzer" className="mt-3 inline-flex text-xs font-bold text-gold hover:text-gold-soft">
                  Run this on your own chart →
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* FEATURES */}
        <section className="border-b border-white/8 py-16">
          <div className="shell">
            <div className="max-w-2xl">
              <span className="pill border-white/15">What a mentor checks</span>
              <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-cream sm:text-4xl">
                Not another indicator wall. A structure-first read.
              </h2>
              <p className="mt-3 text-sm leading-relaxed text-muted">
                FXWizzy analyses the way a discretionary trader does: context, structure, liquidity, candle behaviour,
                then risk. Six engines, one verdict.
              </p>
            </div>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((feature) => (
                <article key={feature.title} className="card p-5 transition hover:border-gold/30">
                  <span className="grid h-10 w-10 place-items-center rounded-xl border border-gold/30 bg-gold/10 font-display text-lg text-gold">
                    {feature.icon}
                  </span>
                  <h3 className="mt-3 font-display text-base font-bold text-cream">{feature.title}</h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-muted">{feature.body}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* SAMPLES */}
        <section className="border-b border-white/8 py-16">
          <div className="shell">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div className="max-w-xl">
                <span className="pill border-white/15">Practice charts</span>
                <h2 className="mt-3 font-display text-3xl font-bold text-cream">Six cases, six lessons</h2>
                <p className="mt-2 text-sm leading-relaxed text-muted">
                  Load any of these inside the analyzer to see a full breakdown. They mirror the patterns that actually
                  pay: sweeps, CHoCH, false breakouts, flags and imbalance fills.
                </p>
              </div>
              <Link href="/analyzer" className="btn btn-ghost text-xs">
                Open the analyzer
              </Link>
            </div>
            <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {SAMPLE_CHARTS.map((sample) => {
                const spec = getInstrument(sample.instrument);
                const last = sample.candles[sample.candles.length - 1].c;
                const candles = sample.candles.map((c) => ({
                  o: spec.priceRef + (c.o - last) * spec.range[sample.timeframe],
                  h: spec.priceRef + (c.h - last) * spec.range[sample.timeframe],
                  l: spec.priceRef + (c.l - last) * spec.range[sample.timeframe],
                  c: spec.priceRef + (c.c - last) * spec.range[sample.timeframe],
                }));
                return (
                  <article key={sample.id} className="card overflow-hidden p-3">
                    <CandleChart candles={candles} digits={spec.digits} height={170} showAxis={false} compact />
                    <div className="p-2">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-display text-xs font-bold text-cream">
                          {sample.instrument} · {sample.timeframe}
                        </p>
                        <span className="rounded border border-white/15 px-1.5 py-0.5 text-[0.58rem] font-bold uppercase tracking-wide text-gold">
                          {sample.difficulty}
                        </span>
                      </div>
                      <p className="mt-1 text-[0.72rem] font-semibold text-cream/80">{sample.title.split("—")[1]?.trim() ?? sample.title}</p>
                      <p className="mt-1 line-clamp-2 text-[0.68rem] leading-relaxed text-muted">{sample.lesson}</p>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section className="relative border-b border-white/8 py-16">
          <div className="pointer-events-none absolute inset-0 grid-lines opacity-20" aria-hidden />
          <div className="shell relative">
            <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
              <div>
                <span className="pill border-white/15">How it works</span>
                <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-cream sm:text-4xl">
                  Forty seconds from screenshot to trade plan.
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-muted">
                  No indicators to configure, no opinions to filter. The engine is deterministic: same chart, same
                  structure, same plan. That is what makes it a training tool, not a slot machine.
                </p>
                <div className="mt-6 space-y-4">
                  {STEPS.map((step, index) => (
                    <div key={step.title} className="flex gap-3">
                      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-gold/40 bg-gold/10 font-mono text-xs font-bold text-gold">
                        0{index + 1}
                      </span>
                      <div>
                        <p className="font-display text-sm font-bold text-cream">{step.title}</p>
                        <p className="mt-0.5 text-xs leading-relaxed text-muted">{step.body}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card p-5">
                <div className="flex items-center justify-between">
                  <p className="text-[0.65rem] font-bold uppercase tracking-[0.15em] text-muted">Sample mentor read</p>
                  <span className="pill border-rose/35 bg-rose/10 text-rose">CHoCH detected</span>
                </div>
                <div className="mt-3 space-y-3">
                  {[
                    {
                      label: "Higher-timeframe context",
                      body: "H4 is still bullish, so a short here is a lower-timeframe distribution trade — take partials, do not marry it.",
                    },
                    {
                      label: "Structure",
                      body: "Equal highs swept, bullish momentum faded, then a bearish close below the last higher low. That is a change of character, not a pullback.",
                    },
                    {
                      label: "Liquidity",
                      body: "Sell-side stops sit under the range low. That is the draw on liquidity, so TP2 belongs there — not at the middle of the range.",
                    },
                    {
                      label: "Candle behaviour",
                      body: "The reversal candle closed with a 14% body and a long upper wick. Buyers tried, sellers answered. Supply is in control.",
                    },
                  ].map((item) => (
                    <div key={item.label} className="rounded-lg border border-white/8 bg-white/[0.025] p-3">
                      <p className="text-[0.62rem] font-bold uppercase tracking-[0.12em] text-gold">{item.label}</p>
                      <p className="mt-1 text-[0.72rem] leading-relaxed text-cream/75">{item.body}</p>
                    </div>
                  ))}
                </div>
                <p className="mt-3 border-l-2 border-gold/60 pl-3 text-xs italic leading-relaxed text-cream/70">
                  “Sell the premium retest, not the break. The break is the trap.”
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* LIVE SIGNALS */}
        <section className="border-b border-white/8 py-16">
          <div className="shell">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <span className="pill border-mint/35 bg-mint/10 text-mint">
                  <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-mint" /> Public signal room
                </span>
                <h2 className="mt-3 font-display text-3xl font-bold text-cream">Every plan is public and trackable</h2>
                <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">
                  Publish your analysis and it lands here with its entry, stop and targets. Outcomes are marked by the
                  creator only, so wins and losses stay visible. {stats.graded > 0 ? `${stats.wins} wins · ${stats.losses} losses · ${stats.pending} in play.` : "Be the first to publish a graded read."}
                </p>
              </div>
              <Link href="/signals" className="btn btn-ghost text-xs">
                All signals →
              </Link>
            </div>

            {signals.length > 0 ? (
              <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {signals.map((signal) => (
                  <SignalCard key={signal.slug} signal={signal} />
                ))}
              </div>
            ) : (
              <div className="mt-6 rounded-xl border border-dashed border-white/15 p-8 text-center text-sm text-muted">
                The room is warming up. <Link href="/analyzer" className="font-bold text-gold">Publish the first signal</Link>.
              </div>
            )}
          </div>
        </section>

        {/* PRICING */}
        <section id="pricing" className="scroll-mt-24 border-b border-white/8 py-16">
          <div className="shell">
            <div className="mx-auto max-w-2xl text-center">
              <span className="pill border-white/15">Plans</span>
              <h2 className="mt-3 font-display text-3xl font-bold text-cream sm:text-4xl">Start free. Stay because it works.</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                The analyzer is public and free to use. Paid tiers add history, exports and desk tooling — never a
                different quality of analysis.
              </p>
            </div>
            <div className="mt-8 grid gap-4 lg:grid-cols-3">
              {PRICING.map((plan) => (
                <article
                  key={plan.name}
                  className={`card flex flex-col p-6 ${plan.highlight ? "card-gold border-gold/45" : ""}`}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-lg font-bold text-cream">{plan.name}</h3>
                    {plan.highlight ? <span className="pill border-gold/40 bg-gold/10 text-gold">Free forever</span> : null}
                  </div>
                  <p className="mt-3 font-display text-3xl font-extrabold text-cream">
                    {plan.price}
                    <span className="ml-1 text-xs font-semibold text-muted">{plan.cadence}</span>
                  </p>
                  <p className="mt-2 text-xs leading-relaxed text-muted">{plan.blurb}</p>
                  <ul className="mt-4 space-y-2 text-xs text-cream/75">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex gap-2">
                        <span className="text-mint">✓</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href={plan.href} className={`btn mt-5 w-full ${plan.highlight ? "btn-primary" : "btn-ghost"}`}>
                    {plan.cta}
                  </Link>
                </article>
              ))}
            </div>
            <p className="mt-4 text-center text-[0.68rem] text-muted">
              Launch pricing preview. No payment is collected on this site — the analyzer stays open to the public.
            </p>
          </div>
        </section>

        {/* FAQ */}
        <section className="border-b border-white/8 py-16">
          <div className="shell grid gap-8 lg:grid-cols-[0.8fr_1.2fr]">
            <div>
              <span className="pill border-white/15">Straight answers</span>
              <h2 className="mt-3 font-display text-3xl font-bold text-cream">Questions traders actually ask</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                If something is unclear, the playbook explains the framework behind every verdict.
              </p>
              <Link href="/playbook" className="btn btn-ghost mt-4 text-xs">
                Read the mentor playbook →
              </Link>
            </div>
            <div className="space-y-2">
              {FAQ.map((item) => (
                <details key={item.q} className="group rounded-xl border border-white/10 bg-white/[0.025] p-4">
                  <summary className="flex cursor-pointer items-center justify-between gap-3 text-sm font-bold text-cream">
                    {item.q}
                    <span className="text-gold transition group-open:rotate-45">+</span>
                  </summary>
                  <p className="mt-2 text-xs leading-relaxed text-muted">{item.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="relative overflow-hidden py-16">
          <div className="pointer-events-none absolute -left-20 bottom-0 h-72 w-72 glow-magenta" aria-hidden />
          <div className="pointer-events-none absolute right-0 top-0 h-72 w-72 glow-gold" aria-hidden />
          <div className="shell relative">
            <div className="card card-gold flex flex-col items-center gap-5 p-8 text-center sm:p-12">
              <Logo className="scale-110" />
              <h2 className="max-w-2xl font-display text-3xl font-extrabold leading-tight text-cream sm:text-4xl">
                Your next trade deserves a second pair of eyes.
              </h2>
              <p className="max-w-xl text-sm leading-relaxed text-cream/70">
                Screenshot the chart, get the structure, get the plan. Then let the checklist — not adrenaline — decide
                whether you execute.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <Link href="/analyzer" className="btn btn-primary">Analyze a chart free</Link>
                <Link href="/signals" className="btn btn-ghost">See the public track record</Link>
              </div>
              <p className="max-w-xl text-[0.68rem] leading-relaxed text-muted">
                FXWizzy is educational software. No signal is guaranteed. Trade with a stop, size responsibly.
              </p>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}

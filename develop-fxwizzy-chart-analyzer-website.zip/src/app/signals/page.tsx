import type { Metadata } from "next";
import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { SignalCard } from "@/components/SignalCard";
import { INSTRUMENT_LIST } from "@/lib/instruments";
import { ensureSeeded, getSignalStats, listPublicSignals, type SignalStats } from "@/lib/server/analyses";
import type { SignalSummary } from "@/lib/types";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Signal Room",
  description:
    "The public FXWizzy signal room: live forex and gold trade plans with entry, stop loss, three targets and auditable outcomes.",
};

export default async function SignalsPage({
  searchParams,
}: {
  searchParams: Promise<{ instrument?: string }>;
}) {
  const { instrument } = await searchParams;
  const active = instrument && INSTRUMENT_LIST.some((i) => i.code === instrument) ? instrument : undefined;

  let stats: SignalStats = {
    total: 0,
    graded: 0,
    wins: 0,
    losses: 0,
    pending: 0,
    winRate: 0,
    avgR: 0,
    totalViews: 0,
    items: [],
  };
  let signals: SignalSummary[] = [];
  try {
    await ensureSeeded();
    [stats, signals] = await Promise.all([
      getSignalStats(),
      listPublicSignals({ limit: 30, instrument: active }),
    ]);
  } catch (error) {
    console.error("signal room unavailable", error);
  }

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main>
        <section className="relative overflow-hidden border-b border-white/8">
          <div className="pointer-events-none absolute inset-0 grid-lines opacity-30" aria-hidden />
          <div className="pointer-events-none absolute -left-24 top-0 h-72 w-72 glow-magenta" aria-hidden />
          <div className="shell relative py-12">
            <span className="pill border-mint/35 bg-mint/10 text-mint">
              <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-mint" /> Public · creator-verified outcomes
            </span>
            <h1 className="mt-3 max-w-3xl font-display text-3xl font-extrabold leading-tight text-cream sm:text-5xl">
              The Signal Room. <span className="gold-text">No screenshots of hidden wins.</span>
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">
              Every plan published here carries its entry, hard stop, three targets and the exact R:R. Outcomes can only
              be marked by the device that created the signal, so the record is what it is.
            </p>

            <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { label: "Published plans", value: stats.total.toString() },
                { label: "Graded win rate", value: `${stats.winRate}%`, hint: `${stats.wins}W / ${stats.losses}L` },
                { label: "Average result", value: `${stats.avgR > 0 ? "+" : ""}${stats.avgR}R`, hint: "Per graded trade" },
                { label: "Analyst views", value: stats.totalViews.toLocaleString("en-US") },
              ].map((item) => (
                <div key={item.label} className="card p-4">
                  <p className="font-display text-2xl font-extrabold text-gold">{item.value}</p>
                  <p className="mt-0.5 text-[0.62rem] font-bold uppercase tracking-[0.12em] text-muted">{item.label}</p>
                  {item.hint ? <p className="mt-0.5 text-[0.62rem] text-muted/70">{item.hint}</p> : null}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="shell py-10">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap gap-1.5">
              <Link
                href="/signals"
                className={`rounded-lg border px-2.5 py-1.5 text-[0.7rem] font-bold transition ${
                  !active ? "border-gold/50 bg-gold/15 text-gold" : "border-white/12 bg-white/[0.03] text-cream/70 hover:text-cream"
                }`}
              >
                All markets
              </Link>
              {INSTRUMENT_LIST.map((item) => (
                <Link
                  key={item.code}
                  href={`/signals?instrument=${item.code}`}
                  className={`rounded-lg border px-2.5 py-1.5 text-[0.7rem] font-bold transition ${
                    active === item.code
                      ? "border-gold/50 bg-gold/15 text-gold"
                      : "border-white/12 bg-white/[0.03] text-cream/70 hover:text-cream"
                  }`}
                >
                  {item.code}
                </Link>
              ))}
            </div>
            <Link href="/analyzer" className="btn btn-primary text-xs">
              Publish your own analysis
            </Link>
          </div>

          {signals.length > 0 ? (
            <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {signals.map((signal) => (
                <SignalCard key={signal.slug} signal={signal} />
              ))}
            </div>
          ) : (
            <div className="mt-5 rounded-2xl border border-dashed border-white/15 p-10 text-center">
              <p className="font-display text-lg font-bold text-cream">No signals for this market yet.</p>
              <p className="mx-auto mt-1 max-w-md text-sm text-muted">
                Run the analyzer on this pair and publish the result — your plan will appear here with a verified
                creator token.
              </p>
              <Link href="/analyzer" className="btn btn-primary mt-4 text-xs">Analyze a chart</Link>
            </div>
          )}

          <div className="mt-10 grid gap-4 lg:grid-cols-3">
            {[
              {
                title: "How to read the record",
                body: "A 60% win rate with 1:2 average reward is a strong system. A 90% win rate with negative R means the losers are bigger than the winners. Judge R, not win rate.",
              },
              {
                title: "Pending means pending",
                body: "Signals stay in play until price hits a target, the stop, or the creator cancels them. Entries that were never filled are not wins.",
              },
              {
                title: "Verify before you execute",
                body: "The analyzer reads screenshots, so prices are approximations. Always confirm levels on your own platform and check the news calendar.",
              },
            ].map((item) => (
              <div key={item.title} className="card p-5">
                <p className="font-display text-sm font-bold text-gold">{item.title}</p>
                <p className="mt-1.5 text-xs leading-relaxed text-muted">{item.body}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { AnalyzerClient } from "@/components/AnalyzerClient";

export const metadata: Metadata = {
  title: "Chart Analyzer",
  description:
    "Upload, paste or snap a forex, gold or index chart screenshot and get market structure, liquidity zones, entry, stop loss and three take profits with exact risk-to-reward.",
};

export default function AnalyzerPage() {
  return (
    <div className="min-h-screen bg-ink">
      <SiteHeader />
      <main className="relative overflow-hidden">
        <div className="pointer-events-none absolute -left-32 top-0 h-72 w-72 glow-magenta" aria-hidden />
        <div className="pointer-events-none absolute right-0 top-40 h-72 w-72 glow-gold" aria-hidden />
        <div className="shell relative py-8 sm:py-10">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <span className="pill border-gold/40 bg-gold/10 text-gold">
                <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-mint" /> Engine online · free to use
              </span>
              <h1 className="mt-3 font-display text-3xl font-extrabold leading-tight text-cream sm:text-4xl">
                The chart analyzer that <span className="gold-text">thinks like a mentor</span>
              </h1>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">
                Screenshot a chart, pick your pair and risk, and get the full read: market structure, liquidity zones,
                candle behaviour, a single execution model, one invalidation and three staged targets. No signup. No
                guarantees — just structure, liquidity and risk.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 text-[0.68rem] font-semibold text-muted">
              <span className="rounded-lg border border-white/12 bg-white/[0.03] px-2.5 py-1.5">PNG · JPG · screenshot</span>
              <span className="rounded-lg border border-white/12 bg-white/[0.03] px-2.5 py-1.5">Clipboard paste</span>
              <span className="rounded-lg border border-white/12 bg-white/[0.03] px-2.5 py-1.5">Mobile camera</span>
              <span className="rounded-lg border border-white/12 bg-white/[0.03] px-2.5 py-1.5">10 instruments</span>
            </div>
          </div>

          <div className="mt-6">
            <AnalyzerClient />
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {[
              {
                title: "What the reader needs",
                body: "Crop to the candle panel if you can. Standard green/red or teal/red candles read best; heavy drawings and indicator panes reduce read quality.",
              },
              {
                title: "What the engine returns",
                body: "Bias, structure, liquidity map, entry model, entry zone, stop, TP1–TP3 with R:R, position size and a WAIT / EXECUTE verdict.",
              },
              {
                title: "What you must do",
                body: "Verify levels against your broker's live price, check the news calendar, and never take a setup that fails the checklist.",
              },
            ].map((item) => (
              <div key={item.title} className="rounded-xl border border-white/8 bg-white/[0.025] p-4">
                <p className="font-display text-xs font-bold uppercase tracking-[0.12em] text-gold">{item.title}</p>
                <p className="mt-1.5 text-xs leading-relaxed text-muted">{item.body}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

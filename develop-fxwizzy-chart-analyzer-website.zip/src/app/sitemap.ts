import type { MetadataRoute } from "next";

const base = process.env.NEXT_PUBLIC_SITE_URL ?? "https://fxwizzy.app";

export default function sitemap(): MetadataRoute.Sitemap {
  const routes = ["", "/analyzer", "/signals", "/playbook"];
  return routes.map((route) => ({
    url: `${base}${route}`,
    lastModified: new Date(),
    changeFrequency: route === "" ? "daily" : "weekly",
    priority: route === "" ? 1 : route === "/analyzer" ? 0.9 : 0.7,
  }));
}

import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "FXWizzy — Forex & Gold Chart Analyzer",
    template: "%s · FXWizzy",
  },
  description:
    "Screenshot any forex, gold or index chart and get a mentor-grade breakdown: market structure, liquidity zones, candle behavior, entry, hard stop and multi-target plans with exact risk-to-reward.",
  keywords: [
    "forex chart analyzer",
    "gold trading signals",
    "smart money concepts",
    "XAUUSD analysis",
    "AI chart analysis",
    "FXWizzy",
  ],
  openGraph: {
    title: "FXWizzy — Read the chart like smart money",
    description:
      "Upload a chart screenshot and get market structure, liquidity zones and a complete trade plan with entry, stop loss and three take profits.",
    siteName: "FXWizzy",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "FXWizzy — Forex & Gold Chart Analyzer",
    description: "Screenshot in. Mentor-grade trade plan out.",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Sora:wght@500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap"
          rel="stylesheet"
        />
        <meta name="theme-color" content="#0b040a" />
      </head>
      <body className="bg-ink text-cream antialiased">{children}</body>
    </html>
  );
}

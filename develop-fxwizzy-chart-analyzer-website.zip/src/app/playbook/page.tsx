import type { Metadata } from "next";
import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { RiskCalculator } from "@/components/RiskCalculator";

export const metadata: Metadata = {
  title: "Mentor Playbook",
  description:
    "The exact framework FXWizzy uses: market structure, liquidity, candle behaviour, entry models and risk rules for forex and gold.",
};

const FRAMEWORK = [
  {
    step: "01",
    title: "Context — higher timeframe bias",
    body: "Start on H4/D1. Where is price coming from, where is it going, and which side of the range is it in? A lower-timeframe setup against the HTF draw on liquidity is a scalp, not a swing.",
  },
  {
    step: "02",
    title: "Structure — BOS and CHoCH",
    body: "Mark the last swing high and low. Acceptance beyond one of them is a break of structure. A break against the prevailing sequence is a change of character — the earliest warning of a reversal.",
  },
  {
    step: "03",
    title: "Liquidity — where are the stops?",
    body: "Equal highs, equal lows, session extremes and round numbers hold resting orders. Price usually runs those pools before it continues. Your targets belong on the other side of the pool, not in the middle of the range.",
  },
  {
    step: "04",
    title: "Trigger — candle behaviour at the level",
    body: "A level is not an entry. You need acceptance: an engulfing close, a rejection wick followed by a close back inside, or displacement out of the zone. Without a trigger you are guessing.",
  },
  {
    step: "05",
    title: "Risk — invalidation first",
    body: "Define the price that proves the idea wrong before you define the target. If the stop is too far for your risk, the trade is too big — not the stop too tight.",
  },
];

const STRUCTURE_TERMS = [
  { term: "Break of structure (BOS)", body: "A candle closes beyond the last confirmed swing in the direction of the trend. Continuation evidence." },
  { term: "Change of character (CHoCH)", body: "A break against the current trend — the first sign the other side has taken control. Trade the retracement, not the break." },
  { term: "Premium / discount", body: "Split the last impulse in half. Above 50% is premium (sell side), below 50% is discount (buy side). Never buy the premium end." },
  { term: "Liquidity sweep", body: "A wick through a prior extreme that closes back inside the range. It is engineered stop-taking, and often the reversal fuel you want." },
  { term: "Fair value gap (FVG)", body: "The imbalance left between candle 1 and candle 3 during displacement. Price often revisits it before continuing." },
  { term: "Equal highs / lows", body: "Two or more highs (or lows) at nearly the same price. Retail sees a 'double top'; smart money sees a stop cluster." },
];

const CANDLES = [
  { name: "Bullish engulfing", read: "Sellers tried, buyers closed above the prior open. Demand accepted.", use: "Entry trigger inside a discount zone after a sweep." },
  { name: "Bearish engulfing", read: "Buyers tried, sellers closed below the prior open. Supply accepted.", use: "Entry trigger inside a premium zone or at range high." },
  { name: "Long lower wick", read: "Price was pushed down and bought back within the candle.", use: "Confirms demand only after the next candle closes above the wick midpoint." },
  { name: "Long upper wick", read: "A rally was sold back inside the range.", use: "Confirms supply, especially at equal highs." },
  { name: "Inside bar", read: "Compression inside the previous candle's range.", use: "Breakout of the mother candle with the HTF bias, not against it." },
  { name: "Doji at a level", read: "Indecision right where a decision matters.", use: "Wait. The next candle carries the information." },
];

const MODELS = [
  {
    name: "OTE retracement",
    when: "Trend is intact, BOS printed, price is pulling back.",
    entry: "Between 62% and 79% retracement of the last impulse.",
    stop: "Beyond the origin of the leg, plus spread buffer.",
    targets: "Previous high (TP1), external liquidity (TP2), 1.618 extension (TP3).",
  },
  {
    name: "Breakout retest",
    when: "Range or level breaks with displacement, then retests.",
    entry: "Retest of the broken level, not the breakout candle.",
    stop: "Back inside the old range / below the retest wick.",
    targets: "Range height projected, then next HTF liquidity.",
  },
  {
    name: "Liquidity sweep reversal",
    when: "Wick through an obvious high/low closes back inside.",
    entry: "Rejection close, or the first lower-timeframe CHoCH.",
    stop: "Beyond the sweep wick.",
    targets: "Opposite range edge, then the midpoint of the wider range.",
  },
  {
    name: "Range fade",
    when: "Clear range, no acceptance outside either edge.",
    entry: "Edge rejection with a wick or engulf, never the middle.",
    stop: "Beyond the range edge plus average wick.",
    targets: "Mid-range first, opposite edge second, then stand aside.",
  },
];

const RISK_RULES = [
  "Risk 0.5–1% of the account per idea. 2% is a hard ceiling, not a target.",
  "One entry, one stop. Averaging into a loser is how accounts die.",
  "Take 50% at TP1, stop to break-even, trail behind swing points for the rest.",
  "After a loss, no revenge entry on the same idea — wait for a fresh sweep and a new BOS.",
  "Maximum three open ideas, and never on correlated pairs in the same direction.",
  "Journal every signal: screenshot, model, R result, and the emotion that showed up.",
];

export default function PlaybookPage() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main>
        <section className="relative overflow-hidden border-b border-white/8">
          <div className="pointer-events-none absolute inset-0 grid-lines opacity-25" aria-hidden />
          <div className="pointer-events-none absolute -right-20 top-0 h-72 w-72 glow-gold" aria-hidden />
          <div className="shell relative py-12">
            <span className="pill border-gold/40 bg-gold/10 text-gold">Mentor playbook</span>
            <h1 className="mt-3 max-w-3xl font-display text-3xl font-extrabold leading-tight text-cream sm:text-5xl">
              The framework behind every <span className="gold-text">FXWizzy</span> verdict.
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">
              Structure first, liquidity second, triggers third, risk always. Learn this page and you will stop needing
              to be told what to do — which is the entire point of a mentor.
            </p>
            <div className="mt-6 flex flex-wrap gap-2 text-[0.68rem] font-semibold text-muted">
              {["Market structure", "Liquidity", "Candle behaviour", "Entry models", "Risk rules"].map((tag) => (
                <a
                  key={tag}
                  href={`#${tag.toLowerCase().replace(" ", "-")}`}
                  className="rounded-lg border border-white/12 bg-white/[0.03] px-2.5 py-1.5 hover:border-gold/40 hover:text-gold"
                >
                  {tag}
                </a>
              ))}
            </div>
          </div>
        </section>

        <section id="market-structure" className="border-b border-white/8 py-14">
          <div className="shell">
            <h2 className="font-display text-2xl font-bold text-cream sm:text-3xl">The five-check framework</h2>
            <p className="mt-2 max-w-2xl text-sm text-muted">Run this in order. If a check fails, the trade is downgraded or skipped.</p>
            <div className="mt-6 grid gap-4 lg:grid-cols-5">
              {FRAMEWORK.map((item) => (
                <article key={item.step} className="card p-4">
                  <p className="font-mono text-xs font-bold text-gold">{item.step}</p>
                  <h3 className="mt-1.5 font-display text-sm font-bold leading-snug text-cream">{item.title}</h3>
                  <p className="mt-1.5 text-[0.72rem] leading-relaxed text-muted">{item.body}</p>
                </article>
              ))}
            </div>

            <div className="mt-8 grid gap-4 md:grid-cols-2">
              {STRUCTURE_TERMS.map((item) => (
                <div key={item.term} className="rounded-xl border border-white/8 bg-white/[0.025] p-4">
                  <p className="text-xs font-bold text-gold">{item.term}</p>
                  <p className="mt-1 text-[0.74rem] leading-relaxed text-cream/75">{item.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="candle-behaviour" className="border-b border-white/8 py-14">
          <div className="shell grid gap-8 lg:grid-cols-[1fr_1.2fr] lg:items-start">
            <div>
              <h2 className="font-display text-2xl font-bold text-cream sm:text-3xl">Candle behaviour is evidence</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                A candle is not a signal on its own. It is evidence of who won the auction at that price. Read the body,
                the wicks and the close location — in context, at a level, after a sweep.
              </p>
              <div className="mt-5 rounded-xl border border-gold/25 bg-gold/[0.06] p-4">
                <p className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-gold">The mentor rule</p>
                <p className="mt-1.5 text-xs leading-relaxed text-cream/80">
                  Long wick + close back inside the range = liquidity was taken. Big body + close at the extreme = the
                  move is being accepted. Trade acceptance, avoid indecision, and never enter on the wick that has not
                  closed yet.
                </p>
              </div>
            </div>
            <div className="space-y-2">
              {CANDLES.map((item) => (
                <div key={item.name} className="rounded-xl border border-white/8 bg-white/[0.025] p-3.5">
                  <p className="text-xs font-bold text-cream">{item.name}</p>
                  <p className="mt-1 text-[0.72rem] leading-relaxed text-muted">{item.read}</p>
                  <p className="mt-1 text-[0.7rem] text-gold-soft">Use: {item.use}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="entry-models" className="border-b border-white/8 py-14">
          <div className="shell">
            <h2 className="font-display text-2xl font-bold text-cream sm:text-3xl">Four entry models worth mastering</h2>
            <p className="mt-2 max-w-2xl text-sm text-muted">
              Master one before adding the next. Every FXWizzy plan is one of these, chosen from the structure you sent.
            </p>
            <div className="mt-6 grid gap-4 md:grid-cols-2">
              {MODELS.map((model) => (
                <article key={model.name} className="card p-5">
                  <h3 className="font-display text-base font-bold text-gold">{model.name}</h3>
                  <dl className="mt-3 space-y-2 text-xs">
                    {[
                      { k: "When", v: model.when },
                      { k: "Entry", v: model.entry },
                      { k: "Invalidation", v: model.stop },
                      { k: "Targets", v: model.targets },
                    ].map((row) => (
                      <div key={row.k} className="grid grid-cols-[76px_1fr] gap-2">
                        <dt className="text-[0.6rem] font-bold uppercase tracking-wider text-muted">{row.k}</dt>
                        <dd className="leading-relaxed text-cream/80">{row.v}</dd>
                      </div>
                    ))}
                  </dl>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="risk-rules" className="border-b border-white/8 py-14">
          <div className="shell grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <h2 className="font-display text-2xl font-bold text-cream sm:text-3xl">Risk rules that keep you in the game</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                Your edge is worthless without survival. These are non-negotiable.
              </p>
              <ul className="mt-4 space-y-2.5">
                {RISK_RULES.map((rule) => (
                  <li key={rule} className="flex gap-2.5 rounded-lg border border-white/8 bg-white/[0.025] p-3 text-xs leading-relaxed text-cream/80">
                    <span className="text-mint">✓</span>
                    <span>{rule}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-5 rounded-xl border border-rose/30 bg-rose/[0.07] p-4">
                <p className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-rose">About “100% profit” signals</p>
                <p className="mt-1.5 text-xs leading-relaxed text-cream/80">
                  They do not exist. Anyone selling a guaranteed signal is monetising your hope, not the market. What a
                  professional offers is a repeatable process: defined invalidation, positive expectancy and honest
                  records. FXWizzy will always show you the losing side of the plan and the cases where you should not
                  trade.
                </p>
              </div>
            </div>
            <div>
              <RiskCalculator />
              <div className="card mt-4 p-5">
                <p className="font-display text-sm font-bold uppercase tracking-[0.12em] text-cream/90">Copy this checklist</p>
                <ul className="mt-2 space-y-1.5 text-[0.74rem] leading-relaxed text-cream/75">
                  {[
                    "HTF bias identified and aligned",
                    "Liquidity pool marked above and below",
                    "Structure break or CHoCH confirmed",
                    "Price is in discount (buy) or premium (sell)",
                    "Trigger candle closed, not forming",
                    "Stop beyond invalidation, size fits the risk",
                    "R:R to primary target at least 1:2",
                    "News window clear and session liquid",
                  ].map((item) => (
                    <li key={item} className="flex gap-2">
                      <span className="text-gold">□</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/analyzer" className="btn btn-primary mt-4 w-full text-xs">
                  Run the checklist on my chart
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="py-14">
          <div className="shell">
            <div className="card card-gold flex flex-col items-center gap-3 p-8 text-center">
              <h2 className="max-w-2xl font-display text-2xl font-extrabold text-cream sm:text-3xl">
                Reading charts is a skill. Practise it with feedback.
              </h2>
              <p className="max-w-xl text-sm text-muted">
                Load a sample chart in the analyzer, form your own bias first, then compare it with the engine&apos;s
                structure read. That loop is how traders improve.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <Link href="/analyzer" className="btn btn-primary">Open the analyzer</Link>
                <Link href="/signals" className="btn btn-ghost">Study public signals</Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}

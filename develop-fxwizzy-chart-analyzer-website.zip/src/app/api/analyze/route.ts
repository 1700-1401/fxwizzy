import { analyzeChart } from "@/lib/analysis";
import { parseAnalyzerInputs } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();
const WINDOW_MS = 10 * 60 * 1000;
const MAX_PER_WINDOW = 40;

function rateLimited(key: string): boolean {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + WINDOW_MS });
    return false;
  }
  bucket.count += 1;
  if (buckets.size > 4000) buckets.clear();
  return bucket.count > MAX_PER_WINDOW;
}

export async function POST(request: Request) {
  const ip =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "anonymous";

  if (rateLimited(ip)) {
    return Response.json(
      { error: "Too many analyses in a short window. Give it a few minutes, then try again." },
      { status: 429 },
    );
  }

  let raw: unknown;
  try {
    const text = await request.text();
    if (text.length > 600_000) {
      return Response.json({ error: "Screenshot payload is too large. Crop the chart or reduce the image size." }, { status: 413 });
    }
    raw = JSON.parse(text);
  } catch {
    return Response.json({ error: "Could not read the request payload." }, { status: 400 });
  }

  const parsed = parseAnalyzerInputs(raw);
  if (!parsed.ok) return Response.json({ error: parsed.error }, { status: 400 });

  try {
    const result = analyzeChart(parsed.value);
    return Response.json({ result });
  } catch (error) {
    console.error("analyze failed", error);
    return Response.json({ error: "The analysis engine hit an unexpected problem. Try a cleaner screenshot." }, { status: 500 });
  }
}

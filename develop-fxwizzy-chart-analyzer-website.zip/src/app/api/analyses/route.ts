import { analyzeChart } from "@/lib/analysis";
import { ensureSeeded, insertAnalysis, listPublicSignals } from "@/lib/server/analyses";
import { parseAnalyzerInputs } from "@/lib/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const instrument = url.searchParams.get("instrument") ?? undefined;
  const limit = Number(url.searchParams.get("limit") ?? 12);
  try {
    await ensureSeeded();
    const signals = await listPublicSignals({ instrument, limit: Number.isFinite(limit) ? limit : 12 });
    return Response.json({ signals });
  } catch (error) {
    console.error("signals list failed", error);
    return Response.json({ signals: [] });
  }
}

function cleanName(value: unknown): string {
  if (typeof value !== "string") return "FXWizzy trader";
  const clean = value.replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 40);
  return clean.length >= 2 ? clean : "FXWizzy trader";
}

export async function POST(request: Request) {
  let raw: unknown;
  try {
    const text = await request.text();
    if (text.length > 600_000) {
      return Response.json({ error: "Payload too large." }, { status: 413 });
    }
    raw = JSON.parse(text);
  } catch {
    return Response.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const body = (raw ?? {}) as Record<string, unknown>;
  const parsed = parseAnalyzerInputs(body.inputs);
  if (!parsed.ok) return Response.json({ error: parsed.error }, { status: 400 });

  try {
    const report = analyzeChart(parsed.value);
    const { slug, manageToken } = await insertAnalysis({
      report,
      authorName: cleanName(body.authorName),
      isPublic: body.isPublic !== false,
    });
    return Response.json({ slug, manageToken, result: { ...report, slug } });
  } catch (error) {
    console.error("publish failed", error);
    return Response.json({ error: "Could not save this signal right now. Try again in a moment." }, { status: 500 });
  }
}

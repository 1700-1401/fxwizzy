import { updateOutcome } from "@/lib/server/analyses";
import type { Outcome } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const ALLOWED: Outcome[] = ["pending", "tp1", "tp2", "tp3", "sl", "be", "cancelled"];

export async function PATCH(request: Request, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const token = typeof body.manageToken === "string" ? body.manageToken : "";
  const outcome = typeof body.outcome === "string" ? (body.outcome as Outcome) : null;
  if (!token || !outcome || !ALLOWED.includes(outcome)) {
    return Response.json({ error: "A valid outcome and manage token are required." }, { status: 400 });
  }

  const outcomeR =
    typeof body.outcomeR === "number" && Number.isFinite(body.outcomeR)
      ? Math.max(-10, Math.min(20, body.outcomeR))
      : null;

  try {
    const ok = await updateOutcome(slug, token, outcome, outcomeR);
    if (!ok) return Response.json({ error: "This link's manage token does not match." }, { status: 403 });
    return Response.json({ ok: true, outcome, outcomeR });
  } catch (error) {
    console.error("outcome update failed", error);
    return Response.json({ error: "Could not update the outcome." }, { status: 500 });
  }
}

import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export default function NotFound() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="shell flex min-h-[60vh] flex-col items-center justify-center py-16 text-center">
        <p className="pill border-gold/40 bg-gold/10 text-gold">404</p>
        <h1 className="mt-4 font-display text-3xl font-extrabold text-cream sm:text-5xl">This setup does not exist.</h1>
        <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">
          The signal link may have been mistyped, or the analysis was never published. The Signal Room always has fresh
          plans — or run your own chart through the analyzer.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link href="/analyzer" className="btn btn-primary">Analyze a chart</Link>
          <Link href="/signals" className="btn btn-ghost">Back to the Signal Room</Link>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

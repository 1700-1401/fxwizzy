"use client";

import { useMemo, useState } from "react";
import { INSTRUMENT_LIST, formatPrice, getInstrument } from "@/lib/instruments";
import type { InstrumentCode } from "@/lib/types";

export function RiskCalculator() {
  const [instrument, setInstrument] = useState<InstrumentCode>("XAUUSD");
  const [balance, setBalance] = useState("1000");
  const [risk, setRisk] = useState("1");
  const spec = getInstrument(instrument);
  const [entry, setEntry] = useState(String(spec.priceRef));
  const [stop, setStop] = useState(String(Number((spec.priceRef - 8).toFixed(spec.digits))));
  const [target, setTarget] = useState(String(Number((spec.priceRef + 20).toFixed(spec.digits))));

  const result = useMemo(() => {
    const entryN = Number(entry);
    const stopN = Number(stop);
    const targetN = Number(target);
    const balanceN = Number(balance);
    const riskN = Number(risk);
    if (![entryN, stopN, targetN, balanceN, riskN].every(Number.isFinite)) return null;
    const distance = Math.abs(entryN - stopN);
    if (distance <= 0) return { error: "Stop loss cannot equal the entry." as const };
    const riskAmount = (balanceN * riskN) / 100;
    const rawLots = riskAmount / (distance * spec.usdPerLotPerUnit);
    const lots = Math.max(Math.floor(rawLots / spec.lotStep) * spec.lotStep, 0);
    const actualRisk = lots * distance * spec.usdPerLotPerUnit;
    const reward = Math.abs(targetN - entryN);
    const rr = reward / distance;
    const profitable = (targetN - entryN) * (entryN - stopN) > 0;
    return {
      distance,
      pips: distance / spec.pip,
      riskAmount,
      rawLots,
      lots,
      actualRisk,
      rr,
      profitable,
      potential: lots * reward * spec.usdPerLotPerUnit,
      belowMin: rawLots < spec.minLot,
    };
  }, [entry, stop, target, balance, risk, spec]);

  function resetLevels(next: InstrumentCode) {
    const nextSpec = getInstrument(next);
    setInstrument(next);
    setEntry(String(nextSpec.priceRef));
    setStop(String(Number((nextSpec.priceRef - nextSpec.range.H1 * 0.2).toFixed(nextSpec.digits))));
    setTarget(String(Number((nextSpec.priceRef + nextSpec.range.H1 * 0.5).toFixed(nextSpec.digits))));
  }

  return (
    <div className="card p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="font-display text-lg font-bold text-cream">Position size calculator</h3>
          <p className="text-xs text-muted">The same math the analyzer uses. Gold, FX, indices and crypto.</p>
        </div>
        <span className="pill border-gold/40 bg-gold/10 text-gold">Risk first</span>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label htmlFor="calc-instrument" className="label">Instrument</label>
          <select
            id="calc-instrument"
            className="field mt-1"
            value={instrument}
            onChange={(event) => resetLevels(event.target.value as InstrumentCode)}
          >
            {INSTRUMENT_LIST.map((item) => (
              <option key={item.code} value={item.code}>
                {item.code} — {item.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="calc-balance" className="label">Balance (USD)</label>
          <input id="calc-balance" inputMode="decimal" className="field mt-1 font-mono" value={balance} onChange={(e) => setBalance(e.target.value)} />
        </div>
        <div>
          <label htmlFor="calc-risk" className="label">Risk %</label>
          <input id="calc-risk" inputMode="decimal" className="field mt-1 font-mono" value={risk} onChange={(e) => setRisk(e.target.value)} />
        </div>
        <div>
          <label htmlFor="calc-entry" className="label">Entry</label>
          <input id="calc-entry" inputMode="decimal" className="field mt-1 font-mono" value={entry} onChange={(e) => setEntry(e.target.value)} />
        </div>
        <div>
          <label htmlFor="calc-stop" className="label">Stop loss</label>
          <input id="calc-stop" inputMode="decimal" className="field mt-1 font-mono" value={stop} onChange={(e) => setStop(e.target.value)} />
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="calc-target" className="label">Target</label>
          <input id="calc-target" inputMode="decimal" className="field mt-1 font-mono" value={target} onChange={(e) => setTarget(e.target.value)} />
        </div>
      </div>

      <div className="mt-4 rounded-xl border border-white/10 bg-ink/50 p-4">
        {!result ? (
          <p className="text-sm text-muted">Enter numbers to see the position size.</p>
        ) : "error" in result ? (
          <p className="text-sm text-rose">{result.error}</p>
        ) : (
          <div className="space-y-2.5">
            <div className="flex items-baseline justify-between">
              <p className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-muted">Position size</p>
              <p className="font-display text-2xl font-extrabold text-gold">{result.lots.toFixed(2)} lots</p>
            </div>
            <div className="grid grid-cols-2 gap-2 font-mono text-[0.7rem]">
              {[
                { label: "Cash at risk", value: `$${result.actualRisk.toFixed(2)}`, tone: "text-rose" },
                { label: "Stop distance", value: `${result.pips.toFixed(1)} ${spec.kind === "fx" ? "pips" : "points"}`, tone: "text-cream" },
                { label: "Reward : risk", value: `1 : ${result.rr.toFixed(2)}`, tone: result.rr >= 2 ? "text-mint" : "text-gold" },
                { label: "Target profit", value: `$${result.potential.toFixed(2)}`, tone: "text-mint" },
              ].map((item) => (
                <div key={item.label} className="rounded-lg border border-white/8 bg-white/[0.025] px-2.5 py-2">
                  <p className="text-[0.55rem] font-bold uppercase tracking-wider text-muted">{item.label}</p>
                  <p className={`mt-0.5 ${item.tone}`}>{item.value}</p>
                </div>
              ))}
            </div>
            <p className="text-[0.68rem] leading-relaxed text-muted">
              Target {formatPrice(Number(target), spec.digits)} is {result.profitable ? "in the profit direction" : "on the wrong side of the entry"}.
              {result.belowMin
                ? ` The mathematically correct size (${result.rawLots.toFixed(3)} lots) is below the broker minimum — the trade is too large for this account, so skip it or increase balance, not risk.`
                : ` Formula: (${formatPrice(Number(balance), 2)} × ${risk}%) ÷ (${result.distance.toFixed(spec.digits)} × ${spec.usdPerLotPerUnit.toLocaleString("en-US")}).`}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

import { formatPrice } from "@/lib/instruments";
import type { NormalizedCandle } from "@/lib/types";

export type ChartLevel = { label: string; value: number; color: string; dashed?: boolean };
export type ChartZone = { low: number; high: number; color: string; label?: string };

type Props = {
  candles: NormalizedCandle[];
  digits: number;
  levels?: ChartLevel[];
  zones?: ChartZone[];
  height?: number;
  showAxis?: boolean;
  className?: string;
  compact?: boolean;
};

const PAD = { top: 16, right: 78, bottom: 22, left: 8 };

export function CandleChart({
  candles,
  digits,
  levels = [],
  zones = [],
  height = 330,
  showAxis = true,
  className = "",
  compact = false,
}: Props) {
  const width = 760;
  const plotW = width - PAD.left - (showAxis ? PAD.right : 14);
  const plotH = height - PAD.top - PAD.bottom;

  if (!candles.length) {
    return (
      <div
        className={`grid place-items-center rounded-xl border border-dashed border-white/15 bg-ink/50 text-xs text-muted ${className}`}
        style={{ height }}
      >
        Chart preview appears here
      </div>
    );
  }

  const levelValues = levels.map((l) => l.value);
  const high = Math.max(...candles.map((c) => c.h), ...levelValues);
  const low = Math.min(...candles.map((c) => c.l), ...levelValues);
  const span = Math.max(high - low, Math.abs(high) * 0.0004, 1e-7);
  const pad = span * 0.09;
  const maxV = high + pad;
  const minV = low - pad;
  const y = (value: number) => PAD.top + ((maxV - value) / (maxV - minV)) * plotH;
  const step = plotW / candles.length;
  const bodyW = Math.max(1.4, Math.min(step * 0.62, 11));

  const gridValues = Array.from({ length: 5 }, (_, i) => minV + ((maxV - minV) / 4) * i);

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className={`w-full ${className}`}
      style={{ height: "auto" }}
      role="img"
      aria-label="Candlestick chart with trade levels"
    >
      <defs>
        <linearGradient id="chartBg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1a0714" />
          <stop offset="100%" stopColor="#100510" />
        </linearGradient>
      </defs>
      <rect x="0" y="0" width={width} height={height} rx="14" fill="url(#chartBg)" />
      <rect x="0.5" y="0.5" width={width - 1} height={height - 1} rx="14" fill="none" stroke="rgba(255,255,255,0.08)" />

      {gridValues.map((value, index) => (
        <g key={`grid-${index}`}>
          <line
            x1={PAD.left}
            x2={PAD.left + plotW}
            y1={y(value)}
            y2={y(value)}
            stroke="rgba(255,255,255,0.07)"
            strokeDasharray="3 5"
          />
          {showAxis ? (
            <text
              x={width - PAD.right + 8}
              y={y(value) + 3.5}
              fill="rgba(195,162,181,0.75)"
              fontSize="9.5"
              fontFamily="JetBrains Mono, monospace"
            >
              {formatPrice(value, digits)}
            </text>
          ) : null}
        </g>
      ))}

      {zones.map((zone, index) => {
        const top = y(Math.max(zone.low, zone.high));
        const bottom = y(Math.min(zone.low, zone.high));
        const rectHeight = Math.max(1.5, bottom - top);
        return (
          <g key={`zone-${index}`}>
            <rect
              x={PAD.left}
              y={top}
              width={plotW}
              height={rectHeight}
              fill={zone.color}
              opacity="0.12"
            />
            <line x1={PAD.left} x2={PAD.left + plotW} y1={top} y2={top} stroke={zone.color} strokeOpacity="0.4" strokeDasharray="2 4" />
            <line x1={PAD.left} x2={PAD.left + plotW} y1={top + rectHeight} y2={top + rectHeight} stroke={zone.color} strokeOpacity="0.4" strokeDasharray="2 4" />
            {zone.label && !compact ? (
              <text x={PAD.left + 6} y={top + 10} fill={zone.color} fontSize="8.5" fontWeight="700" opacity="0.85">
                {zone.label.toUpperCase()}
              </text>
            ) : null}
          </g>
        );
      })}

      {candles.map((candle, index) => {
        const cx = PAD.left + step * (index + 0.5);
        const bull = candle.c >= candle.o;
        const color = bull ? "#2fd39a" : "#f25a73";
        const bodyTop = y(Math.max(candle.o, candle.c));
        const bodyBottom = y(Math.min(candle.o, candle.c));
        return (
          <g key={`candle-${index}`}>
            <line x1={cx} x2={cx} y1={y(candle.h)} y2={y(candle.l)} stroke={color} strokeWidth="1" opacity="0.85" />
            <rect
              x={cx - bodyW / 2}
              y={bodyTop}
              width={bodyW}
              height={Math.max(1.2, bodyBottom - bodyTop)}
              fill={color}
              opacity={bull ? 0.95 : 0.9}
              rx="0.6"
            />
          </g>
        );
      })}

      {levels.map((level) => {
        const ly = y(level.value);
        return (
          <g key={`level-${level.label}`}>
            <line
              x1={PAD.left}
              x2={PAD.left + plotW}
              y1={ly}
              y2={ly}
              stroke={level.color}
              strokeWidth={compact ? 1 : 1.4}
              strokeDasharray={level.dashed === false ? undefined : "6 4"}
              opacity="0.95"
            />
            {showAxis ? (
              <g>
                <rect x={PAD.left + plotW + 2} y={ly - 7} width={PAD.right - 6} height={14} rx="3.5" fill={level.color} opacity="0.94" />
                <text
                  x={PAD.left + plotW + 6}
                  y={ly + 3.2}
                  fontSize="8.6"
                  fontWeight="700"
                  fill="#12040d"
                  fontFamily="JetBrains Mono, monospace"
                >
                  {level.label} {formatPrice(level.value, digits)}
                </text>
              </g>
            ) : null}
          </g>
        );
      })}

      {!compact ? (
        <text x={PAD.left + 4} y={height - 6} fontSize="8.5" fill="rgba(195,162,181,0.6)">
          FXWizzy chart engine · levels are calculated, not drawn by hand
        </text>
      ) : null}
    </svg>
  );
}

import type { CSSProperties } from "react";

type LogoProps = {
  className?: string;
  compact?: boolean;
  showTagline?: boolean;
};

export function Logo({ className = "", compact = false, showTagline = true }: LogoProps) {
  const style: CSSProperties = { lineHeight: 0 };
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`} style={style}>
      <svg
        viewBox="0 0 300 86"
        role="img"
        aria-label="FXWizzy"
        className={compact ? "h-9 w-auto" : "h-11 w-auto sm:h-12"}
      >
        <defs>
          <linearGradient id="fxPink" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ff7ab8" />
            <stop offset="55%" stopColor="#ec1a83" />
            <stop offset="100%" stopColor="#b00c5f" />
          </linearGradient>
          <linearGradient id="fxGold" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ffeab3" />
            <stop offset="48%" stopColor="#ebbb52" />
            <stop offset="100%" stopColor="#bd8620" />
          </linearGradient>
          <linearGradient id="fxIvory" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#f4e3ea" />
          </linearGradient>
          <linearGradient id="fxGreen" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#5ae39d" />
            <stop offset="55%" stopColor="#17a95f" />
            <stop offset="100%" stopColor="#0a7a43" />
          </linearGradient>
        </defs>

        {/* candlestick motif */}
        <g>
          <line x1="196" y1="10" x2="196" y2="40" stroke="#f3e6d2" strokeWidth="1.4" />
          <rect x="192.5" y="18" width="7" height="14" rx="1" fill="#f8f1e6" />
          <line x1="212" y1="14" x2="212" y2="42" stroke="#ff5a5a" strokeWidth="1.4" />
          <rect x="208.5" y="22" width="7" height="12" rx="1" fill="#f23b3b" />
          <line x1="228" y1="6" x2="228" y2="38" stroke="#f3e6d2" strokeWidth="1.4" />
          <rect x="224.5" y="12" width="7" height="18" rx="1" fill="#fbf6ee" />
          <line x1="244" y1="12" x2="244" y2="38" stroke="#ff5a5a" strokeWidth="1.4" />
          <rect x="240.5" y="18" width="7" height="12" rx="1" fill="#f23b3b" />
          <line x1="260" y1="4" x2="260" y2="34" stroke="#f3e6d2" strokeWidth="1.4" />
          <rect x="256.5" y="10" width="7" height="16" rx="1" fill="#fbf6ee" />
          <line x1="276" y1="8" x2="276" y2="32" stroke="#f3e6d2" strokeWidth="1.4" />
          <rect x="272.5" y="14" width="7" height="12" rx="1" fill="#fbf6ee" />
          <line x1="288" y1="2" x2="288" y2="30" stroke="#ff5a5a" strokeWidth="1.4" />
          <rect x="284.5" y="7" width="7" height="15" rx="1" fill="#f23b3b" />
        </g>

        <text
          x="4"
          y="68"
          fontFamily="Sora, Manrope, ui-sans-serif, system-ui, sans-serif"
          fontSize="57"
          fontWeight="800"
          fontStyle="italic"
          letterSpacing="-2.6"
          stroke="#e9b949"
          strokeWidth="0.6"
          strokeOpacity="0.35"
          paintOrder="stroke"
        >
          <tspan fill="url(#fxPink)">fx</tspan>
          <tspan fill="url(#fxGold)">w</tspan>
          <tspan fill="url(#fxIvory)">i</tspan>
          <tspan fill="url(#fxIvory)">z</tspan>
          <tspan fill="url(#fxGreen)">z</tspan>
          <tspan fill="url(#fxGreen)">y</tspan>
        </text>
        <rect x="6" y="76" width="282" height="1.8" rx="0.9" fill="url(#fxGold)" opacity="0.9" />
      </svg>
      {showTagline && !compact ? (
        <span className="hidden text-[0.62rem] font-semibold uppercase leading-tight tracking-[0.28em] text-muted sm:block">
          Chart
          <br />
          Intelligence
        </span>
      ) : null}
    </span>
  );
}

export function LogoMark({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} role="img" aria-label="FXWizzy mark">
      <defs>
        <linearGradient id="markGold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ffeab3" />
          <stop offset="60%" stopColor="#e9b949" />
          <stop offset="100%" stopColor="#b00c5f" />
        </linearGradient>
      </defs>
      <rect width="48" height="48" rx="13" fill="#1d0a19" />
      <rect x="0.75" y="0.75" width="46.5" height="46.5" rx="12.4" fill="none" stroke="url(#markGold)" strokeOpacity="0.55" />
      <rect x="12" y="24" width="5" height="12" rx="1.2" fill="url(#markGold)" />
      <rect x="21.5" y="18" width="5" height="18" rx="1.2" fill="#fdf4f8" />
      <rect x="31" y="12" width="5" height="24" rx="1.2" fill="#17a95f" />
      <path d="M12 20l7-5 7 3 8-8" stroke="#ec1a83" strokeWidth="2" fill="none" strokeLinecap="round" />
    </svg>
  );
}

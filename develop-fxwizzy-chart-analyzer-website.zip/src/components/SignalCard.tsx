import Link from "next/link";
import { formatPrice, getInstrument } from "@/lib/instruments";
import { OUTCOME_META, biasMeta, gradeMeta, timeAgo } from "@/lib/format";
import type { SignalSummary } from "@/lib/types";

export function SignalCard({ signal }: { signal: SignalSummary }) {
  const digits = getInstrument(signal.instrument).digits;
  const f = (v: number) => formatPrice(v, digits);
  const outcome = OUTCOME_META[signal.outcome];
  const bias = biasMeta(signal.bias);

  return (
    <article className="card group flex flex-col gap-4 p-5 transition hover:border-gold/35">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-display text-lg font-bold text-cream">{signal.instrument}</h3>
            <span className="rounded-md border border-white/15 px-1.5 py-0.5 text-[0.65rem] font-bold text-cream/70">
              {signal.timeframe}
            </span>
            <span className={`rounded-md border px-1.5 py-0.5 text-[0.65rem] font-bold ${bias.className}`}>{bias.label}</span>
          </div>
          <p className="mt-1 text-xs text-muted">
            {signal.authorName} · {timeAgo(signal.createdAt)} · {signal.views} views
          </p>
        </div>
        <div className="flex flex-col items-end gap-1.5">
          <span className={`rounded-md border px-2 py-0.5 text-[0.65rem] font-extrabold ${gradeMeta(signal.grade)}`}>
            {signal.grade}
          </span>
          <span className="font-mono text-[0.68rem] text-muted">{signal.confidence}%</span>
        </div>
      </div>

      <p className="line-clamp-2 text-sm leading-relaxed text-cream/80">{signal.headline}</p>

      <div className="grid grid-cols-4 gap-1.5 text-center font-mono text-[0.68rem]">
        <div className="rounded-lg border border-gold/25 bg-gold/10 px-1 py-1.5">
          <p className="text-[0.55rem] font-bold uppercase tracking-wider text-gold/80">Entry</p>
          <p className="mt-0.5 text-cream">{f(signal.entry)}</p>
        </div>
        <div className="rounded-lg border border-rose/25 bg-rose/10 px-1 py-1.5">
          <p className="text-[0.55rem] font-bold uppercase tracking-wider text-rose/80">Stop</p>
          <p className="mt-0.5 text-cream">{f(signal.stop)}</p>
        </div>
        <div className="rounded-lg border border-mint/25 bg-mint/10 px-1 py-1.5">
          <p className="text-[0.55rem] font-bold uppercase tracking-wider text-mint/80">TP2</p>
          <p className="mt-0.5 text-cream">{f(signal.tp2)}</p>
        </div>
        <div className="rounded-lg border border-white/15 bg-white/5 px-1 py-1.5">
          <p className="text-[0.55rem] font-bold uppercase tracking-wider text-muted">R:R</p>
          <p className="mt-0.5 text-cream">1:{signal.rr.toFixed(1)}</p>
        </div>
      </div>

      <div className="mt-auto flex items-center justify-between gap-2 border-t border-white/8 pt-3">
        <span className={`rounded-md border px-2 py-0.5 text-[0.65rem] font-bold ${outcome.className}`}>
          {outcome.label}
          {signal.outcomeR !== null && signal.outcome !== "pending"
            ? ` · ${signal.outcomeR > 0 ? "+" : ""}${signal.outcomeR.toFixed(2)}R`
            : ""}
        </span>
        <Link href={`/analysis/${signal.slug}`} className="text-xs font-bold text-gold transition group-hover:text-gold-soft">
          Full breakdown →
        </Link>
      </div>
    </article>
  );
}

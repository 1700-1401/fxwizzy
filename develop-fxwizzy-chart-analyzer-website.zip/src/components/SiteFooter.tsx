import Link from "next/link";
import { Logo } from "./Logo";

export function SiteFooter() {
  return (
    <footer className="border-t border-white/10 bg-plum/60">
      <div className="shell py-14">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted">
              The mentor-grade chart reader for forex, gold, indices and crypto. Screenshot in, structure,
              liquidity and a risk-defined trade plan out.
            </p>
          </div>
          <div>
            <p className="label text-gold">Product</p>
            <ul className="mt-3 space-y-2 text-sm text-cream/75">
              <li><Link href="/analyzer" className="hover:text-gold">Chart Analyzer</Link></li>
              <li><Link href="/signals" className="hover:text-gold">Signal Room</Link></li>
              <li><Link href="/playbook" className="hover:text-gold">Mentor Playbook</Link></li>
              <li><Link href="/#pricing" className="hover:text-gold">Plans</Link></li>
            </ul>
          </div>
          <div>
            <p className="label text-gold">Markets</p>
            <ul className="mt-3 space-y-2 text-sm text-cream/75">
              <li>XAUUSD · Gold</li>
              <li>EURUSD · GBPUSD</li>
              <li>USDJPY · GBPJPY</li>
              <li>BTCUSD · US30 · NAS100</li>
            </ul>
          </div>
          <div>
            <p className="label text-gold">Why FXWizzy</p>
            <ul className="mt-3 space-y-2 text-sm text-cream/75">
              <li>Private screenshot reading</li>
              <li>Structure-first, not indicator noise</li>
              <li>Hard stops and staged targets</li>
              <li>Public, auditable signal room</li>
            </ul>
          </div>
        </div>

        <div className="hairline my-8" />

        <div className="space-y-3 text-xs leading-relaxed text-muted/85">
          <p>
            <strong className="text-cream/90">Risk disclaimer:</strong> FXWizzy is an educational analysis
            tool. Nothing on this site is financial advice, and no setup is ever guaranteed. Trading forex,
            gold and derivatives carries a high risk of loss. Never risk money you cannot afford to lose,
            always use a hard stop, and remember that leveraged products can lose more than your deposit.
          </p>
          <p>
            Screenshots are processed inside your browser for candle extraction; only the extracted price
            geometry is sent to our analysis engine. Public signals you choose to publish are visible to
            everyone.
          </p>
          <p className="flex flex-wrap items-center justify-between gap-2 pt-2 text-muted/70">
            <span>© {new Date().getFullYear()} FXWizzy. Built for traders who respect risk.</span>
            <span className="font-mono text-[0.68rem] uppercase tracking-[0.2em]">Structure · Liquidity · Risk</span>
          </p>
        </div>
      </div>
    </footer>
  );
}

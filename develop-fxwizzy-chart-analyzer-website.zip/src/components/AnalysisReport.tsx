import type { ReactNode } from "react";
import { CandleChart, type ChartLevel, type ChartZone } from "./CandleChart";
import { formatPrice } from "@/lib/instruments";
import { OUTCOME_META, biasMeta, gradeMeta } from "@/lib/format";
import type { AnalysisResult, Outcome } from "@/lib/types";

export type ReportMeta = {
  authorName?: string;
  createdAt?: string;
  outcome?: Outcome;
  outcomeR?: number | null;
  views?: number;
};

function ConfidenceRing({ value }: { value: number }) {
  const radius = 34;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - Math.max(0, Math.min(100, value)) / 100);
  return (
    <div className="relative grid h-24 w-24 shrink-0 place-items-center">
      <svg viewBox="0 0 80 80" className="h-24 w-24 -rotate-90">
        <circle cx="40" cy="40" r={radius} fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="6" />
        <circle
          cx="40"
          cy="40"
          r={radius}
          fill="none"
          stroke="url(#confidenceGold)"
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
        />
        <defs>
          <linearGradient id="confidenceGold" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#f6d98a" />
            <stop offset="60%" stopColor="#e9b949" />
            <stop offset="100%" stopColor="#e0167f" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute text-center">
        <p className="font-mono text-xl font-bold text-cream">{value}%</p>
        <p className="text-[0.55rem] font-bold uppercase tracking-[0.16em] text-muted">conviction</p>
      </div>
    </div>
  );
}

function Row({ label, value, hint, accent }: { label: string; value: string; hint?: string; accent?: string }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-white/8 py-2.5 last:border-0">
      <div>
        <p className="text-xs font-bold uppercase tracking-wider text-muted">{label}</p>
        {hint ? <p className="mt-0.5 text-[0.68rem] text-muted/70">{hint}</p> : null}
      </div>
      <p className={`text-right font-mono text-sm font-semibold ${accent ?? "text-cream"}`}>{value}</p>
    </div>
  );
}

function SectionTitle({ index, children }: { index: string; children: ReactNode }) {
  return (
    <div className="mb-3 flex items-center gap-2">
      <span className="grid h-6 w-6 place-items-center rounded-md border border-gold/40 bg-gold/10 font-mono text-[0.65rem] font-bold text-gold">
        {index}
      </span>
      <h3 className="font-display text-sm font-bold uppercase tracking-[0.12em] text-cream/90">{children}</h3>
    </div>
  );
}

export function AnalysisReport({
  report,
  meta,
  footer,
  actions,
}: {
  report: AnalysisResult;
  meta?: ReportMeta;
  footer?: ReactNode;
  actions?: ReactNode;
}) {
  const digits = report.digits;
  const f = (v: number) => formatPrice(v, digits);
  const unit = report.instrument.includes("JPY") || report.instrument === "XAUUSD" ? "pips" : report.pip >= 1 ? "points" : "pips";
  const bias = biasMeta(report.bias);
  const verdict = report.finalSignal.verdict;
  const actionTone =
    report.finalSignal.action === "BUY"
      ? "from-mint/25 to-mint/5 border-mint/45 text-mint"
      : report.finalSignal.action === "SELL"
        ? "from-rose/25 to-rose/5 border-rose/45 text-rose"
        : "from-gold/20 to-gold/5 border-gold/40 text-gold-soft";

  const chartLevels: ChartLevel[] = [
    { label: "ENTRY", value: report.levels.entry, color: "#e9b949", dashed: false },
    { label: "SL", value: report.levels.stop, color: "#f25a73" },
    { label: "TP1", value: report.levels.tp1, color: "#2fd39a" },
    { label: "TP2", value: report.levels.tp2, color: "#2fd39a" },
    { label: "TP3", value: report.levels.tp3, color: "#2fd39a" },
  ];
  const zoneColors: Record<string, string> = {
    resistance: "#f25a73",
    support: "#2fd39a",
    "liquidity-buy": "#e9b949",
    "liquidity-sell": "#e9b949",
    fvg: "#8b7bff",
  };
  const chartZones: ChartZone[] = report.zones
    .filter((zone) => zoneColors[zone.kind])
    .map((zone) => ({
      low: zone.low,
      high: zone.high,
      color: zoneColors[zone.kind],
      label: zone.kind === "resistance" ? "Resistance" : zone.kind === "support" ? "Support" : zone.kind === "fvg" ? "FVG" : "Liquidity",
    }));

  const outcomeMeta = meta?.outcome ? OUTCOME_META[meta.outcome] : null;

  return (
    <div className="space-y-5">
      {/* FINAL SIGNAL */}
      <section className="card card-gold relative overflow-hidden">
        <div className="pointer-events-none absolute -right-20 -top-24 h-64 w-64 glow-gold" aria-hidden />
        <div className="relative flex flex-wrap items-center justify-between gap-2 border-b border-white/10 px-5 py-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="pill border-gold/45 bg-gold/10 text-gold">Final signal</span>
            <span className={`rounded-md border px-2 py-0.5 text-[0.65rem] font-extrabold ${gradeMeta(report.grade)}`}>
              Grade {report.grade}
            </span>
            <span className={`rounded-md border px-2 py-0.5 text-[0.65rem] font-bold ${bias.className}`}>{bias.label}</span>
            <span className={`rounded-md border px-2 py-0.5 text-[0.65rem] font-bold ${verdict === "execute" ? "border-mint/40 bg-mint/10 text-mint" : "border-gold/40 bg-gold/10 text-gold-soft"}`}>
              {verdict === "execute" ? "Execute the plan" : verdict === "wait" ? "Wait for trigger" : "Stand aside"}
            </span>
            {outcomeMeta ? (
              <span className={`rounded-md border px-2 py-0.5 text-[0.65rem] font-bold ${outcomeMeta.className}`}>
                {outcomeMeta.label}
                {meta?.outcomeR != null ? ` · ${meta.outcomeR > 0 ? "+" : ""}${meta.outcomeR.toFixed(2)}R` : ""}
              </span>
            ) : null}
          </div>
          <p className="font-mono text-[0.65rem] uppercase tracking-widest text-muted">
            {report.instrument} · {report.timeframe} · {report.style}
          </p>
        </div>

        <div className="relative grid gap-5 px-5 py-5 lg:grid-cols-[auto_1fr_auto]">
          <div className={`grid content-center gap-1 rounded-xl border bg-gradient-to-br px-5 py-4 text-center ${actionTone}`}>
            <p className="font-display text-3xl font-extrabold tracking-tight">{report.finalSignal.action}</p>
            <p className="text-[0.62rem] font-bold uppercase tracking-[0.18em] opacity-80">{report.instrument}</p>
            <p className="text-[0.62rem] font-semibold opacity-70">{report.finalSignal.orderType}</p>
          </div>

          <div className="min-w-0">
            <h2 className="font-display text-xl font-bold leading-snug text-cream sm:text-2xl">{report.finalSignal.headline}</h2>
            <p className="mt-2 text-sm leading-relaxed text-cream/80">{report.finalSignal.sentence}</p>
            <p className="mt-3 rounded-lg border border-gold/20 bg-gold/5 px-3 py-2 text-xs leading-relaxed text-gold-soft">
              <strong className="font-bold">Trigger:</strong> {report.trigger}
            </p>
            <div className="mt-3 grid grid-cols-2 gap-1.5 font-mono text-[0.7rem] sm:grid-cols-4">
              <div className="rounded-lg border border-gold/25 bg-gold/10 px-2 py-1.5">
                <p className="text-[0.55rem] font-bold uppercase tracking-wider text-gold/80">Entry</p>
                <p className="mt-0.5 text-cream">{f(report.levels.entry)}</p>
              </div>
              <div className="rounded-lg border border-rose/25 bg-rose/10 px-2 py-1.5">
                <p className="text-[0.55rem] font-bold uppercase tracking-wider text-rose/80">Stop</p>
                <p className="mt-0.5 text-cream">{f(report.levels.stop)}</p>
              </div>
              <div className="rounded-lg border border-mint/25 bg-mint/10 px-2 py-1.5">
                <p className="text-[0.55rem] font-bold uppercase tracking-wider text-mint/80">TP2</p>
                <p className="mt-0.5 text-cream">{f(report.levels.tp2)}</p>
              </div>
              <div className="rounded-lg border border-white/15 bg-white/5 px-2 py-1.5">
                <p className="text-[0.55rem] font-bold uppercase tracking-wider text-muted">To TP2</p>
                <p className="mt-0.5 text-cream">1:{report.levels.rr2.toFixed(2)}</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center justify-center gap-2">
            <ConfidenceRing value={report.confidence} />
            <p className="text-center text-[0.62rem] leading-tight text-muted">
              {report.vision.candlesRead} candles read
              <br />
              {report.vision.source === "image" ? "from your screenshot" : "from a validated sample"}
            </p>
          </div>
        </div>

        <div className="relative border-t border-white/10 px-5 py-4">
          <p className="text-[0.65rem] font-bold uppercase tracking-[0.16em] text-muted">Only execute when all of this is true</p>
          <ul className="mt-2 grid gap-1.5 sm:grid-cols-2">
            {report.finalSignal.conditions.map((condition, index) => (
              <li key={index} className="flex gap-2 text-xs leading-relaxed text-cream/75">
                <span className="mt-0.5 text-gold">✓</span>
                <span>{condition}</span>
              </li>
            ))}
          </ul>
          {actions ? <div className="mt-4 flex flex-wrap gap-2">{actions}</div> : null}
        </div>
      </section>

      {/* CHART */}
      <section className="card p-4 sm:p-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-[0.12em] text-cream/90">Mapped chart</h3>
            <p className="text-xs text-muted">
              Levels are calculated from the extracted structure · {report.meta.volatilityLabel}
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5 font-mono text-[0.6rem]">
            <span className="rounded border border-gold/40 bg-gold/10 px-1.5 py-0.5 text-gold">Entry</span>
            <span className="rounded border border-rose/40 bg-rose/10 px-1.5 py-0.5 text-rose">Stop</span>
            <span className="rounded border border-mint/40 bg-mint/10 px-1.5 py-0.5 text-mint">Targets</span>
            <span className="rounded border border-[#8b7bff]/40 bg-[#8b7bff]/10 px-1.5 py-0.5 text-[#b8adff]">FVG</span>
          </div>
        </div>
        <CandleChart candles={report.chart} digits={digits} levels={chartLevels} zones={chartZones} height={350} />
      </section>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* PLAN */}
        <section className="card p-5">
          <SectionTitle index="01">The trade plan</SectionTitle>
          <Row label="Setup model" value={report.setupModel} />
          <Row
            label="Entry"
            hint={`Zone ${f(report.levels.entryZoneLow)} – ${f(report.levels.entryZoneHigh)}`}
            value={f(report.levels.entry)}
            accent="text-gold"
          />
          <Row label="Stop loss" hint={`${report.risk.stopPips} ${unit} invalidation`} value={f(report.levels.stop)} accent="text-rose" />
          <Row label="Take profit 1" hint={`1:${report.levels.rr1.toFixed(2)} · close 50%`} value={f(report.levels.tp1)} accent="text-mint" />
          <Row label="Take profit 2" hint={`1:${report.levels.rr2.toFixed(2)} · primary target`} value={f(report.levels.tp2)} accent="text-mint" />
          <Row label="Take profit 3" hint={`1:${report.levels.rr3.toFixed(2)} · runner`} value={f(report.levels.tp3)} accent="text-mint" />
          <Row label="Order type" value={report.orderType} />
        </section>

        {/* RISK */}
        <section className="card p-5">
          <SectionTitle index="02">Risk &amp; position size</SectionTitle>
          <Row label="Account balance" value={`$${report.risk.accountSize.toLocaleString("en-US", { maximumFractionDigits: 2 })}`} />
          <Row label="Risk per trade" hint="Professional range is 0.5–1%" value={`${report.risk.riskPercent.toFixed(2)}%`} />
          <Row label="Cash at risk" value={`$${report.risk.riskAmount.toFixed(2)}`} accent="text-rose" />
          <Row label="Position size" hint={`${report.risk.units.toLocaleString("en-US")} units`} value={`${report.risk.lots.toFixed(2)} lots`} accent="text-gold" />
          <Row label="Pip value / lot" value={`$${report.risk.pipValuePerLot.toFixed(2)}`} />
          <Row label="Stop distance" value={`${report.risk.stopPips} ${unit}`} />
          <div className="mt-3 rounded-lg border border-white/10 bg-ink/50 p-3 text-[0.7rem] leading-relaxed text-muted">
            Size = (balance × risk%) ÷ (stop distance × ${report.risk.usdPerLotPerUnit.toLocaleString("en-US")} per lot). Always
            round down — never up. If the broker's minimum lot is larger than this, the trade is too big for the account.
          </div>
        </section>
      </div>

      {/* MENTOR READ */}
      <section className="card p-5">
        <SectionTitle index="03">Mentor read</SectionTitle>
        <div className="grid gap-4 sm:grid-cols-2">
          {[
            { title: "Higher-timeframe context", body: report.narrative.htf },
            { title: "Market structure", body: report.narrative.structure },
            { title: "Liquidity map", body: report.narrative.liquidity },
            { title: "Candle behaviour", body: report.narrative.candleRead },
          ].map((block) => (
            <div key={block.title} className="rounded-xl border border-white/8 bg-white/[0.025] p-3.5">
              <p className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-gold">{block.title}</p>
              <p className="mt-1.5 text-xs leading-relaxed text-cream/75">{block.body}</p>
            </div>
          ))}
        </div>

        <blockquote className="mt-4 border-l-2 border-gold/60 bg-gold/[0.06] px-4 py-3 text-sm italic leading-relaxed text-cream/85">
          “{report.narrative.mentor}”
        </blockquote>

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <p className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-muted">Execution &amp; management</p>
            <p className="mt-1 text-xs leading-relaxed text-cream/75">{report.narrative.management}</p>
          </div>
          <div>
            <p className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-muted">Invalidation</p>
            <p className="mt-1 text-xs leading-relaxed text-cream/75">{report.narrative.invalidation}</p>
          </div>
        </div>
      </section>

      {/* STRUCTURE + ZONES */}
      <div className="grid gap-5 lg:grid-cols-2">
        <section className="card p-5">
          <SectionTitle index="04">Structure snapshot</SectionTitle>
          <div className="grid grid-cols-2 gap-2 font-mono text-xs">
            {[
              { label: "Range high", value: f(report.structure.rangeHigh), tone: "text-rose" },
              { label: "Range low", value: f(report.structure.rangeLow), tone: "text-mint" },
              { label: "Swing high", value: f(report.structure.swingHigh), tone: "text-cream" },
              { label: "Swing low", value: f(report.structure.swingLow), tone: "text-cream" },
              { label: "Midpoint", value: f(report.structure.midpoint), tone: "text-muted" },
              { label: "Session", value: report.session.name, tone: "text-gold" },
            ].map((item) => (
              <div key={item.label} className="rounded-lg border border-white/8 bg-white/[0.025] px-2.5 py-2">
                <p className="text-[0.55rem] font-bold uppercase tracking-wider text-muted">{item.label}</p>
                <p className={`mt-0.5 text-[0.72rem] ${item.tone}`}>{item.value}</p>
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs leading-relaxed text-cream/75">{report.structure.trendLabel}</p>
          <p className="mt-1.5 text-[0.7rem] text-muted">
            BOS up: {report.structure.bosUp ? "yes" : "no"} · BOS down: {report.structure.bosDown ? "yes" : "no"} · CHoCH:{" "}
            {report.structure.choch ? "yes" : "no"} · Equal highs: {report.structure.equalHighs ? "yes" : "no"} · Equal lows:{" "}
            {report.structure.equalLows ? "yes" : "no"} · {report.structure.htfTimeframe} bias inferred:{" "}
            {report.structure.htfBias}
          </p>
        </section>

        <section className="card p-5">
          <SectionTitle index="05">Liquidity &amp; zones</SectionTitle>
          <ul className="space-y-2.5">
            {report.zones.map((zone) => (
              <li key={`${zone.kind}-${zone.label}`} className="rounded-lg border border-white/8 bg-white/[0.025] p-2.5">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs font-bold text-cream/85">{zone.label}</p>
                  <p className="shrink-0 font-mono text-[0.68rem] text-gold">
                    {f(Math.min(zone.low, zone.high))} – {f(Math.max(zone.low, zone.high))}
                  </p>
                </div>
                <p className="mt-1 text-[0.7rem] leading-relaxed text-muted">{zone.note}</p>
              </li>
            ))}
          </ul>
        </section>
      </div>

      {/* CHECKLIST + QUESTIONS */}
      <div className="grid gap-5 lg:grid-cols-2">
        <section className="card p-5">
          <SectionTitle index="06">Pre-trade checklist</SectionTitle>
          <ul className="space-y-2">
            {report.checklist.map((item) => {
              const tone =
                item.state === "pass"
                  ? "border-mint/30 bg-mint/[0.07] text-mint"
                  : item.state === "warn"
                    ? "border-gold/30 bg-gold/[0.07] text-gold-soft"
                    : "border-rose/30 bg-rose/[0.07] text-rose";
              return (
                <li key={item.label} className={`flex gap-2.5 rounded-lg border p-2.5 ${tone}`}>
                  <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full border border-current text-[0.6rem] font-bold">
                    {item.state === "pass" ? "✓" : item.state === "warn" ? "!" : "×"}
                  </span>
                  <div>
                    <p className="text-xs font-bold">{item.label}</p>
                    <p className="mt-0.5 text-[0.7rem] leading-relaxed text-cream/60">{item.note}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        <section className="card p-5">
          <SectionTitle index="07">Before I lock this in — answer these</SectionTitle>
          <ul className="space-y-2.5">
            {report.questions.map((question, index) => (
              <li key={index} className="flex gap-2 text-xs leading-relaxed text-cream/80">
                <span className="font-mono text-[0.65rem] text-gold">{String(index + 1).padStart(2, "0")}</span>
                <span>{question}</span>
              </li>
            ))}
          </ul>
          <div className="mt-4 rounded-xl border border-rose/25 bg-rose/[0.07] p-3">
            <p className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-rose">Read this before you click buy or sell</p>
            <ul className="mt-1.5 space-y-1.5">
              {report.warnings.map((warning, index) => (
                <li key={index} className="text-[0.7rem] leading-relaxed text-cream/70">
                  • {warning}
                </li>
              ))}
            </ul>
          </div>
          <p className="mt-3 text-[0.65rem] leading-relaxed text-muted">
            Analysis quality: {report.vision.confidence}% · {report.vision.candlesRead} candles · bull share{" "}
            {Math.round(report.vision.bullRatio * 100)}% · generated {new Date(report.generatedAt).toLocaleString("en-US")}.
          </p>
        </section>
      </div>

      {footer}
    </div>
  );
}

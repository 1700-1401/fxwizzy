import Link from "next/link";
import { Logo } from "./Logo";

const NAV = [
  { href: "/analyzer", label: "Analyzer" },
  { href: "/signals", label: "Signal Room" },
  { href: "/playbook", label: "Playbook" },
  { href: "/#pricing", label: "Pricing" },
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-ink/80 backdrop-blur-xl">
      <div className="shell flex h-[72px] items-center justify-between gap-4">
        <Link href="/" className="shrink-0" aria-label="FXWizzy home">
          <Logo />
        </Link>
        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-lg px-3 py-2 text-sm font-semibold text-cream/75 transition hover:bg-white/5 hover:text-cream"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Link href="/signals" className="btn btn-ghost hidden text-xs sm:inline-flex">
            Live signals
          </Link>
          <Link href="/analyzer" className="btn btn-primary text-xs sm:text-sm">
            Analyze a chart
          </Link>
          <details className="relative md:hidden">
            <summary className="grid h-10 w-10 cursor-pointer place-items-center rounded-lg border border-white/15 text-cream/80">
              <span className="sr-only">Open menu</span>
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M4 7h16M4 12h16M4 17h16" strokeLinecap="round" />
              </svg>
            </summary>
            <div className="absolute right-0 mt-2 w-52 overflow-hidden rounded-xl border border-white/10 bg-plum-2 p-1.5 shadow-2xl">
              {NAV.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="block rounded-lg px-3 py-2 text-sm font-semibold text-cream/80 hover:bg-white/5"
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </details>
        </div>
      </div>
    </header>
  );
}

"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { AnalysisReport } from "./AnalysisReport";
import { CandleChart } from "./CandleChart";
import { extractChartVision, visionFromSeries, type VisionResult } from "@/lib/vision";
import { INSTRUMENT_LIST, TIMEFRAMES, STYLE_LABELS, getInstrument } from "@/lib/instruments";
import { SAMPLE_CHARTS, type ChartSample } from "@/lib/market";
import { planToText } from "@/lib/format";
import type {
  AnalysisResult,
  AnalyzerInputs,
  InstrumentCode,
  NormalizedCandle,
  Timeframe,
  TradingStyle,
} from "@/lib/types";

const MANAGE_KEY = "fxwizzy:managed";
const NAME_KEY = "fxwizzy:trader-name";

function toPriceSpace(candles: NormalizedCandle[], anchorPrice: number, rangePrice: number): NormalizedCandle[] {
  if (!candles.length) return [];
  const last = candles[candles.length - 1].c;
  return candles.map((c) => ({
    o: anchorPrice + (c.o - last) * rangePrice,
    h: anchorPrice + (c.h - last) * rangePrice,
    l: anchorPrice + (c.l - last) * rangePrice,
    c: anchorPrice + (c.c - last) * rangePrice,
  }));
}

export function AnalyzerClient() {
  const [instrument, setInstrument] = useState<InstrumentCode>("XAUUSD");
  const [timeframe, setTimeframe] = useState<Timeframe>("H1");
  const [style, setStyle] = useState<TradingStyle>("intraday");
  const [accountSize, setAccountSize] = useState("1000");
  const [riskPercent, setRiskPercent] = useState("1");
  const [price, setPrice] = useState(() => String(getInstrument("XAUUSD").priceRef));
  const [priceTouched, setPriceTouched] = useState(false);

  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [vision, setVision] = useState<VisionResult | null>(null);
  const [sample, setSample] = useState<ChartSample | null>(null);
  const [reading, setReading] = useState(false);

  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [lastInputs, setLastInputs] = useState<AnalyzerInputs | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [author, setAuthor] = useState("");
  const [publish, setPublish] = useState(true);
  const [published, setPublished] = useState<{ slug: string; manageToken: string } | null>(null);
  const [publishing, setPublishing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [dragging, setDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const spec = useMemo(() => getInstrument(instrument), [instrument]);

  useEffect(() => {
    try {
      const storedName = window.localStorage.getItem(NAME_KEY);
      if (storedName) setAuthor(storedName);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (!priceTouched) setPrice(String(spec.priceRef));
  }, [spec, priceTouched]);

  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  const readFile = useCallback(async (incoming: File) => {
    if (!incoming.type.startsWith("image/")) {
      setError("That file is not an image. Use a PNG or JPG screenshot of the chart.");
      return;
    }
    if (incoming.size > 12 * 1024 * 1024) {
      setError("That screenshot is larger than 12MB. Crop it to the price panel and try again.");
      return;
    }
    setError(null);
    setNotice(null);
    setReading(true);
    setSample(null);
    setResult(null);
    setPublished(null);
    setFile(incoming);
    setPreviewUrl((old) => {
      if (old) URL.revokeObjectURL(old);
      return URL.createObjectURL(incoming);
    });
    try {
      const extraction = await extractChartVision(incoming);
      setVision(extraction);
      if (extraction.candles.length < 8) {
        setNotice(
          "The reader could not isolate enough candles. You can still run the analysis, but crop tighter around the candles for a real read.",
        );
      }
    } catch {
      setVision(null);
      setError("This browser could not decode that image. A PNG or JPG screenshot works best.");
    } finally {
      setReading(false);
    }
  }, []);

  const handlePaste = useCallback(
    (event: ClipboardEvent) => {
      const items = event.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i += 1) {
        if (items[i].type.startsWith("image/")) {
          const blob = items[i].getAsFile();
          if (blob) {
            event.preventDefault();
            void readFile(blob);
          }
          return;
        }
      }
    },
    [readFile],
  );

  useEffect(() => {
    document.addEventListener("paste", handlePaste);
    return () => document.removeEventListener("paste", handlePaste);
  }, [handlePaste]);

  function loadSample(item: ChartSample) {
    setFile(null);
    setPreviewUrl((old) => {
      if (old) URL.revokeObjectURL(old);
      return null;
    });
    setSample(item);
    setInstrument(item.instrument);
    const itemSpec = getInstrument(item.instrument);
    setTimeframe(item.timeframe);
    setStyle(item.timeframe === "M5" || item.timeframe === "M15" ? "scalp" : item.timeframe === "H4" || item.timeframe === "D1" ? "swing" : "intraday");
    setPrice(String(Number((itemSpec.priceRef + item.anchorPriceOffset).toFixed(itemSpec.digits))));
    setPriceTouched(true);
    setVision(visionFromSeries(item.candles, "sample"));
    setResult(null);
    setPublished(null);
    setError(null);
    setNotice(null);
  }

  function resetAll() {
    setFile(null);
    setPreviewUrl((old) => {
      if (old) URL.revokeObjectURL(old);
      return null;
    });
    setVision(null);
    setSample(null);
    setResult(null);
    setLastInputs(null);
    setPublished(null);
    setPriceTouched(false);
    setError(null);
    setNotice(null);
  }

  const anchorPrice = Number(price);
  const rangePrice = spec.range[timeframe];

  async function handleAnalyze() {
    setBusy(true);
    setError(null);
    setPublished(null);
    try {
      let activeVision = vision;
      if (file && !activeVision) {
        activeVision = await extractChartVision(file);
        setVision(activeVision);
      }
      if (!activeVision && !file) {
        throw new Error("Add a screenshot, paste one with Ctrl+V, or load a sample chart first.");
      }
      if (!Number.isFinite(anchorPrice) || anchorPrice <= 0) {
        throw new Error("Enter the last price visible on your chart so the levels land on real values.");
      }

      const inputs: AnalyzerInputs = {
        instrument,
        timeframe,
        style,
        accountSize: Number(accountSize) || 1000,
        riskPercent: Number(riskPercent) || 1,
        anchorPrice,
        candles: activeVision?.candles ?? [],
        source: activeVision ? (sample ? "sample" : "image") : "fallback",
        visionConfidence: activeVision?.confidence ?? 20,
        visionNotes: activeVision?.notes ?? ["No screenshot supplied — reference structure used."],
      };

      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(inputs),
      });
      const data = (await response.json()) as { result?: AnalysisResult; error?: string };
      if (!response.ok || !data.result) throw new Error(data.error ?? "The analysis engine could not process that chart.");
      setResult(data.result);
      setLastInputs(inputs);
      setNotice(null);
      window.setTimeout(() => {
        document.getElementById("analysis-result")?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 80);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Try again.");
    } finally {
      setBusy(false);
    }
  }

  async function handlePublish() {
    if (!lastInputs) return;
    setPublishing(true);
    setError(null);
    try {
      const cleanName = author.trim() || "Anonymous trader";
      const response = await fetch("/api/analyses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ inputs: lastInputs, authorName: cleanName, isPublic: publish }),
      });
      const data = (await response.json()) as { slug?: string; manageToken?: string; error?: string };
      if (!response.ok || !data.slug || !data.manageToken) throw new Error(data.error ?? "Could not save the signal.");
      setPublished({ slug: data.slug, manageToken: data.manageToken });
      try {
        window.localStorage.setItem(NAME_KEY, cleanName);
        const raw = window.localStorage.getItem(MANAGE_KEY);
        const map = raw ? (JSON.parse(raw) as Record<string, string>) : {};
        map[data.slug] = data.manageToken;
        window.localStorage.setItem(MANAGE_KEY, JSON.stringify(map));
      } catch {
        /* ignore storage errors */
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not publish this signal.");
    } finally {
      setPublishing(false);
    }
  }

  async function copyPlan() {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(planToText(result));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setError("Clipboard access was blocked by your browser. Select the plan text manually.");
    }
  }

  const previewCandles = sample
    ? toPriceSpace(sample.candles, Number.isFinite(anchorPrice) && anchorPrice > 0 ? anchorPrice : spec.priceRef, rangePrice)
    : vision && vision.candles.length >= 8
      ? toPriceSpace(vision.candles, Number.isFinite(anchorPrice) && anchorPrice > 0 ? anchorPrice : spec.priceRef, rangePrice)
      : [];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 xl:grid-cols-[1.05fr_1fr_0.85fr]">
        {/* 1. SOURCE */}
        <section className="card flex flex-col p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-sm font-bold uppercase tracking-[0.12em] text-cream/90">1 · Your chart</h2>
            {(file || sample) && (
              <button type="button" onClick={resetAll} className="text-[0.68rem] font-bold text-muted hover:text-rose">
                Clear
              </button>
            )}
          </div>

          <div
            onDragOver={(event) => {
              event.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(event) => {
              event.preventDefault();
              setDragging(false);
              const dropped = event.dataTransfer.files?.[0];
              if (dropped) void readFile(dropped);
            }}
            className={`mt-3 rounded-xl border-2 border-dashed p-4 text-center transition ${
              dragging ? "border-gold bg-gold/10" : "border-white/15 bg-ink/40"
            }`}
          >
            {previewUrl ? (
              <div className="space-y-2">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={previewUrl} alt="Uploaded chart screenshot" className="mx-auto max-h-[260px] w-auto rounded-lg border border-white/10 object-contain" />
                <p className="text-[0.68rem] text-muted">
                  {reading ? "Reading candles…" : vision ? `${vision.candles.length} candles detected · ${vision.confidence}% vision confidence` : "Screenshot loaded"}
                </p>
              </div>
            ) : sample ? (
              <div className="space-y-2">
                <CandleChart candles={previewCandles} digits={spec.digits} height={210} showAxis={false} compact />
                <p className="text-[0.68rem] text-gold">{sample.title}</p>
                <p className="text-[0.66rem] leading-relaxed text-muted">{sample.lesson}</p>
              </div>
            ) : (
              <div className="py-6">
                <div className="mx-auto grid h-12 w-12 place-items-center rounded-full border border-gold/35 bg-gold/10 text-gold">
                  <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.7">
                    <path d="M12 16V4m0 0L8 8m4-4 4 4" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M4 16v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" strokeLinecap="round" />
                  </svg>
                </div>
                <p className="mt-3 text-sm font-bold text-cream">Drop a chart screenshot here</p>
                <p className="mt-1 text-[0.7rem] text-muted">
                  Or paste with <kbd className="rounded border border-white/20 px-1 font-mono text-[0.65rem]">Ctrl/⌘ + V</kbd>. Candles are read in your browser.
                </p>
              </div>
            )}

            <div className="mt-3 flex flex-wrap justify-center gap-2">
              <button type="button" className="btn btn-ghost text-[0.72rem]" onClick={() => fileInputRef.current?.click()}>
                Choose from gallery
              </button>
              <button type="button" className="btn btn-ghost text-[0.72rem]" onClick={() => cameraInputRef.current?.click()}>
                Take screenshot
              </button>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(event) => {
                const picked = event.target.files?.[0];
                if (picked) void readFile(picked);
                event.target.value = "";
              }}
            />
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={(event) => {
                const picked = event.target.files?.[0];
                if (picked) void readFile(picked);
                event.target.value = "";
              }}
            />
          </div>

          {vision ? (
            <div className="mt-3 rounded-lg border border-white/10 bg-white/[0.025] p-2.5">
              <div className="flex items-center justify-between gap-2">
                <p className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-muted">Vision report</p>
                <span className={`font-mono text-[0.68rem] ${vision.confidence >= 70 ? "text-mint" : vision.confidence >= 45 ? "text-gold" : "text-rose"}`}>
                  {vision.confidence}%
                </span>
              </div>
              <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-magenta to-gold"
                  style={{ width: `${Math.max(4, vision.confidence)}%` }}
                />
              </div>
              <ul className="mt-2 space-y-1">
                {vision.notes.slice(0, 3).map((note, index) => (
                  <li key={index} className="text-[0.66rem] leading-relaxed text-muted">
                    · {note}
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          <div className="mt-3">
            <p className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-muted">Or load a sample chart</p>
            <div className="mt-1.5 grid grid-cols-2 gap-1.5">
              {SAMPLE_CHARTS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => loadSample(item)}
                  className={`rounded-lg border px-2 py-1.5 text-left text-[0.66rem] font-semibold leading-tight transition ${
                    sample?.id === item.id
                      ? "border-gold/60 bg-gold/10 text-cream"
                      : "border-white/10 bg-white/[0.02] text-cream/70 hover:border-gold/40 hover:text-cream"
                  }`}
                >
                  {item.instrument} · {item.timeframe}
                  <span className="mt-0.5 block text-[0.6rem] font-normal text-muted">{item.difficulty}</span>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* 2. SETUP */}
        <section className="card flex flex-col p-4 sm:p-5">
          <h2 className="font-display text-sm font-bold uppercase tracking-[0.12em] text-cream/90">2 · Trade context</h2>

          <div className="mt-3 grid gap-3">
            <div>
              <label htmlFor="instrument" className="label">Instrument</label>
              <select
                id="instrument"
                className="field mt-1"
                value={instrument}
                onChange={(event) => {
                  setInstrument(event.target.value as InstrumentCode);
                  setPriceTouched(false);
                }}
              >
                {INSTRUMENT_LIST.map((item) => (
                  <option key={item.code} value={item.code}>
                    {item.code} — {item.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <span className="label">Chart timeframe</span>
              <div className="mt-1 grid grid-cols-6 gap-1">
                {TIMEFRAMES.map((tf) => (
                  <button
                    key={tf.value}
                    type="button"
                    onClick={() => setTimeframe(tf.value)}
                    className={`rounded-md border py-1.5 text-[0.7rem] font-bold transition ${
                      timeframe === tf.value
                        ? "border-gold/60 bg-gold/15 text-gold"
                        : "border-white/10 bg-white/[0.02] text-cream/60 hover:text-cream"
                    }`}
                  >
                    {tf.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="label">Trading style</span>
              <div className="mt-1 grid grid-cols-3 gap-1">
                {(Object.keys(STYLE_LABELS) as TradingStyle[]).map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setStyle(value)}
                    className={`rounded-md border py-1.5 text-[0.7rem] font-bold capitalize transition ${
                      style === value
                        ? "border-magenta/60 bg-magenta/15 text-cream"
                        : "border-white/10 bg-white/[0.02] text-cream/60 hover:text-cream"
                    }`}
                  >
                    {STYLE_LABELS[value]}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="price" className="label">Last price on the chart</label>
              <input
                id="price"
                inputMode="decimal"
                className="field mt-1 font-mono"
                value={price}
                onChange={(event) => {
                  setPrice(event.target.value);
                  setPriceTouched(true);
                }}
              />
              <p className="mt-1 text-[0.63rem] leading-relaxed text-muted">
                Levels are anchored here. Reference {spec.priceRef} · {spec.digits} decimals · typical {timeframe} span ≈{" "}
                {rangePrice}.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label htmlFor="account" className="label">Balance (USD)</label>
                <input
                  id="account"
                  inputMode="decimal"
                  className="field mt-1 font-mono"
                  value={accountSize}
                  onChange={(event) => setAccountSize(event.target.value)}
                />
              </div>
              <div>
                <label htmlFor="risk" className="label">Risk %</label>
                <input
                  id="risk"
                  inputMode="decimal"
                  className="field mt-1 font-mono"
                  value={riskPercent}
                  onChange={(event) => setRiskPercent(event.target.value)}
                />
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {[0.5, 1, 2].map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setRiskPercent(String(value))}
                  className="rounded-full border border-white/15 px-2.5 py-1 text-[0.65rem] font-bold text-cream/70 hover:border-gold/40 hover:text-gold"
                >
                  {value}% risk
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* 3. RUN */}
        <section className="card flex flex-col p-4 sm:p-5">
          <h2 className="font-display text-sm font-bold uppercase tracking-[0.12em] text-cream/90">3 · Get the plan</h2>
          <p className="mt-2 text-[0.72rem] leading-relaxed text-muted">
            The engine reads structure, liquidity and candle behaviour, then builds entry, hard stop and three targets
            sized to your account. It will tell you to wait when the edge is not there.
          </p>

          <div className="mt-3 space-y-2">
            <label htmlFor="author" className="label">Display name (if you publish)</label>
            <input
              id="author"
              className="field"
              placeholder="e.g. Wizzy Mentor"
              value={author}
              maxLength={40}
              onChange={(event) => setAuthor(event.target.value)}
            />
            <label className="flex items-start gap-2 rounded-lg border border-white/10 bg-white/[0.02] p-2">
              <input
                type="checkbox"
                checked={publish}
                onChange={(event) => setPublish(event.target.checked)}
                className="mt-0.5 h-4 w-4 accent-[#e9b949]"
              />
              <span className="text-[0.7rem] leading-relaxed text-cream/75">
                Publish to the public Signal Room after analysing
                <span className="block text-[0.63rem] text-muted">Keep it ticked to share your plan; untick for an unlisted link.</span>
              </span>
            </label>
          </div>

          <button type="button" onClick={handleAnalyze} disabled={busy || reading} className="btn btn-primary mt-3 w-full">
            {busy ? "Reading the chart…" : reading ? "Extracting candles…" : "Analyze chart & build the plan"}
          </button>

          {result ? (
            <button type="button" onClick={handlePublish} disabled={publishing} className="btn btn-ghost mt-2 w-full">
              {publishing ? "Publishing…" : publish ? "Publish signal to the room" : "Create unlisted share link"}
            </button>
          ) : null}

          {published ? (
            <div className="mt-3 rounded-lg border border-mint/30 bg-mint/[0.08] p-2.5">
              <p className="text-[0.68rem] font-bold text-mint">Signal saved</p>
              <Link href={`/analysis/${published.slug}`} className="mt-1 block break-all text-[0.68rem] text-cream underline decoration-gold/60">
                /analysis/{published.slug}
              </Link>
              <p className="mt-1 text-[0.62rem] leading-relaxed text-muted">
                Manage token saved on this device — you can mark TP/SL from the signal page.
              </p>
            </div>
          ) : null}

          {error ? (
            <p className="mt-3 rounded-lg border border-rose/35 bg-rose/10 px-2.5 py-2 text-[0.7rem] leading-relaxed text-rose">{error}</p>
          ) : null}
          {notice ? (
            <p className="mt-3 rounded-lg border border-gold/30 bg-gold/10 px-2.5 py-2 text-[0.7rem] leading-relaxed text-gold-soft">{notice}</p>
          ) : null}
          <div className="mt-auto space-y-1.5 pt-4 text-[0.63rem] leading-relaxed text-muted">
            <p className="flex items-center gap-1.5"><span className="text-mint">✓</span> Screenshots stay in your browser</p>
            <p className="flex items-center gap-1.5"><span className="text-mint">✓</span> Hard stop and R:R on every plan</p>
            <p className="flex items-center gap-1.5"><span className="text-gold">!</span> Analysis is education, never a guarantee</p>
          </div>
        </section>
      </div>

      {!result ? (
        <section className="card p-5">
          <div className="grid gap-4 sm:grid-cols-3">
            {[
              { title: "1. Structure first", body: "Swing highs, swing lows, BOS and CHoCH are read from the candles — not from indicators." },
              { title: "2. Liquidity map", body: "Equal highs/lows, range edges and imbalances tell you where price is being drawn." },
              { title: "3. Risk-defined plan", body: "One entry, one invalidation, three targets. Position size is calculated, not guessed." },
            ].map((item) => (
              <div key={item.title} className="rounded-xl border border-white/8 bg-white/[0.025] p-4">
                <p className="font-display text-sm font-bold text-gold">{item.title}</p>
                <p className="mt-1.5 text-xs leading-relaxed text-muted">{item.body}</p>
              </div>
            ))}
          </div>
          <p className="mt-4 text-center text-sm text-muted">
            No chart handy? Load one of the six sample charts and watch the full breakdown generate.
          </p>
        </section>
      ) : (
        <div id="analysis-result" className="scroll-mt-24">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="pill border-mint/35 bg-mint/10 text-mint">Analysis complete</p>
              <h2 className="mt-1.5 font-display text-2xl font-bold text-cream">
                {result.instrument} · {result.timeframe} mentor read
              </h2>
            </div>
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={copyPlan} className="btn btn-ghost text-xs">
                {copied ? "Copied ✓" : "Copy the plan"}
              </button>
              <button type="button" onClick={resetAll} className="btn btn-ghost text-xs">
                New chart
              </button>
              {published ? (
                <Link href={`/analysis/${published.slug}`} className="btn btn-primary text-xs">
                  Open share page →
                </Link>
              ) : (
                <button type="button" onClick={handlePublish} disabled={publishing} className="btn btn-primary text-xs">
                  {publishing ? "Publishing…" : "Publish this signal"}
                </button>
              )}
            </div>
          </div>
          <AnalysisReport
            report={result}
            meta={{ authorName: author || "You", outcome: "pending" }}
            footer={
              <div className="card border-magenta/25 p-4 text-xs leading-relaxed text-cream/70">
                <p className="font-bold text-magenta-hot">Mentor note</p>
                <p className="mt-1">
                  Send the higher-timeframe chart next if you want this bias locked in. Until then, trade the plan exactly
                  as written: one entry, one stop, staged targets. If price does not do what the invalidation level says,
                  the idea is dead — no re-entries, no widening.
                </p>
              </div>
            }
          />
        </div>
      )}
    </div>
  );
}

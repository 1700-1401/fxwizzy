"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { OUTCOME_META } from "@/lib/format";
import type { Outcome } from "@/lib/types";

const MANAGE_KEY = "fxwizzy:managed";

export function SignalActions({
  slug,
  outcome,
  rr1,
  rr2,
  rr3,
}: {
  slug: string;
  outcome: Outcome;
  rr1: number;
  rr2: number;
  rr3: number;
}) {
  const router = useRouter();
  const [token, setToken] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(MANAGE_KEY);
      if (!raw) return;
      const map = JSON.parse(raw) as Record<string, string>;
      if (map[slug]) setToken(map[slug]);
    } catch {
      /* ignore */
    }
  }, [slug]);

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/analysis/${slug}`);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setStatus("Clipboard blocked by your browser.");
    }
  }

  async function mark(next: Outcome) {
    if (!token) return;
    setBusy(true);
    setStatus(null);
    const outcomeR =
      next === "tp1" ? rr1 : next === "tp2" ? rr2 : next === "tp3" ? rr3 : next === "sl" ? -1 : next === "be" ? 0 : null;
    try {
      const response = await fetch(`/api/analyses/${slug}/outcome`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ outcome: next, outcomeR, manageToken: token }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "Could not update the outcome.");
      setStatus("Outcome updated. The public record just got more honest.");
      router.refresh();
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Could not update the outcome.");
    } finally {
      setBusy(false);
    }
  }

  const buttons: { label: string; value: Outcome }[] = [
    { label: "TP1 hit", value: "tp1" },
    { label: "TP2 hit", value: "tp2" },
    { label: "TP3 hit", value: "tp3" },
    { label: "Stopped", value: "sl" },
    { label: "Break-even", value: "be" },
    { label: "Cancel", value: "cancelled" },
  ];

  return (
    <div className="card p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="font-display text-sm font-bold uppercase tracking-[0.12em] text-cream/90">Share this plan</p>
          <p className="mt-1 text-xs text-muted">Anyone with the link can read the full breakdown. Only the publisher can mark the outcome.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={copyLink} className="btn btn-ghost text-xs">
            {copied ? "Link copied ✓" : "Copy share link"}
          </button>
        </div>
      </div>

      <div className="mt-4 border-t border-white/10 pt-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-muted">Current status</span>
          <span className={`rounded-md border px-2 py-0.5 text-[0.65rem] font-bold ${OUTCOME_META[outcome].className}`}>
            {OUTCOME_META[outcome].label}
          </span>
        </div>

        {token ? (
          <>
            <p className="mt-3 text-[0.65rem] font-bold uppercase tracking-[0.14em] text-gold">Publisher controls</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {buttons.map((button) => (
                <button
                  key={button.value}
                  type="button"
                  disabled={busy}
                  onClick={() => mark(button.value)}
                  className="rounded-lg border border-white/15 bg-white/[0.03] px-2.5 py-1.5 text-[0.68rem] font-bold text-cream/80 transition hover:border-gold/45 hover:text-gold disabled:opacity-50"
                >
                  {button.label}
                </button>
              ))}
            </div>
          </>
        ) : (
          <p className="mt-3 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-[0.68rem] leading-relaxed text-muted">
            This device does not hold the manage token for this signal. Publish your own analysis to get a token and an
            auditable track record.
          </p>
        )}
        {status ? <p className="mt-2 text-[0.68rem] text-gold-soft">{status}</p> : null}
      </div>
    </div>
  );
}

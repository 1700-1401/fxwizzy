import { isInstrument, isTimeframe } from "./instruments";
import type { AnalyzerInputs, ChartSource, NormalizedCandle, TradingStyle } from "./types";

export type ParseResult =
  | { ok: true; value: AnalyzerInputs }
  | { ok: false; error: string };

const STYLES: TradingStyle[] = ["scalp", "intraday", "swing"];
const SOURCES: ChartSource[] = ["image", "sample", "fallback"];

const num = (value: unknown, fallback: number) => {
  const n = typeof value === "string" ? Number(value) : value;
  return typeof n === "number" && Number.isFinite(n) ? n : fallback;
};

function parseCandles(raw: unknown): NormalizedCandle[] {
  if (!Array.isArray(raw)) return [];
  const out: NormalizedCandle[] = [];
  for (const item of raw.slice(0, 400)) {
    if (!item || typeof item !== "object") continue;
    const c = item as Record<string, unknown>;
    const o = num(c.o, NaN);
    const h = num(c.h, NaN);
    const l = num(c.l, NaN);
    const cl = num(c.c, NaN);
    if (![o, h, l, cl].every(Number.isFinite)) continue;
    out.push({ o, h, l, c: cl });
  }
  return out;
}

export function parseAnalyzerInputs(body: unknown): ParseResult {
  if (!body || typeof body !== "object") return { ok: false, error: "Invalid request body." };
  const raw = body as Record<string, unknown>;
  const instrument = String(raw.instrument ?? "");
  const timeframe = String(raw.timeframe ?? "");
  const style = String(raw.style ?? "intraday");

  if (!isInstrument(instrument)) return { ok: false, error: "Choose a supported instrument." };
  if (!isTimeframe(timeframe)) return { ok: false, error: "Choose a supported timeframe." };
  if (!STYLES.includes(style as TradingStyle)) return { ok: false, error: "Choose a trading style." };

  const candles = parseCandles(raw.candles);
  if (candles.length > 0 && candles.length < 4) {
    return { ok: false, error: "The chart read returned too few candles. Crop closer to the candles and try again." };
  }

  const sourceRaw = String(raw.source ?? "image");
  const source = SOURCES.includes(sourceRaw as ChartSource) ? (sourceRaw as ChartSource) : "image";

  const visionNotes = Array.isArray(raw.visionNotes)
    ? raw.visionNotes.filter((n): n is string => typeof n === "string").map((n) => n.slice(0, 220)).slice(0, 8)
    : [];

  const anchorPrice = num(raw.anchorPrice, 0);
  if (!(anchorPrice > 0)) return { ok: false, error: "Enter the current market price shown on the chart." };

  const accountSize = Math.min(Math.max(num(raw.accountSize, 1000), 10), 10_000_000);
  const riskPercent = Math.min(Math.max(num(raw.riskPercent, 1), 0.05), 5);

  return {
    ok: true,
    value: {
      instrument,
      timeframe,
      style: style as TradingStyle,
      accountSize,
      riskPercent,
      anchorPrice,
      candles,
      source,
      visionConfidence: Math.min(Math.max(num(raw.visionConfidence, 50), 0), 100),
      visionNotes,
    },
  };
}

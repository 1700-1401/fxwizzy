import { and, desc, eq, sql } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { db } from "@/db";
import { analyses } from "@/db/schema";
import { analyzeChart } from "@/lib/analysis";
import { INSTRUMENTS, getInstrument, isInstrument, isTimeframe } from "@/lib/instruments";
import { SAMPLE_CHARTS } from "@/lib/market";
import type {
  AnalysisResult,
  Bias,
  Grade,
  InstrumentCode,
  Outcome,
  SignalSummary,
  Timeframe,
  TradingStyle,
} from "@/lib/types";

export type SignalStats = {
  total: number;
  graded: number;
  wins: number;
  losses: number;
  pending: number;
  winRate: number;
  avgR: number;
  totalViews: number;
  items: { instrument: InstrumentCode; count: number }[];
};

export function generateSlug(length = 8): string {
  const alphabet = "abcdefghjkmnpqrstuvwxyz23456789";
  const bytes = randomBytes(length);
  let out = "";
  for (let i = 0; i < length; i += 1) out += alphabet[bytes[i] % alphabet.length];
  return out;
}

export function generateToken(): string {
  return randomBytes(18).toString("base64url");
}

const WIN_OUTCOMES: Outcome[] = ["tp1", "tp2", "tp3"];

export async function listPublicSignals(options?: {
  limit?: number;
  instrument?: string;
}): Promise<SignalSummary[]> {
  const limit = Math.min(Math.max(options?.limit ?? 12, 1), 60);
  const instrument = options?.instrument && isInstrument(options.instrument) ? options.instrument : undefined;
  const conditions = [eq(analyses.isPublic, true)];
  if (instrument) conditions.push(eq(analyses.instrument, instrument));

  const rows = await db
    .select({
      slug: analyses.slug,
      createdAt: analyses.createdAt,
      instrument: analyses.instrument,
      timeframe: analyses.timeframe,
      bias: analyses.bias,
      grade: analyses.grade,
      confidence: analyses.confidence,
      outcome: analyses.outcome,
      outcomeR: analyses.outcomeR,
      authorName: analyses.authorName,
      views: analyses.views,
      entry: analyses.entry,
      stop: analyses.stop,
      tp1: analyses.tp1,
      tp2: analyses.tp2,
      tp3: analyses.tp3,
      rr: analyses.rr,
      setupModel: sql<string>`coalesce(${analyses.report}->>'setupModel', '')`,
      verdict: sql<string>`coalesce(${analyses.report}->'finalSignal'->>'verdict', 'wait')`,
      sentence: sql<string>`coalesce(${analyses.report}->'finalSignal'->>'sentence', '')`,
      headline: sql<string>`coalesce(${analyses.report}->'finalSignal'->>'headline', '')`,
    })
    .from(analyses)
    .where(and(...conditions))
    .orderBy(desc(analyses.createdAt))
    .limit(limit);

  return rows.map((row) => ({
    ...row,
    createdAt: row.createdAt.toISOString(),
    setupModel: row.setupModel ?? "",
    verdict: row.verdict ?? "wait",
    sentence: row.sentence ?? "",
    headline: row.headline ?? "",
  }));
}

export async function getAnalysisBySlug(slug: string): Promise<
  | { report: AnalysisResult; meta: { outcome: Outcome; outcomeR: number | null; authorName: string; views: number; createdAt: string; isPublic: boolean; instrument: InstrumentCode; timeframe: Timeframe; bias: Bias; grade: Grade; confidence: number } }
  | null
> {
  const rows = await db.select().from(analyses).where(eq(analyses.slug, slug)).limit(1);
  const row = rows[0];
  if (!row) return null;
  return {
    report: { ...row.report, slug: row.slug },
    meta: {
      outcome: row.outcome,
      outcomeR: row.outcomeR,
      authorName: row.authorName,
      views: row.views,
      createdAt: row.createdAt.toISOString(),
      isPublic: row.isPublic,
      instrument: row.instrument,
      timeframe: row.timeframe,
      bias: row.bias,
      grade: row.grade,
      confidence: row.confidence,
    },
  };
}

export async function incrementViews(slug: string): Promise<void> {
  try {
    await db
      .update(analyses)
      .set({ views: sql`${analyses.views} + 1` })
      .where(eq(analyses.slug, slug));
  } catch {
    /* non-critical */
  }
}

export async function getSignalStats(): Promise<SignalStats> {
  const rows = await db
    .select({ outcome: analyses.outcome, outcomeR: analyses.outcomeR, views: analyses.views, instrument: analyses.instrument })
    .from(analyses)
    .where(eq(analyses.isPublic, true));

  let wins = 0;
  let losses = 0;
  let pending = 0;
  let totalViews = 0;
  let rSum = 0;
  let rCount = 0;
  const byInstrument = new Map<InstrumentCode, number>();

  for (const row of rows) {
    totalViews += row.views;
    byInstrument.set(row.instrument, (byInstrument.get(row.instrument) ?? 0) + 1);
    if (WIN_OUTCOMES.includes(row.outcome)) {
      wins += 1;
      rSum += row.outcomeR ?? 1;
      rCount += 1;
    } else if (row.outcome === "sl") {
      losses += 1;
      rSum += row.outcomeR ?? -1;
      rCount += 1;
    } else if (row.outcome === "be") {
      rCount += 1;
    } else {
      pending += 1;
    }
  }

  const graded = wins + losses;
  return {
    total: rows.length,
    graded,
    wins,
    losses,
    pending,
    winRate: graded > 0 ? Math.round((wins / graded) * 100) : 0,
    avgR: rCount > 0 ? Number((rSum / rCount).toFixed(2)) : 0,
    totalViews,
    items: [...byInstrument.entries()]
      .map(([instrument, count]) => ({ instrument, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 6),
  };
}

const SEED_BLUEPRINTS: {
  sampleId: string;
  author: string;
  outcome: Outcome;
  views: number;
  hoursAgo: number;
  style: TradingStyle;
}[] = [
  { sampleId: "gold-h1-sweep", author: "Wizzy Mentor", outcome: "tp2", views: 412, hoursAgo: 5, style: "intraday" },
  { sampleId: "eurusd-m15-reversal", author: "Naomi T.", outcome: "sl", views: 208, hoursAgo: 19, style: "scalp" },
  { sampleId: "cable-h4-range", author: "FXWizzy Desk", outcome: "pending", views: 176, hoursAgo: 31, style: "swing" },
  { sampleId: "gold-m5-breakout", author: "Ade K.", outcome: "tp1", views: 94, hoursAgo: 44, style: "scalp" },
  { sampleId: "euro-h4-flag", author: "Wizzy Mentor", outcome: "tp3", views: 651, hoursAgo: 60, style: "swing" },
];

const SAMPLE_KEY_MAP: Record<string, string> = {
  "gold-h1-sweep": "gold-h1-sweep",
  "eurusd-m15-reversal": "euro-m15-choch",
  "cable-h4-range": "cable-h4-range",
  "gold-m5-breakout": "gold-m5-breakout",
  "euro-h4-flag": "euro-h4-flag",
};

export async function ensureSeeded(): Promise<void> {
  const existing = await db.select({ slug: analyses.slug }).from(analyses).limit(1);
  if (existing.length > 0) return;

  const values = SEED_BLUEPRINTS.map((blueprint) => {
    const sample = SAMPLE_CHARTS.find((s) => s.id === SAMPLE_KEY_MAP[blueprint.sampleId]);
    if (!sample) return null;
    const spec = getInstrument(sample.instrument);
    const report = analyzeChart({
      instrument: sample.instrument,
      timeframe: sample.timeframe,
      style: blueprint.style,
      accountSize: 10000,
      riskPercent: 1,
      anchorPrice: Number((spec.priceRef + sample.anchorPriceOffset).toFixed(spec.digits)),
      candles: sample.candles,
      source: "sample",
      visionConfidence: 98,
      visionNotes: ["Curated FXWizzy chart sample."],
    });
    const outcomeR =
      blueprint.outcome === "sl"
        ? -1
        : blueprint.outcome === "tp1"
          ? report.levels.rr1
          : blueprint.outcome === "tp2"
            ? report.levels.rr2
            : blueprint.outcome === "tp3"
              ? report.levels.rr3
              : null;
    if (blueprint.outcome !== "pending") report.finalSignal = { ...report.finalSignal };

    return {
      slug: `demo-${sample.id}`,
      createdAt: new Date(Date.now() - blueprint.hoursAgo * 3600_000),
      instrument: report.instrument,
      timeframe: report.timeframe,
      bias: report.bias,
      grade: report.grade,
      confidence: report.confidence,
      entry: report.levels.entry,
      stop: report.levels.stop,
      tp1: report.levels.tp1,
      tp2: report.levels.tp2,
      tp3: report.levels.tp3,
      rr: report.levels.rr2,
      authorName: blueprint.author,
      isPublic: true,
      outcome: blueprint.outcome,
      outcomeR,
      manageToken: generateToken(),
      views: blueprint.views,
      report,
    };
  }).filter((v): v is NonNullable<typeof v> => v !== null);

  await db.insert(analyses).values(values).onConflictDoNothing();
}

export async function insertAnalysis(params: {
  report: AnalysisResult;
  authorName: string;
  isPublic: boolean;
}): Promise<{ slug: string; manageToken: string }> {
  const slug = `${params.report.instrument.toLowerCase()}-${params.report.timeframe.toLowerCase()}-${generateSlug(6)}`;
  const manageToken = generateToken();
  await db.insert(analyses).values({
    slug,
    instrument: params.report.instrument,
    timeframe: params.report.timeframe,
    bias: params.report.bias,
    grade: params.report.grade,
    confidence: params.report.confidence,
    entry: params.report.levels.entry,
    stop: params.report.levels.stop,
    tp1: params.report.levels.tp1,
    tp2: params.report.levels.tp2,
    tp3: params.report.levels.tp3,
    rr: params.report.levels.rr2,
    authorName: params.authorName,
    isPublic: params.isPublic,
    outcome: "pending",
    manageToken,
    report: { ...params.report, slug },
  });
  return { slug, manageToken };
}

export async function updateOutcome(
  slug: string,
  token: string,
  outcome: Outcome,
  outcomeR: number | null,
): Promise<boolean> {
  const allowed: Outcome[] = ["pending", "tp1", "tp2", "tp3", "sl", "be", "cancelled"];
  if (!allowed.includes(outcome)) return false;
  const rows = await db.select({ manageToken: analyses.manageToken }).from(analyses).where(eq(analyses.slug, slug)).limit(1);
  const row = rows[0];
  if (!row || row.manageToken !== token) return false;
  await db.update(analyses).set({ outcome, outcomeR }).where(eq(analyses.slug, slug));
  return true;
}

export const instrumentOptions = Object.values(INSTRUMENTS);
export { isTimeframe };

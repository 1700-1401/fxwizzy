import type { InstrumentCode, NormalizedCandle, Timeframe } from "./types";

export const clamp = (n: number, min: number, max: number) => Math.min(max, Math.max(min, n));

export function roundTo(value: number, step: number): number {
  if (!Number.isFinite(value) || step <= 0) return value;
  return Math.round(value / step) * step;
}

export function roundDecimals(value: number, digits: number): number {
  const f = 10 ** digits;
  return Math.round(value * f) / f;
}

/* ------------------------------------------------------------------ */
/* Deterministic sample chart generation                              */
/* ------------------------------------------------------------------ */

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type Segment = { count: number; drift: number; vol: number };

export function makeSeries(seed: number, segments: Segment[], start = 0.5): NormalizedCandle[] {
  const rand = mulberry32(seed);
  const candles: NormalizedCandle[] = [];
  let price = start;
  for (const seg of segments) {
    for (let i = 0; i < seg.count; i += 1) {
      const open = price;
      const shock = (rand() - 0.5) * seg.vol * 2.1;
      const drift = seg.drift * (0.55 + rand() * 0.9);
      let close = clamp(open + drift + shock, 0.05, 0.95);
      if (Math.abs(close - open) < seg.vol * 0.22) {
        close = clamp(open + (rand() > 0.5 ? 1 : -1) * seg.vol * 0.35, 0.05, 0.95);
      }
      const wickUp = rand() * seg.vol * 0.9;
      const wickDown = rand() * seg.vol * 0.9;
      const high = clamp(Math.max(open, close) + wickUp, 0.05, 0.97);
      const low = clamp(Math.min(open, close) - wickDown, 0.03, 0.95);
      candles.push({
        o: roundDecimals(open, 4),
        h: roundDecimals(high, 4),
        l: roundDecimals(low, 4),
        c: roundDecimals(close, 4),
      });
      price = close;
    }
  }
  return candles;
}

export type ChartSample = {
  id: string;
  title: string;
  instrument: InstrumentCode;
  timeframe: Timeframe;
  lesson: string;
  difficulty: "Core" | "Intermediate" | "Advanced";
  anchorPriceOffset: number;
  candles: NormalizedCandle[];
};

export const SAMPLE_CHARTS: ChartSample[] = [
  {
    id: "gold-h1-sweep",
    title: "Gold H1 — sell-side sweep, then reclaim",
    instrument: "XAUUSD",
    timeframe: "H1",
    lesson: "Liquidity sweep below an old low, instant reclaim, then a clean break of structure. The textbook continuation.",
    difficulty: "Core",
    anchorPriceOffset: 6.4,
    candles: makeSeries(9123, [
      { count: 11, drift: -0.0035, vol: 0.0055 },
      { count: 8, drift: 0.008, vol: 0.0062 },
      { count: 6, drift: -0.0075, vol: 0.0075 },
      { count: 14, drift: 0.0125, vol: 0.0082 },
      { count: 9, drift: -0.0055, vol: 0.006 },
      { count: 12, drift: 0.0135, vol: 0.0085 },
    ], 0.3),
  },
  {
    id: "euro-m15-choch",
    title: "EURUSD M15 — equal highs, distribution, CHoCH",
    instrument: "EURUSD",
    timeframe: "M15",
    lesson: "Buy-side liquidity taken twice, momentum divergence, then a change of character. Reversal sellers get a discount entry.",
    difficulty: "Intermediate",
    anchorPriceOffset: -0.0012,
    candles: makeSeries(4471, [
      { count: 13, drift: 0.0055, vol: 0.0045 },
      { count: 7, drift: 0.0012, vol: 0.0042 },
      { count: 9, drift: 0.0048, vol: 0.0048 },
      { count: 7, drift: -0.0045, vol: 0.005 },
      { count: 15, drift: -0.0115, vol: 0.0068 },
      { count: 8, drift: 0.0045, vol: 0.0045 },
    ], 0.35),
  },
  {
    id: "cable-h4-range",
    title: "GBPUSD H4 — range compression / false breakout",
    instrument: "GBPUSD",
    timeframe: "H4",
    lesson: "Two failed breakouts around the same high. Range liquidity is being engineered — trade the edges, not the middle.",
    difficulty: "Advanced",
    anchorPriceOffset: 0.0021,
    candles: makeSeries(7712, [
      { count: 12, drift: 0.0115, vol: 0.0075 },
      { count: 11, drift: -0.0112, vol: 0.0078 },
      { count: 12, drift: 0.0104, vol: 0.0072 },
      { count: 10, drift: -0.0098, vol: 0.0068 },
      { count: 11, drift: 0.0042, vol: 0.0055 },
    ], 0.4),
  },
  {
    id: "gold-m5-breakout",
    title: "Gold M5 — Asian range breakout & retest",
    instrument: "XAUUSD",
    timeframe: "M5",
    lesson: "Tight accumulation, displacement out of the range, then a shallow retest into the breakout zone. Entry at the retest.",
    difficulty: "Core",
    anchorPriceOffset: -2.1,
    candles: makeSeries(3310, [
      { count: 16, drift: 0.0006, vol: 0.0022 },
      { count: 5, drift: 0.0085, vol: 0.0045 },
      { count: 7, drift: -0.0055, vol: 0.0038 },
      { count: 12, drift: 0.009, vol: 0.0046 },
      { count: 9, drift: 0.0028, vol: 0.003 },
    ], 0.4),
  },
  {
    id: "usdjpy-h1-fvg",
    title: "USDJPY H1 — bearish FVG, premium mitigation",
    instrument: "USDJPY",
    timeframe: "H1",
    lesson: "Displacement leaves an imbalance. Price retraces into premium, fills the void, and continues lower.",
    difficulty: "Intermediate",
    anchorPriceOffset: 0.21,
    candles: makeSeries(6024, [
      { count: 14, drift: -0.0075, vol: 0.0062 },
      { count: 8, drift: 0.0068, vol: 0.0055 },
      { count: 16, drift: -0.0115, vol: 0.0072 },
      { count: 10, drift: 0.0082, vol: 0.0065 },
      { count: 12, drift: -0.0105, vol: 0.007 },
    ], 0.62),
  },
  {
    id: "euro-h4-flag",
    title: "EURUSD H4 — bull flag into prior highs",
    instrument: "EURUSD",
    timeframe: "H4",
    lesson: "Impulse, corrective flag with higher lows, then continuation. HTF trend stays intact until the last higher low breaks.",
    difficulty: "Core",
    anchorPriceOffset: 0.0043,
    candles: makeSeries(8814, [
      { count: 10, drift: -0.0035, vol: 0.006 },
      { count: 16, drift: 0.0115, vol: 0.0072 },
      { count: 13, drift: -0.0055, vol: 0.0058 },
      { count: 14, drift: 0.0105, vol: 0.007 },
      { count: 8, drift: 0.0042, vol: 0.0055 },
    ], 0.28),
  },
];

/* ------------------------------------------------------------------ */
/* Technical metrics from a candle series                            */
/* ------------------------------------------------------------------ */

export type SwingPoint = { index: number; price: number };

export type ChartMetrics = {
  count: number;
  rangeHigh: number;
  rangeLow: number;
  range: number;
  lastClose: number;
  lastOpen: number;
  lastHigh: number;
  lastLow: number;
  lastDir: 1 | -1 | 0;
  bullRatio: number;
  closePos: number;
  slope: number;
  totalTrend: number;
  atr: number;
  momentum: number;
  swingsHigh: SwingPoint[];
  swingsLow: SwingPoint[];
  lastSwingHigh: SwingPoint;
  lastSwingLow: SwingPoint;
  structuralHigh: SwingPoint;
  structuralLow: SwingPoint;
  bosUp: boolean;
  bosDown: boolean;
  choch: boolean;
  equalHighs: boolean;
  equalLows: boolean;
  structureLabel: string;
  htfBias: "bullish" | "bearish" | "neutral";
};

export function computeMetrics(input: NormalizedCandle[]): ChartMetrics {
  const candles = input.length > 0 ? input : makeSeries(1, [{ count: 40, drift: 0, vol: 0.006 }]);
  const count = candles.length;
  let rangeHigh = -Infinity;
  let rangeLow = Infinity;
  let bull = 0;
  let bear = 0;
  for (const c of candles) {
    rangeHigh = Math.max(rangeHigh, c.h);
    rangeLow = Math.min(rangeLow, c.l);
    if (c.c > c.o) bull += 1;
    else if (c.c < c.o) bear += 1;
  }
  const range = Math.max(rangeHigh - rangeLow, 0.0001);
  const last = candles[count - 1];

  // Linear regression slope of closes.
  let sumX = 0;
  let sumY = 0;
  let sumXY = 0;
  let sumXX = 0;
  for (let i = 0; i < count; i += 1) {
    sumX += i;
    sumY += candles[i].c;
    sumXY += i * candles[i].c;
    sumXX += i * i;
  }
  const denom = count * sumXX - sumX * sumX || 1;
  const slope = (count * sumXY - sumX * sumY) / denom;
  const totalTrend = slope * count;

  // ATR(14)
  const atrWindow = Math.min(14, count);
  let trSum = 0;
  for (let i = count - atrWindow; i < count; i += 1) {
    const prevClose = i > 0 ? candles[i - 1].c : candles[i].o;
    trSum += Math.max(
      candles[i].h - candles[i].l,
      Math.abs(candles[i].h - prevClose),
      Math.abs(candles[i].l - prevClose),
    );
  }
  const atr = Math.max(trSum / atrWindow, range * 0.004);

  const window = count >= 30 ? 2 : 1;
  const swingsHigh: SwingPoint[] = [];
  const swingsLow: SwingPoint[] = [];
  for (let i = window; i < count - window; i += 1) {
    let isHigh = true;
    let isLow = true;
    for (let j = i - window; j <= i + window; j += 1) {
      if (j === i) continue;
      if (candles[j].h >= candles[i].h) isHigh = false;
      if (candles[j].l <= candles[i].l) isLow = false;
    }
    if (isHigh) swingsHigh.push({ index: i, price: candles[i].h });
    if (isLow) swingsLow.push({ index: i, price: candles[i].l });
  }
  if (swingsHigh.length === 0) swingsHigh.push({ index: Math.max(0, count - 5), price: rangeHigh });
  if (swingsLow.length === 0) swingsLow.push({ index: Math.max(0, count - 5), price: rangeLow });

  const lastSwingHigh = swingsHigh[swingsHigh.length - 1];
  const lastSwingLow = swingsLow[swingsLow.length - 1];

  const highsBeforeLastLow = swingsHigh.filter((s) => s.index < lastSwingLow.index);
  const structuralHigh = highsBeforeLastLow.length
    ? highsBeforeLastLow[highsBeforeLastLow.length - 1]
    : swingsHigh[Math.max(0, swingsHigh.length - 2)] ?? lastSwingHigh;
  const lowsBeforeLastHigh = swingsLow.filter((s) => s.index < lastSwingHigh.index);
  const structuralLow = lowsBeforeLastHigh.length
    ? lowsBeforeLastHigh[lowsBeforeLastHigh.length - 1]
    : swingsLow[Math.max(0, swingsLow.length - 2)] ?? lastSwingLow;

  const bosUp = last.c > structuralHigh.price;
  const bosDown = last.c < structuralLow.price;

  const momentum = count >= 6 ? last.c - candles[count - 6].c : last.c - candles[0].o;
  const trendUp = totalTrend > atr * 0.4 || momentum > 0;
  const choch = (bosUp && totalTrend < -atr * 0.2) || (bosDown && totalTrend > atr * 0.2);

  const tol = Math.max(atr * 0.45, range * 0.012);
  const recentHighs = swingsHigh.slice(-3);
  const recentLows = swingsLow.slice(-3);
  let equalHighs = false;
  let equalLows = false;
  for (let i = 1; i < recentHighs.length; i += 1) {
    if (Math.abs(recentHighs[i].price - recentHighs[i - 1].price) <= tol) equalHighs = true;
  }
  for (let i = 1; i < recentLows.length; i += 1) {
    if (Math.abs(recentLows[i].price - recentLows[i - 1].price) <= tol) equalLows = true;
  }

  const higherHighs = swingsHigh.length >= 2 && swingsHigh[swingsHigh.length - 1].price > swingsHigh[swingsHigh.length - 2].price;
  const higherLows = swingsLow.length >= 2 && swingsLow[swingsLow.length - 1].price > swingsLow[swingsLow.length - 2].price;
  let structureLabel = "Consolidation / no clear structure";
  if (higherHighs && higherLows) structureLabel = "Higher highs & higher lows (bullish structure)";
  else if (!higherHighs && !higherLows) structureLabel = "Lower highs & lower lows (bearish structure)";
  else if (bosUp) structureLabel = "Break of structure to the upside";
  else if (bosDown) structureLabel = "Break of structure to the downside";
  else if (higherLows) structureLabel = "Higher lows into resistance (bullish compression)";
  else if (!higherHighs) structureLabel = "Lower highs into support (bearish compression)";

  const closePos = clamp((last.c - rangeLow) / range, 0, 1);
  const dirScore = (bull / Math.max(bull + bear, 1)) * 2 - 1;
  const trendScore = clamp(totalTrend / (range * 0.5), -1, 1);
  const structureScore = bosUp ? 0.7 : bosDown ? -0.7 : 0;
  const htfBiasScore = 0.45 * trendScore + 0.25 * dirScore + 0.2 * (closePos * 2 - 1) + 0.18 * structureScore;
  const htfBias = htfBiasScore > 0.18 ? "bullish" : htfBiasScore < -0.18 ? "bearish" : "neutral";

  return {
    count,
    rangeHigh,
    rangeLow,
    range,
    lastClose: last.c,
    lastOpen: last.o,
    lastHigh: last.h,
    lastLow: last.l,
    lastDir: last.c > last.o ? 1 : last.c < last.o ? -1 : 0,
    bullRatio: bull / Math.max(bull + bear, 1),
    closePos,
    slope,
    totalTrend,
    atr,
    momentum,
    swingsHigh,
    swingsLow,
    lastSwingHigh,
    lastSwingLow,
    structuralHigh,
    structuralLow,
    bosUp,
    bosDown,
    choch,
    equalHighs,
    equalLows,
    structureLabel: trendUp && !bosDown ? structureLabel : structureLabel,
    htfBias,
  };
}

/* ------------------------------------------------------------------ */
/* Candle behaviour reading                                          */
/* ------------------------------------------------------------------ */

export type CandleRead = {
  label: string;
  sentence: string;
  bodyPct: number;
  upperWickPct: number;
  lowerWickPct: number;
  bullEngulf: boolean;
  bearEngulf: boolean;
  pinBar: boolean;
  insideBar: boolean;
  doji: boolean;
  momentum: boolean;
};

export function readLastCandle(candles: NormalizedCandle[]): CandleRead {
  const n = candles.length;
  const c = candles[n - 1];
  const p = candles[Math.max(0, n - 2)];
  const total = Math.max(c.h - c.l, 1e-6);
  const body = Math.abs(c.c - c.o);
  const upper = c.h - Math.max(c.o, c.c);
  const lower = Math.min(c.o, c.c) - c.l;
  const bodyPct = Math.round((body / total) * 100);
  const upperWickPct = Math.round((upper / total) * 100);
  const lowerWickPct = Math.round((lower / total) * 100);
  const bullish = c.c > c.o;
  const prevBody = Math.abs(p.c - p.o);
  const bullEngulf = bullish && p.c < p.o && c.c >= p.o && c.o <= p.c && body > prevBody;
  const bearEngulf = !bullish && p.c > p.o && c.c <= p.o && c.o >= p.c && body > prevBody;
  const pinBar = (upper > body * 2.2 && upper > total * 0.55) || (lower > body * 2.2 && lower > total * 0.55);
  const insideBar = c.h <= p.h && c.l >= p.l;
  const doji = bodyPct <= 12;
  const momentum = bodyPct >= 62;

  let label = "Balanced candle — no strong intent";
  if (bullEngulf) label = "Bullish engulfing (demand accepted)";
  else if (bearEngulf) label = "Bearish engulfing (supply accepted)";
  else if (pinBar && lowerWickPct > upperWickPct) label = "Bullish rejection wick (buyers defended)";
  else if (pinBar && upperWickPct > lowerWickPct) label = "Bearish rejection wick (sellers defended)";
  else if (doji) label = "Doji / indecision";
  else if (momentum && bullish) label = "Expansion candle, buyers in control";
  else if (momentum && !bullish) label = "Expansion candle, sellers in control";
  else if (insideBar) label = "Inside bar (compression before expansion)";

  const direction = bullish ? "bullish" : !bullish ? "bearish" : "flat";
  const wickSide = upperWickPct > lowerWickPct ? "upper" : "lower";
  const sentence = `Last candle closed ${direction} with a ${bodyPct}% body, ${upperWickPct}% upper wick and ${lowerWickPct}% lower wick. ${
    pinBar
      ? `The long ${wickSide} wick means that side was swept and rejected — read it as ${wickSide === "upper" ? "supply" : "demand"} until proven otherwise.`
      : momentum
        ? `Body dominance says the move is being accepted, so continuation after a shallow retracement is the higher-probability path.`
        : `Small body means the market is deciding — let the next candle close before committing risk.`
  }`;

  return {
    label,
    sentence,
    bodyPct,
    upperWickPct,
    lowerWickPct,
    bullEngulf,
    bearEngulf,
    pinBar,
    insideBar,
    doji,
    momentum,
  };
}

export function volatilityLabel(atr: number, range: number): string {
  const ratio = atr / Math.max(range, 1e-9);
  if (ratio > 0.11) return "Expanded volatility — reduce size";
  if (ratio < 0.035) return "Compressed volatility — breakout pending";
  return "Normal volatility";
}

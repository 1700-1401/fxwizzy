import type { InstrumentCode, Timeframe } from "./types";

export type InstrumentSpec = {
  code: InstrumentCode;
  name: string;
  short: string;
  kind: "gold" | "fx" | "index" | "crypto";
  digits: number;
  pip: number;
  priceRef: number;
  /** Typical visible price span of a screenshot for this timeframe. */
  range: Record<Timeframe, number>;
  /** USD P/L for a 1.00 price move on one standard lot. */
  usdPerLotPerUnit: number;
  lotStep: number;
  minLot: number;
  spread: string;
  session: string;
  note: string;
};

export const INSTRUMENTS: Record<InstrumentCode, InstrumentSpec> = {
  XAUUSD: {
    code: "XAUUSD",
    name: "Gold / US Dollar",
    short: "Gold",
    kind: "gold",
    digits: 2,
    pip: 0.1,
    priceRef: 3345.0,
    range: { M5: 9, M15: 17, M30: 26, H1: 42, H4: 95, D1: 215 },
    usdPerLotPerUnit: 100,
    lotStep: 0.01,
    minLot: 0.01,
    spread: "12–35 points",
    session: "London + New York overlap",
    note: "XAUUSD respects liquidity sweeps around session highs/lows more than any other pair. Never chase gold mid-range.",
  },
  EURUSD: {
    code: "EURUSD",
    name: "Euro / US Dollar",
    short: "Euro",
    kind: "fx",
    digits: 5,
    pip: 0.0001,
    priceRef: 1.115,
    range: { M5: 0.0009, M15: 0.0017, M30: 0.0026, H1: 0.0042, H4: 0.0095, D1: 0.0175 },
    usdPerLotPerUnit: 100000,
    lotStep: 0.01,
    minLot: 0.01,
    spread: "0.6–1.4 pips",
    session: "London open → New York",
    note: "EURUSD gives the cleanest market-structure reads during London. Asian-session breaks are usually liquidity traps.",
  },
  GBPUSD: {
    code: "GBPUSD",
    name: "British Pound / US Dollar",
    short: "Cable",
    kind: "fx",
    digits: 5,
    pip: 0.0001,
    priceRef: 1.268,
    range: { M5: 0.0011, M15: 0.002, M30: 0.0032, H1: 0.0052, H4: 0.0115, D1: 0.021 },
    usdPerLotPerUnit: 100000,
    lotStep: 0.01,
    minLot: 0.01,
    spread: "1.0–2.2 pips",
    session: "London open",
    note: "Cable runs stops aggressively. Wider invalidation and smaller size is the professional approach.",
  },
  USDJPY: {
    code: "USDJPY",
    name: "US Dollar / Japanese Yen",
    short: "Gopher",
    kind: "fx",
    digits: 3,
    pip: 0.01,
    priceRef: 154.2,
    range: { M5: 0.09, M15: 0.18, M30: 0.28, H1: 0.48, H4: 1.05, D1: 2.2 },
    usdPerLotPerUnit: 650,
    lotStep: 0.01,
    minLot: 0.01,
    spread: "0.7–1.6 pips",
    session: "Tokyo + New York",
    note: "JPY pairs love round-number liquidity (150.00, 155.00). Treat them as magnets, not walls.",
  },
  GBPJPY: {
    code: "GBPJPY",
    name: "British Pound / Japanese Yen",
    short: "Beast",
    kind: "fx",
    digits: 3,
    pip: 0.01,
    priceRef: 195.6,
    range: { M5: 0.18, M15: 0.34, M30: 0.52, H1: 0.9, H4: 1.9, D1: 3.8 },
    usdPerLotPerUnit: 511,
    lotStep: 0.01,
    minLot: 0.01,
    spread: "1.5–3.0 pips",
    session: "London open",
    note: "Fast and unforgiving. If the setup is not A-grade, there is no trade.",
  },
  AUDUSD: {
    code: "AUDUSD",
    name: "Australian Dollar / US Dollar",
    short: "Aussie",
    kind: "fx",
    digits: 5,
    pip: 0.0001,
    priceRef: 0.662,
    range: { M5: 0.0007, M15: 0.0013, M30: 0.0021, H1: 0.0034, H4: 0.0075, D1: 0.014 },
    usdPerLotPerUnit: 100000,
    lotStep: 0.01,
    minLot: 0.01,
    spread: "0.8–1.5 pips",
    session: "Asia + London",
    note: "Aussie trends cleanly out of the Asia session but needs London to validate the break.",
  },
  USDCAD: {
    code: "USDCAD",
    name: "US Dollar / Canadian Dollar",
    short: "Loonie",
    kind: "fx",
    digits: 5,
    pip: 0.0001,
    priceRef: 1.372,
    range: { M5: 0.0008, M15: 0.0015, M30: 0.0023, H1: 0.0038, H4: 0.0085, D1: 0.016 },
    usdPerLotPerUnit: 72900,
    lotStep: 0.01,
    minLot: 0.01,
    spread: "1.0–1.8 pips",
    session: "New York",
    note: "Oil correlation and NY-session reversals are common. Wait for the retest.",
  },
  BTCUSD: {
    code: "BTCUSD",
    name: "Bitcoin / US Dollar",
    short: "Bitcoin",
    kind: "crypto",
    digits: 1,
    pip: 1,
    priceRef: 96000,
    range: { M5: 850, M15: 1600, M30: 2500, H1: 4200, H4: 9000, D1: 18000 },
    usdPerLotPerUnit: 1,
    lotStep: 0.01,
    minLot: 0.01,
    spread: "10–40 points",
    session: "24/7 — US equity hours carry volume",
    note: "Crypto ignores sessions but respects weekend liquidity voids. Size smaller than you think.",
  },
  US30: {
    code: "US30",
    name: "Dow Jones 30 Index",
    short: "Dow",
    kind: "index",
    digits: 1,
    pip: 1,
    priceRef: 43800,
    range: { M5: 120, M15: 220, M30: 340, H1: 580, H4: 1200, D1: 2400 },
    usdPerLotPerUnit: 1,
    lotStep: 0.1,
    minLot: 0.1,
    spread: "2–6 points",
    session: "New York cash session",
    note: "Index structure is driven by open-hour flows. The first hour is noise more often than signal.",
  },
  NAS100: {
    code: "NAS100",
    name: "Nasdaq 100 Index",
    short: "Nasdaq",
    kind: "index",
    digits: 1,
    pip: 1,
    priceRef: 20500,
    range: { M5: 95, M15: 170, M30: 260, H1: 460, H4: 950, D1: 1900 },
    usdPerLotPerUnit: 1,
    lotStep: 0.1,
    minLot: 0.1,
    spread: "1.5–4 points",
    session: "New York cash session",
    note: "Nasdaq rewards momentum continuation, punishes mean-reversion entries.",
  },
};

export const INSTRUMENT_LIST = Object.values(INSTRUMENTS);

export const TIMEFRAMES: { value: Timeframe; label: string; minutes: number }[] = [
  { value: "M5", label: "M5", minutes: 5 },
  { value: "M15", label: "M15", minutes: 15 },
  { value: "M30", label: "M30", minutes: 30 },
  { value: "H1", label: "H1", minutes: 60 },
  { value: "H4", label: "H4", minutes: 240 },
  { value: "D1", label: "D1", minutes: 1440 },
];

export const STYLE_LABELS = {
  scalp: "Scalp",
  intraday: "Intraday",
  swing: "Swing",
} as const;

export function getInstrument(code: string): InstrumentSpec {
  return INSTRUMENTS[code as InstrumentCode] ?? INSTRUMENTS.XAUUSD;
}

export function isInstrument(code: string): code is InstrumentCode {
  return code in INSTRUMENTS;
}

export function isTimeframe(value: string): value is Timeframe {
  return TIMEFRAMES.some((tf) => tf.value === value);
}

export function htfFor(timeframe: Timeframe): Timeframe {
  const map: Record<Timeframe, Timeframe> = {
    M5: "H1",
    M15: "H1",
    M30: "H4",
    H1: "H4",
    H4: "D1",
    D1: "D1",
  };
  return map[timeframe];
}

export function formatPrice(value: number, digits: number): string {
  return value.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export type InstrumentCode =
  | "XAUUSD"
  | "EURUSD"
  | "GBPUSD"
  | "USDJPY"
  | "GBPJPY"
  | "AUDUSD"
  | "USDCAD"
  | "BTCUSD"
  | "US30"
  | "NAS100";

export type Timeframe = "M5" | "M15" | "M30" | "H1" | "H4" | "D1";
export type TradingStyle = "scalp" | "intraday" | "swing";
export type Bias = "bullish" | "bearish" | "neutral";
export type Grade = "A+" | "A" | "B" | "C";
export type Outcome = "pending" | "tp1" | "tp2" | "tp3" | "sl" | "be" | "cancelled";
export type ChartSource = "image" | "sample" | "fallback";

export type NormalizedCandle = { o: number; h: number; l: number; c: number };

export type AnalyzerInputs = {
  instrument: InstrumentCode;
  timeframe: Timeframe;
  style: TradingStyle;
  accountSize: number;
  riskPercent: number;
  /** Current / last price on the chart. All normalized geometry is anchored here. */
  anchorPrice: number;
  /** Candle series in normalized price space (0 = bottom of the image, 1 = top). */
  candles: NormalizedCandle[];
  source: ChartSource;
  /** How confident the screenshot reader is about the extracted candles (0-100). */
  visionConfidence: number;
  visionNotes?: string[];
};

export type ZoneKind =
  | "resistance"
  | "support"
  | "liquidity-buy"
  | "liquidity-sell"
  | "fvg"
  | "entry"
  | "target"
  | "invalidation";

export type Zone = {
  kind: ZoneKind;
  label: string;
  low: number;
  high: number;
  note: string;
};

export type StructureData = {
  trendLabel: string;
  swingHigh: number;
  swingLow: number;
  prevSwingHigh: number;
  prevSwingLow: number;
  rangeHigh: number;
  rangeLow: number;
  midpoint: number;
  bosUp: boolean;
  bosDown: boolean;
  choch: boolean;
  equalHighs: boolean;
  equalLows: boolean;
  htfBias: Bias;
  htfTimeframe: Timeframe;
};

export type CheckItem = {
  label: string;
  state: "pass" | "warn" | "fail";
  note: string;
};

export type FinalSignal = {
  verdict: "execute" | "wait" | "stand-aside";
  action: "BUY" | "SELL" | "WAIT";
  orderType: string;
  headline: string;
  sentence: string;
  conditions: string[];
  confidence: number;
  grade: Grade;
};

export type RiskPlan = {
  accountSize: number;
  riskPercent: number;
  riskAmount: number;
  stopDistance: number;
  stopPips: number;
  lots: number;
  units: number;
  usdPerLotPerUnit: number;
  pipValuePerLot: number;
};

export type Narrative = {
  htf: string;
  structure: string;
  liquidity: string;
  candleRead: string;
  plan: string;
  management: string;
  invalidation: string;
  mentor: string;
};

export type AnalysisResult = {
  slug?: string;
  generatedAt: string;
  instrument: InstrumentCode;
  instrumentName: string;
  timeframe: Timeframe;
  style: TradingStyle;
  digits: number;
  pip: number;
  bias: Bias;
  grade: Grade;
  confidence: number;
  biasScore: number;
  setupModel: string;
  orderType: string;
  trigger: string;
  levels: {
    entry: number;
    entryZoneLow: number;
    entryZoneHigh: number;
    stop: number;
    tp1: number;
    tp2: number;
    tp3: number;
    rr1: number;
    rr2: number;
    rr3: number;
    recommendedRR: number;
  };
  risk: RiskPlan;
  structure: StructureData;
  zones: Zone[];
  chart: NormalizedCandle[];
  chartHigh: number;
  chartLow: number;
  vision: {
    source: ChartSource;
    confidence: number;
    candlesRead: number;
    bullRatio: number;
    notes: string[];
  };
  narrative: Narrative;
  checklist: CheckItem[];
  questions: string[];
  warnings: string[];
  session: { name: string; note: string; active: boolean; utcHour: number };
  finalSignal: FinalSignal;
  meta: {
    anchorPrice: number;
    rangePrice: number;
    trendStrength: number;
    volatilityLabel: string;
    equalHighsPrice?: number;
    equalLowsPrice?: number;
  };
};

export type SignalSummary = {
  slug: string;
  createdAt: string;
  instrument: InstrumentCode;
  timeframe: Timeframe;
  bias: Bias;
  grade: Grade;
  confidence: number;
  outcome: Outcome;
  outcomeR: number | null;
  authorName: string;
  views: number;
  entry: number;
  stop: number;
  tp1: number;
  tp2: number;
  tp3: number;
  rr: number;
  setupModel: string;
  verdict: string;
  sentence: string;
  headline: string;
};

export type StoredAnalysis = {
  id: number;
  slug: string;
  createdAt: string;
  instrument: InstrumentCode;
  timeframe: Timeframe;
  bias: Bias;
  grade: Grade;
  confidence: number;
  outcome: Outcome;
  outcomeR: number | null;
  authorName: string;
  isPublic: boolean;
  views: number;
  report: AnalysisResult;
};

"use client";

import { clamp, roundDecimals } from "./market";
import type { ChartSource, NormalizedCandle } from "./types";

export type VisionResult = {
  candles: NormalizedCandle[];
  confidence: number;
  notes: string[];
  width: number;
  height: number;
  bullPixels: number;
  bearPixels: number;
};

const MAX_WIDTH = 1600;

function classify(r: number, g: number, b: number): 1 | -1 | 0 {
  const mx = Math.max(r, g, b);
  const mn = Math.min(r, g, b);
  const d = mx - mn;
  if (mx < 45 || d < 20) return 0;
  let hue: number;
  if (mx === r) hue = ((g - b) / d) % 6;
  else if (mx === g) hue = (b - r) / d + 2;
  else hue = (r - g) / d + 4;
  hue *= 60;
  if (hue < 0) hue += 360;
  if (hue >= 75 && hue <= 190 && g >= 55 && d > 22) return 1;
  if ((hue >= 330 || hue <= 18) && r >= 60 && d > 28 && b < r * 0.88 && g < r * 0.92) return -1;
  return 0;
}

async function loadBitmap(file: Blob): Promise<ImageBitmap | HTMLImageElement> {
  if (typeof createImageBitmap === "function") {
    try {
      return await createImageBitmap(file);
    } catch {
      /* fall through */
    }
  }
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.decoding = "sync";
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error("The image could not be decoded."));
      img.src = url;
    });
    return img;
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }
}

/**
 * Reads candlestick geometry directly out of a chart screenshot using
 * colour classification + column clustering. Runs fully in the browser so
 * screenshots are never uploaded to a third party.
 */
export async function extractChartVision(file: Blob): Promise<VisionResult> {
  const bitmap = await loadBitmap(file);
  const srcWidth = "width" in bitmap ? bitmap.width : 0;
  const srcHeight = "height" in bitmap ? bitmap.height : 0;
  if (!srcWidth || !srcHeight) throw new Error("Empty image.");

  const scale = Math.min(1, MAX_WIDTH / srcWidth);
  const width = Math.max(1, Math.round(srcWidth * scale));
  const height = Math.max(1, Math.round(srcHeight * scale));

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas is not available in this browser.");
  ctx.drawImage(bitmap as CanvasImageSource, 0, 0, width, height);
  if ("close" in bitmap && typeof bitmap.close === "function") bitmap.close();

  const data = ctx.getImageData(0, 0, width, height).data;
  const labels = new Uint8Array(width * height);
  const colBull = new Uint32Array(width);
  const colBear = new Uint32Array(width);
  const colTop = new Int32Array(width).fill(height);
  const colBottom = new Int32Array(width).fill(-1);
  let bullPixels = 0;
  let bearPixels = 0;

  for (let y = 0; y < height; y += 1) {
    const rowOffset = y * width;
    const pixelRow = rowOffset * 4;
    for (let x = 0; x < width; x += 1) {
      const i = pixelRow + x * 4;
      if (data[i + 3] < 120) continue;
      const dir = classify(data[i], data[i + 1], data[i + 2]);
      if (dir === 0) continue;
      labels[rowOffset + x] = dir === 1 ? 1 : 2;
      if (dir === 1) {
        colBull[x] += 1;
        bullPixels += 1;
      } else {
        colBear[x] += 1;
        bearPixels += 1;
      }
      if (y < colTop[x]) colTop[x] = y;
      if (y > colBottom[x]) colBottom[x] = y;
    }
  }

  // Cluster active columns into candle candidates.
  const runs: { start: number; end: number }[] = [];
  let runStart = -1;
  let lastActive = -10;
  for (let x = 0; x < width; x += 1) {
    const active = colBull[x] + colBear[x] >= 2;
    if (active) {
      if (runStart < 0) runStart = x;
      lastActive = x;
    } else if (runStart >= 0 && x - lastActive > 3) {
      runs.push({ start: runStart, end: lastActive });
      runStart = -1;
    }
  }
  if (runStart >= 0) runs.push({ start: runStart, end: lastActive });

  const rawCandles: { x: number; candle: NormalizedCandle; pxWidth: number }[] = [];

  for (const run of runs) {
    const pxWidth = run.end - run.start + 1;
    if (pxWidth < 1 || pxWidth > Math.max(30, width * 0.03)) continue;

    let bull = 0;
    let bear = 0;
    for (let x = run.start; x <= run.end; x += 1) {
      bull += colBull[x];
      bear += colBear[x];
    }
    if (bull + bear < 6) continue;

    let top = height;
    let bottom = -1;
    for (let x = run.start; x <= run.end; x += 1) {
      if (colTop[x] < top) top = colTop[x];
      if (colBottom[x] > bottom) bottom = colBottom[x];
    }
    if (top < 0 || bottom <= top) continue;
    if (bottom - top < 3) continue;

    const rowCounts = new Uint32Array(bottom - top + 1);
    for (let y = top; y <= bottom; y += 1) {
      const rowOffset = y * width;
      let count = 0;
      for (let x = run.start; x <= run.end; x += 1) {
        if (labels[rowOffset + x] !== 0) count += 1;
      }
      rowCounts[y - top] = count;
    }

    const rowCountAt = (y: number) => rowCounts[y - top] ?? 0;

    const bodyThreshold = Math.max(2, Math.floor(pxWidth * 0.55));
    let bodyTop = -1;
    let bodyBottom = -1;
    for (let y = top; y <= bottom; y += 1) {
      if (rowCountAt(y) >= bodyThreshold) {
        if (bodyTop < 0) bodyTop = y;
        bodyBottom = y;
      }
    }
    if (bodyTop < 0) {
      for (let y = top; y <= bottom; y += 1) {
        if (rowCountAt(y) >= 2) {
          if (bodyTop < 0) bodyTop = y;
          bodyBottom = y;
        }
      }
    }
    if (bodyTop < 0) {
      bodyTop = top;
      bodyBottom = bottom;
    }

    const dir = bull >= bear ? 1 : -1;
    const priceOf = (y: number) => roundDecimals(clamp(1 - y / height, 0, 1), 4);
    const high = priceOf(top);
    const low = priceOf(bottom);
    const bodyUpper = priceOf(bodyTop);
    const bodyLower = priceOf(bodyBottom);
    const candle: NormalizedCandle =
      dir === 1
        ? { o: bodyLower, c: bodyUpper, h: high, l: low }
        : { o: bodyUpper, c: bodyLower, h: high, l: low };

    if (candle.h - candle.l <= 0.0005) continue;
    rawCandles.push({ x: (run.start + run.end) / 2, candle, pxWidth });
  }

  rawCandles.sort((a, b) => a.x - b.x);
  let candles = rawCandles.map((r) => r.candle);
  if (candles.length > 150) {
    const step = candles.length / 150;
    candles = Array.from({ length: 150 }, (_, i) => candles[Math.floor(i * step)]);
  }

  const widths = rawCandles.map((r) => r.pxWidth);
  const meanWidth = widths.reduce((a, b) => a + b, 0) / Math.max(widths.length, 1);
  const variance =
    widths.reduce((acc, w) => acc + (w - meanWidth) ** 2, 0) / Math.max(widths.length, 1);
  const cv = meanWidth > 0 ? Math.sqrt(variance) / meanWidth : 1;

  const notes: string[] = [];
  const coverage = (bullPixels + bearPixels) / (width * height);
  let confidence = 20;
  confidence += Math.min(34, candles.length * 0.85);
  confidence += Math.min(16, coverage * 900);
  confidence += cv < 0.35 ? 16 : cv < 0.7 ? 9 : cv < 1.1 ? 4 : 0;
  confidence += bullPixels > 0 && bearPixels > 0 ? 8 : 0;
  confidence += candles.length >= 15 ? 6 : 0;
  if (candles.length < 8) confidence = Math.min(confidence, 32);
  confidence = Math.round(clamp(confidence, 4, 95));

  if (candles.length === 0) {
    notes.push("No green/red candle pixels found. Use a standard candle theme, or crop away dark overlays and drawings.");
  } else {
    notes.push(`Read ${candles.length} candles from the screenshot (${Math.round(coverage * 1000) / 10}% coloured pixels).`);
    notes.push(`Bull/bear pixel balance: ${Math.round((bullPixels / Math.max(bullPixels + bearPixels, 1)) * 100)}% / ${Math.round((bearPixels / Math.max(bullPixels + bearPixels, 1)) * 100)}%.`);
    if (cv > 0.7) notes.push("Candle widths are inconsistent — indicator panes or drawings may be mixed into the read.");
    if (!(bullPixels > 0 && bearPixels > 0)) notes.push("Only one candle colour was detected — make sure both bullish and bearish candles are visible.");
  }

  return {
    candles,
    confidence,
    notes,
    width,
    height,
    bullPixels,
    bearPixels,
  };
}

/** Sample charts already carry clean OHLC data, so confidence is high. */
export function visionFromSeries(candles: NormalizedCandle[], source: ChartSource = "sample"): VisionResult {
  return {
    candles,
    confidence: source === "sample" ? 98 : 96,
    notes: [`${candles.length} candles loaded from a validated FXWizzy sample chart.`, "Geometry is exact — no pixel guessing required."],
    width: 0,
    height: 0,
    bullPixels: 0,
    bearPixels: 0,
  };
}

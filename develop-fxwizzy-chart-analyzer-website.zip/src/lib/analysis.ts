import {
  clamp,
  computeMetrics,
  makeSeries,
  readLastCandle,
  volatilityLabel,
  type ChartMetrics,
} from "./market";
import {
  formatPrice,
  getInstrument,
  htfFor,
  type InstrumentSpec,
} from "./instruments";
import type {
  AnalysisResult,
  AnalyzerInputs,
  Bias,
  CheckItem,
  ChartSource,
  Grade,
  NormalizedCandle,
  StructureData,
  Zone,
} from "./types";

/* ------------------------------------------------------------------ */
/* Input sanitation                                                   */
/* ------------------------------------------------------------------ */

const isNum = (n: unknown): n is number => typeof n === "number" && Number.isFinite(n);

function sanitizeCandles(raw: unknown): NormalizedCandle[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .slice(0, 400)
    .map((c) => {
      if (!c || typeof c !== "object") return null;
      const o = Number((c as NormalizedCandle).o);
      const h = Number((c as NormalizedCandle).h);
      const l = Number((c as NormalizedCandle).l);
      const cl = Number((c as NormalizedCandle).c);
      if (![o, h, l, cl].every(isNum)) return null;
      const safeOpen = clamp(o, -0.5, 1.5);
      const safeClose = clamp(cl, -0.5, 1.5);
      const safeHigh = Math.max(clamp(h, -0.5, 1.5), safeOpen, safeClose);
      const safeLow = Math.min(clamp(l, -0.5, 1.5), safeOpen, safeClose);
      return {
        o: safeOpen,
        h: safeHigh,
        l: safeLow,
        c: safeClose,
      };
    })
    .filter((c): c is NormalizedCandle => c !== null && c.h - c.l > 0.00001);
}

function hashString(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return Math.abs(hash);
}

/* ------------------------------------------------------------------ */
/* Planning                                                           */
/* ------------------------------------------------------------------ */

type RawPlan = {
  model: string;
  orderType: string;
  trigger: string;
  zoneLow: number;
  zoneHigh: number;
  entry: number;
  stop: number;
  tp1: number;
  tp2: number;
  tp3: number;
};

function tidyLevels(m: ChartMetrics, p: RawPlan): RawPlan {
  const extension = m.range * 0.75;
  const floor = m.rangeLow - extension;
  const ceiling = m.rangeHigh + extension;
  const zoneLow = clamp(p.zoneLow, floor, ceiling);
  const zoneHigh = clamp(p.zoneHigh, zoneLow + m.atr * 0.25, ceiling);
  const entry = clamp(p.entry, zoneLow, zoneHigh);
  const stop = clamp(p.stop, floor, ceiling);
  const risk = Math.abs(entry - stop);
  const dir = Math.sign(entry - stop) || 1;
  const tp1 = clamp(p.tp1, floor, ceiling);
  const tp2 = clamp(p.tp2, floor, ceiling);
  const tp3 = clamp(p.tp3, floor, ceiling);
  const ordered =
    dir > 0
      ? [
          Math.max(tp1, entry + risk * 1.05),
          Math.max(tp2, entry + risk * 1.9),
          Math.max(tp3, entry + risk * 2.8),
        ]
      : [
          Math.min(tp1, entry - risk * 1.05),
          Math.min(tp2, entry - risk * 1.9),
          Math.min(tp3, entry - risk * 2.8),
        ];
  return {
    ...p,
    zoneLow,
    zoneHigh,
    entry,
    stop,
    tp1: ordered[0],
    tp2: ordered[1],
    tp3: ordered[2],
  };
}

function bullishPlan(m: ChartMetrics, read: ReturnType<typeof readLastCandle>): RawPlan {
  const impulseLow = Math.min(m.structuralLow.price, m.lastSwingLow.price, m.rangeLow + m.range * 0.08);
  const impulseHigh = m.rangeHigh;
  const leg = Math.max(impulseHigh - impulseLow, m.atr * 2.2);
  const extended = m.closePos > 0.55;

  let zoneHigh: number;
  let zoneLow: number;
  let model: string;
  let orderType: string;
  let trigger: string;

  if (extended) {
    zoneHigh = impulseHigh - leg * 0.5;
    zoneLow = impulseHigh - leg * 0.79;
    if (m.lastClose < zoneHigh) {
      zoneHigh = m.lastClose + m.atr * 0.25;
      zoneLow = m.lastClose - m.atr * 0.35;
    }
    model = "Continuation — OTE discount retracement after BOS";
    orderType = "Buy Limit (pending)";
    trigger = "A lower-timeframe bullish close (engulfing or pin) inside the discount zone, with the higher-timeframe bias still up.";
  } else {
    zoneLow = m.lastClose - m.atr * 0.2;
    zoneHigh = m.lastClose + m.atr * 0.45;
    model = "Reclaim continuation from discount";
    orderType = read.pinBar || read.bullEngulf ? "Buy market / Buy Stop" : "Buy Stop above the confirmation candle";
    trigger = "Wait for the current candle to close bullish and take out the previous candle high before entering.";
  }

  const entry = (zoneLow + zoneHigh) / 2;
  let stop = Math.min(m.structuralLow.price, m.lastSwingLow.price) - m.atr * 0.35;
  if (entry - stop > m.range * 0.5) stop = Math.max(entry - m.range * 0.5, m.rangeLow - m.atr * 0.25);
  stop = Math.min(stop, entry - m.atr * 0.8);
  const risk = entry - stop;
  const target1 = Math.max(entry + risk * 1.05, Math.min(m.structuralHigh.price, m.rangeHigh));
  const target2 = Math.max(entry + risk * 2, m.rangeHigh);
  const target3 = Math.max(entry + risk * 3, m.rangeHigh + m.range * 0.25);

  return tidyLevels(m, {
    model,
    orderType,
    trigger,
    zoneLow,
    zoneHigh,
    entry,
    stop,
    tp1: target1,
    tp2: target2,
    tp3: target3,
  });
}

function bearishPlan(m: ChartMetrics, read: ReturnType<typeof readLastCandle>): RawPlan {
  const impulseHigh = Math.max(m.structuralHigh.price, m.lastSwingHigh.price, m.rangeHigh - m.range * 0.08);
  const impulseLow = m.rangeLow;
  const leg = Math.max(impulseHigh - impulseLow, m.atr * 2.2);
  const extended = m.closePos < 0.45;

  let zoneHigh: number;
  let zoneLow: number;
  let model: string;
  let orderType: string;
  let trigger: string;

  if (extended) {
    zoneLow = impulseLow + leg * 0.5;
    zoneHigh = impulseLow + leg * 0.79;
    if (m.lastClose > zoneLow) {
      zoneLow = m.lastClose - m.atr * 0.25;
      zoneHigh = m.lastClose + m.atr * 0.35;
    }
    model = "Continuation — premium OTE retracement after BOS";
    orderType = "Sell Limit (pending)";
    trigger = "A lower-timeframe bearish close (engulfing or pin) inside the premium zone while the higher-timeframe bias stays down.";
  } else {
    zoneHigh = m.lastClose + m.atr * 0.2;
    zoneLow = m.lastClose - m.atr * 0.45;
    model = "Rejection continuation from premium";
    orderType = read.pinBar || read.bearEngulf ? "Sell market / Sell Stop" : "Sell Stop below the confirmation candle";
    trigger = "Wait for the current candle to close bearish and break the previous candle low before entering.";
  }

  const entry = (zoneLow + zoneHigh) / 2;
  let stop = Math.max(m.structuralHigh.price, m.lastSwingHigh.price) + m.atr * 0.35;
  if (stop - entry > m.range * 0.5) stop = Math.min(entry + m.range * 0.5, m.rangeHigh + m.atr * 0.25);
  stop = Math.max(stop, entry + m.atr * 0.8);
  const risk = stop - entry;
  const target1 = Math.min(entry - risk * 1.05, Math.max(m.structuralLow.price, m.rangeLow));
  const target2 = Math.min(entry - risk * 2, m.rangeLow);
  const target3 = Math.min(entry - risk * 3, m.rangeLow - m.range * 0.25);

  return tidyLevels(m, {
    model,
    orderType,
    trigger,
    zoneLow,
    zoneHigh,
    entry,
    stop,
    tp1: target1,
    tp2: target2,
    tp3: target3,
  });
}

function rangePlan(m: ChartMetrics, bias: Bias, read: ReturnType<typeof readLastCandle>): RawPlan {
  const mid = (m.rangeHigh + m.rangeLow) / 2;
  const shortSide = bias === "bearish" || (bias === "neutral" && m.closePos > 0.5);
  const band = m.atr * 0.45;

  if (shortSide) {
    const zoneHigh = m.rangeHigh;
    const zoneLow = m.rangeHigh - m.atr * 0.9;
    const entry = (zoneHigh + zoneLow) / 2;
    const stop = zoneHigh + m.atr * 0.6;
    const risk = stop - entry;
    return tidyLevels(m, {
      model: "Range liquidity fade — sell the premium edge",
      orderType: read.pinBar || read.bearEngulf ? "Sell Limit" : "Wait for rejection, then sell",
      trigger: "Only sell after price sweeps the range high and closes back inside, or prints a bearish engulfing on the retest.",
      zoneLow,
      zoneHigh,
      entry,
      stop,
      tp1: Math.min(entry - risk * 1.05, mid + band),
      tp2: Math.min(entry - risk * 2, m.rangeLow + m.atr * 0.3),
      tp3: m.rangeLow - m.range * 0.15,
    });
  }

  const zoneLow = m.rangeLow;
  const zoneHigh = m.rangeLow + m.atr * 0.9;
  const entry = (zoneHigh + zoneLow) / 2;
  const stop = zoneLow - m.atr * 0.6;
  const risk = entry - stop;
  return tidyLevels(m, {
    model: "Range liquidity fade — buy the discount edge",
    orderType: read.pinBar || read.bullEngulf ? "Buy Limit" : "Wait for rejection, then buy",
    trigger: "Only buy after price sweeps the range low and closes back inside, or prints a bullish engulfing on the retest.",
    zoneLow,
    zoneHigh,
    entry,
    stop,
    tp1: Math.max(entry + risk * 1.05, mid - band),
    tp2: Math.max(entry + risk * 2, m.rangeHigh - m.atr * 0.3),
    tp3: m.rangeHigh + m.range * 0.15,
  });
}

function findFvg(candles: NormalizedCandle[]): { low: number; high: number; kind: "bullish" | "bearish" } | null {
  const end = candles.length - 1;
  const start = Math.max(2, end - 18);
  for (let i = end; i >= start; i -= 1) {
    const a = candles[i - 2];
    const c = candles[i];
    if (a.h < c.l && c.l - a.h > 0.0008) return { low: a.h, high: c.l, kind: "bullish" };
    if (a.l > c.h && a.l - c.h > 0.0008) return { low: c.h, high: a.l, kind: "bearish" };
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Main engine                                                        */
/* ------------------------------------------------------------------ */

export function analyzeChart(inputs: AnalyzerInputs): AnalysisResult {
  const spec: InstrumentSpec = getInstrument(inputs.instrument);
  const timeframe = inputs.timeframe;
  const style = inputs.style;

  let candles = sanitizeCandles(inputs.candles);
  let source: ChartSource = inputs.source === "sample" ? "sample" : "image";
  const notes: string[] = [...(inputs.visionNotes ?? [])].slice(0, 8);
  let visionConfidence = isNum(inputs.visionConfidence) ? clamp(inputs.visionConfidence, 0, 100) : 55;

  if (candles.length < 8) {
    source = "fallback";
    const seed = hashString(`${inputs.instrument}-${timeframe}-${Math.round(inputs.anchorPrice)}`);
    candles = makeSeries(seed, [
      { count: 18, drift: -0.0025, vol: 0.006 },
      { count: 12, drift: 0.0075, vol: 0.0062 },
      { count: 8, drift: -0.0055, vol: 0.0058 },
      { count: 16, drift: 0.0095, vol: 0.0068 },
    ], 0.34);
    visionConfidence = Math.min(visionConfidence, 34);
    notes.push("Chart reader could not isolate enough candles — showing a reference structure. Enter your live price and re-run.");
  }

  const m = computeMetrics(candles);
  const read = readLastCandle(candles);
  const accountSize = clamp(isNum(inputs.accountSize) ? inputs.accountSize : 1000, 10, 10_000_000);
  const riskPercent = clamp(isNum(inputs.riskPercent) ? inputs.riskPercent : 1, 0.05, 5);
  const anchorPrice = isNum(inputs.anchorPrice) && inputs.anchorPrice > 0 ? inputs.anchorPrice : spec.priceRef;
  const rangePrice = spec.range[timeframe];
  const anchorNorm = m.lastClose;

  const priceOf = (norm: number) => anchorPrice + (norm - anchorNorm) * rangePrice;
  const roundPrice = (value: number) => Number(value.toFixed(spec.digits));

  /* ---------------- bias & confidence ---------------- */
  const dirScore = (m.bullRatio - 0.5) * 2;
  const trendScore = clamp(m.totalTrend / (m.range * 0.6), -1, 1);
  const closeScore = (m.closePos - 0.5) * 2;
  const bosScore = m.bosUp ? 0.55 : m.bosDown ? -0.55 : 0;
  const chochScore = m.choch ? (m.bosDown ? -0.3 : 0.3) : 0;
  const biasScore = clamp(
    0.4 * trendScore + 0.24 * dirScore + 0.16 * closeScore + 0.22 * bosScore + chochScore,
    -1.4,
    1.4,
  );
  const bias: Bias = biasScore > 0.14 ? "bullish" : biasScore < -0.14 ? "bearish" : "neutral";

  let confidence =
    42 +
    Math.abs(biasScore) * 32 +
    (visionConfidence - 55) * 0.22 +
    (m.bosUp || m.bosDown ? 5 : 0) +
    (read.momentum ? 3 : 0) +
    (bias === "neutral" ? -9 : 3);
  if (riskPercent > 2) confidence -= 5;
  confidence = Math.round(clamp(confidence, 18, 95));

  const grade: Grade = confidence >= 82 ? "A+" : confidence >= 70 ? "A" : confidence >= 58 ? "B" : "C";

  /* ---------------- plan ---------------- */
  const rawPlan = bias === "bullish" ? bullishPlan(m, read) : bias === "bearish" ? bearishPlan(m, read) : rangePlan(m, bias, read);
  const priceCandles: NormalizedCandle[] = candles.map((c) => ({
    o: roundPrice(priceOf(c.o)),
    h: roundPrice(priceOf(c.h)),
    l: roundPrice(priceOf(c.l)),
    c: roundPrice(priceOf(c.c)),
  }));

  const entry = roundPrice(priceOf(rawPlan.entry));
  const rawStop = roundPrice(priceOf(rawPlan.stop));
  const isLong = rawPlan.entry > rawPlan.stop;
  // Never allow a stop that a normal spread/noise can take out.
  const minStopDistance = Math.max(rangePrice * 0.055, spec.pip * 4);
  const rawRiskDistance = Math.abs(entry - rawStop);
  const tightened = rawRiskDistance < minStopDistance;
  const stop = tightened
    ? roundPrice(isLong ? entry - minStopDistance : entry + minStopDistance)
    : rawStop;
  const entryZoneLow = roundPrice(priceOf(Math.min(rawPlan.zoneLow, rawPlan.zoneHigh)));
  const entryZoneHigh = roundPrice(priceOf(Math.max(rawPlan.zoneLow, rawPlan.zoneHigh)));
  const riskDistance = Math.abs(entry - stop);
  const priceTargets = tightened
    ? [1.15, 2.1, 3.2].map((multiple) => roundPrice(entry + (isLong ? 1 : -1) * riskDistance * multiple))
    : [rawPlan.tp1, rawPlan.tp2, rawPlan.tp3].map((tp) => roundPrice(priceOf(tp)));
  const [tp1, tp2, tp3] = priceTargets;
  const rr = (tp: number) => (riskDistance > 0 ? Math.abs(tp - entry) / riskDistance : 0);

  /* ---------------- risk ---------------- */
  const riskAmount = (accountSize * riskPercent) / 100;
  const rawLots =
    riskDistance > 0 ? riskAmount / (riskDistance * spec.usdPerLotPerUnit) : 0;
  const lotsRaw = Math.floor(rawLots / spec.lotStep) * spec.lotStep;
  const lots = Math.max(Number(lotsRaw.toFixed(2)), spec.minLot);
  const unitsPerLot = spec.kind === "gold" ? 100 : spec.kind === "fx" ? 100_000 : 1;
  const stopPips = riskDistance / spec.pip;

  /* ---------------- structure ---------------- */
  const htf = htfFor(timeframe);
  const structure: StructureData = {
    trendLabel: m.structureLabel,
    swingHigh: roundPrice(priceOf(m.lastSwingHigh.price)),
    swingLow: roundPrice(priceOf(m.lastSwingLow.price)),
    prevSwingHigh: roundPrice(priceOf(m.structuralHigh.price)),
    prevSwingLow: roundPrice(priceOf(m.structuralLow.price)),
    rangeHigh: roundPrice(priceOf(m.rangeHigh)),
    rangeLow: roundPrice(priceOf(m.rangeLow)),
    midpoint: roundPrice(priceOf((m.rangeHigh + m.rangeLow) / 2)),
    bosUp: m.bosUp,
    bosDown: m.bosDown,
    choch: m.choch,
    equalHighs: m.equalHighs,
    equalLows: m.equalLows,
    htfBias: m.htfBias,
    htfTimeframe: htf,
  };

  /* ---------------- zones ---------------- */
  const zones: Zone[] = [
    {
      kind: "resistance",
      label: "Range high / buy-side liquidity",
      low: roundPrice(priceOf(m.rangeHigh - m.atr * 0.2)),
      high: roundPrice(priceOf(m.rangeHigh + m.atr * 0.35)),
      note: "Stops of early sellers rest above this level. Expect a sweep or a rejection — not a clean walk-through.",
    },
    {
      kind: "support",
      label: "Range low / sell-side liquidity",
      low: roundPrice(priceOf(m.rangeLow - m.atr * 0.35)),
      high: roundPrice(priceOf(m.rangeLow + m.atr * 0.2)),
      note: "Stops of late buyers rest below. A sweep into this zone is fuel for the next expansion.",
    },
    {
      kind: m.bosUp ? "liquidity-buy" : "liquidity-sell",
      label: m.bosUp ? "Broken swing high — demand flip" : "Broken swing low — supply flip",
      low: roundPrice(priceOf((m.bosUp ? m.structuralHigh.price : m.structuralLow.price) - m.atr * 0.15)),
      high: roundPrice(priceOf((m.bosUp ? m.structuralHigh.price : m.structuralLow.price) + m.atr * 0.15)),
      note: "The last structural pivot. Holding on a retest keeps the continuation thesis alive.",
    },
    {
      kind: "entry",
      label: "Execution zone (limit area)",
      low: entryZoneLow,
      high: entryZoneHigh,
      note: rawPlan.trigger,
    },
    {
      kind: "target",
      label: "Primary liquidity target (TP2)",
      low: roundPrice(tp2 - spec.pip * 2),
      high: roundPrice(tp2 + spec.pip * 2),
      note: "Book the majority here unless momentum is expanding into a new range.",
    },
  ];

  const fvg = findFvg(candles);
  if (fvg) {
    zones.splice(3, 0, {
      kind: "fvg",
      label: `${fvg.kind === "bullish" ? "Bullish" : "Bearish"} fair value gap (imbalance)`,
      low: roundPrice(priceOf(fvg.low)),
      high: roundPrice(priceOf(fvg.high)),
      note: "Inefficiency left by displacement. Price usually revisits it before continuing.",
    });
  }

  /* ---------------- session ---------------- */
  const utcHour = new Date().getUTCHours();
  let sessionName = "New York close / Asia transition";
  let sessionActive = false;
  if (utcHour >= 0 && utcHour < 7) sessionName = "Asia session";
  else if (utcHour >= 7 && utcHour < 12) {
    sessionName = "London session";
    sessionActive = true;
  } else if (utcHour >= 12 && utcHour < 16) {
    sessionName = "London / New York overlap";
    sessionActive = true;
  } else if (utcHour >= 16 && utcHour < 21) {
    sessionName = "New York session";
    sessionActive = true;
  }
  const sessionNote = sessionActive
    ? `Active liquidity: ${sessionName}. ${spec.session} is where ${spec.name} delivers its cleanest expansion.`
    : `Thin liquidity: ${sessionName}. Spreads widen and false breaks increase — reduce size or wait for ${spec.session}.`;

  /* ---------------- checklist ---------------- */
  const structuralAligned = bias !== "neutral" && ((bias === "bullish" && !m.bosDown) || (bias === "bearish" && !m.bosUp));
  const rewardToTp2 = rr(tp2);
  const checklist: CheckItem[] = [
    {
      label: "Market structure aligned with bias",
      state: structuralAligned ? "pass" : bias === "neutral" ? "warn" : "fail",
      note: `Structure read: ${m.structureLabel}.`,
    },
    {
      label: "Price is on the correct side of the range",
      state:
        bias === "bullish"
          ? m.closePos < 0.85
            ? "pass"
            : "warn"
          : bias === "bearish"
            ? m.closePos > 0.15
              ? "pass"
              : "warn"
            : "warn",
      note: `Price sits at ${Math.round(m.closePos * 100)}% of the visible range (0% = range low, 100% = range high).`,
    },
    {
      label: "Liquidity swept before the entry",
      state: bias === "bullish" ? (m.equalLows || m.bosUp ? "pass" : "warn") : m.equalHighs || m.bosDown ? "pass" : "warn",
      note: m.equalHighs || m.equalLows
        ? "Equal highs/lows are visible — those pools are the draw on liquidity."
        : "No obvious stop cluster detected in the screenshot. Confirm on a higher timeframe.",
    },
    {
      label: "Candle confirmation at the level",
      state: read.bullEngulf || read.bearEngulf || read.pinBar ? "pass" : "warn",
      note: read.label,
    },
    {
      label: "Reward-to-risk to primary target ≥ 1:2",
      state: rewardToTp2 >= 2 ? "pass" : rewardToTp2 >= 1.5 ? "warn" : "fail",
      note: `TP2 pays 1:${rewardToTp2.toFixed(2)} from the planned entry.`,
    },
    {
      label: "Risk per trade within professional limits",
      state: riskPercent <= 1 ? "pass" : riskPercent <= 2 ? "warn" : "fail",
      note: `You are risking ${riskPercent.toFixed(2)}% (${riskAmount.toFixed(2)} USD) on this idea.`,
    },
    {
      label: "Screenshot read quality",
      state: visionConfidence >= 70 ? "pass" : visionConfidence >= 45 ? "warn" : "fail",
      note:
        source === "image"
          ? `Vision engine extracted ${candles.length} candles at ${Math.round(visionConfidence)}% confidence.`
          : "Using reference structure — verify levels against your live chart before executing.",
    },
    {
      label: "News window clear",
      state: "warn",
      note: "FXWizzy cannot see the economic calendar — check high-impact USD/gold events before entry.",
    },
  ];

  const fails = checklist.filter((item) => item.state === "fail").length;
  const warns = checklist.filter((item) => item.state === "warn").length;
  if (fails >= 2 || (grade === "C" && fails >= 1)) confidence = Math.max(15, confidence - 8);

  /* ---------------- final signal ---------------- */
  const verdict: "execute" | "wait" | "stand-aside" =
    bias === "neutral" || grade === "C" || confidence < 62 ? "wait" : confidence >= 70 && fails === 0 ? "execute" : "wait";
  const action: "BUY" | "SELL" | "WAIT" = verdict === "wait" ? "WAIT" : bias === "bullish" ? "BUY" : bias === "bearish" ? "SELL" : "WAIT";

  const directionWord = bias === "bullish" ? "long" : bias === "bearish" ? "short" : "neutral";
  const headline =
    verdict === "wait"
      ? `WAIT — no A-grade ${spec.name.split(" ")[0]} edge yet`
      : `${action} ${inputs.instrument} · ${timeframe} · ${grade} setup`;

  const sentence =
    verdict === "wait"
      ? bias === "neutral"
        ? `${inputs.instrument} is mid-range with no clean structure. Let price reach ${formatPrice(entryZoneLow, spec.digits)}–${formatPrice(entryZoneHigh, spec.digits)} and print a rejection before risking anything; invalidation stays at ${formatPrice(stop, spec.digits)}.`
        : `The ${directionWord} thesis is valid but the read is only ${confidence}% (${grade}). Do not market-execute: wait for price to tap ${formatPrice(entryZoneLow, spec.digits)}–${formatPrice(entryZoneHigh, spec.digits)}, print a confirmation candle, then risk no more than ${riskPercent.toFixed(2)}%. Invalidation ${formatPrice(stop, spec.digits)}.`
      : `${action} ${inputs.instrument} via ${rawPlan.model}. Entry ${formatPrice(entryZoneLow, spec.digits)}–${formatPrice(entryZoneHigh, spec.digits)}, hard invalidation ${formatPrice(stop, spec.digits)}, TP1 ${formatPrice(tp1, spec.digits)} (1:${rr(tp1).toFixed(1)}), TP2 ${formatPrice(tp2, spec.digits)} (1:${rr(tp2).toFixed(1)}), TP3 ${formatPrice(tp3, spec.digits)} (1:${rr(tp3).toFixed(1)}).`;

  const conditions = [
    rawPlan.trigger,
    `Higher-timeframe (${htf}) structure must not close against the idea before your entry fills.`,
    `Skip the trade if price closes beyond ${formatPrice(stop, spec.digits)} — no averaging, no wideners.`,
    `Take 50% at TP1, move to break-even, trail the rest behind ${timeframe} swing points toward TP2/TP3.`,
  ];

  /* ---------------- narrative ---------------- */
  const fmt = (v: number) => formatPrice(v, spec.digits);
  const narrative = {
    htf: `You gave me the ${timeframe} chart, so the ${htfFor(timeframe)} higher-timeframe read is inferred: ${structure.htfBias.toUpperCase()} and ${m.structureLabel.toLowerCase()}. ${
      structure.htfBias === bias
        ? "Alignment is clean — this is the condition that turns a decent setup into a good one."
        : structure.htfBias === "neutral"
          ? `The ${htf} is balanced, so treat this as a ${timeframe} trade only, not a swing position.`
          : `The ${htf} is leaning ${structure.htfBias}, against this ${timeframe} idea — demand extra confirmation or stand down.`
    }`,
    structure: `${m.bosUp ? `Price broke structure to the upside above ${fmt(structure.prevSwingHigh)}` : m.bosDown ? `Price broke structure to the downside below ${fmt(structure.prevSwingLow)}` : `Price is holding between ${fmt(structure.rangeLow)} and ${fmt(structure.rangeHigh)} with no accepted break yet`}. ${
      m.equalHighs ? `Equal highs sit near ${fmt(structure.swingHigh)} — buy-side liquidity is the magnet. ` : m.equalLows ? `Equal lows sit near ${fmt(structure.swingLow)} — sell-side liquidity is the magnet. ` : ""
    }${m.choch ? "A change of character (CHoCH) is printed, so the aggressive continuation trade is off; trade the retracement instead." : ""}`,
    liquidity: `Nearest draw on liquidity: ${bias === "bearish" ? `${fmt(structure.prevSwingLow)} then ${fmt(structure.rangeLow)}` : `${fmt(structure.prevSwingHigh)} then ${fmt(structure.rangeHigh)}`}. The visible range high (${fmt(structure.rangeHigh)}) and low (${fmt(structure.rangeLow)}) are the two pools of stops. ${
      fvg
        ? `There is an unfilled ${fvg.kind} imbalance at ${fmt(priceOf(Math.min(fvg.low, fvg.high)))}–${fmt(priceOf(Math.max(fvg.low, fvg.high)))} that price tends to revisit.`
        : "No clean fair value gap in the last 20 candles, so liquidity comes from swing points rather than imbalances."
    }`,
    candleRead: read.sentence,
    plan: `${rawPlan.model}. ${rawPlan.trigger} Entry ${fmt(entry)} (zone ${fmt(entryZoneLow)}–${fmt(entryZoneHigh)}), stop ${fmt(stop)} (${stopPips.toFixed(1)} ${spec.kind === "fx" ? "pips" : "points"}), targets ${fmt(tp1)} / ${fmt(tp2)} / ${fmt(tp3)}. ${spec.note}`,
    management: `Risk ${riskPercent.toFixed(2)}% = ${riskAmount.toFixed(2)} USD, position ${lots.toFixed(2)} lots ($${spec.usdPerLotPerUnit.toLocaleString("en-US")} per 1.00 price move, about $${(spec.pip * spec.usdPerLotPerUnit).toFixed(2)} per pip per lot). Take half at TP1, stop to break-even, then trail behind ${timeframe} swing highs/lows. If price sits inside the entry zone for more than three ${timeframe} candles without displacement, cancel the pending order.`,
    invalidation: `A ${timeframe} close beyond ${fmt(stop)} invalidates the idea. Re-entry is only valid after a fresh sweep and a new break of structure — never after a loss.`,
    mentor: `${grade === "A+" || grade === "A" ? "This is the type of chart I would put my own money behind" : "This is a B-grade read"}: ${bias === "neutral" ? "the market has not chosen a side, so protect your capital and let it show its hand." : `${bias} structure, ${m.closePos > 0.65 || m.closePos < 0.35 ? "an extended price location" : "price still offering a discount/premium entry"} and a ${rewardToTp2 >= 2 ? "healthy" : "thin"} ${rewardToTp2.toFixed(1)}R to the main target. `}${
      verdict === "execute"
        ? "Execute the plan, not the emotion."
        : "The best trade right now may be patience — wait for the trigger instead of donating to the spread."
    }`,
  };

  /* ---------------- warnings ---------------- */
  const warnings: string[] = [
    "No signal is 100% accurate. FXWizzy grades conviction and enforces risk; it does not predict the future. Use a hard stop on every trade.",
    "Chart reading from a screenshot is an approximation. Verify the levels against your broker's live price and spread.",
  ];
  if (source === "fallback") warnings.push("Candle extraction failed — this plan is based on reference structure. Re-shoot the screenshot with only the price panel visible (no indicators, no drawing toolbar).");
  if (source === "image" && visionConfidence < 65) warnings.push(`Vision confidence is only ${Math.round(visionConfidence)}%. Crop tighter around the candlesticks, use a standard green/red or teal/red candle theme, then re-run.`);
  if (visionConfidence >= 65 && source === "image") warnings.push(`Vision engine read ${candles.length} candles at ${Math.round(visionConfidence)}% confidence.`);
  if (riskPercent > 1) warnings.push(`Risking ${riskPercent.toFixed(2)}% per trade is above the 0.5–1% professional range. One losing streak can end an account.`);
  if (tightened) warnings.push(`The chart read gave an unusually tight invalidation, so it was widened to a minimum buffer of ${(minStopDistance / spec.pip).toFixed(1)} ${spec.kind === "fx" ? "pips" : "points"}. Targets were recalculated from the wider stop.`);
  if (!sessionActive) warnings.push(sessionNote);
  if (m.equalHighs || m.equalLows) warnings.push(`Equal ${m.equalHighs ? "highs" : "lows"} are engineered liquidity — expect a sweep of ${fmt(m.equalHighs ? structure.swingHigh : structure.swingLow)} before any real move.`);
  if (verdict === "wait") warnings.push("Final verdict is WAIT. Placing this now is a lower-probability trade; the levels are your trigger map, not an invitation.");

  /* ---------------- clarifying questions ---------------- */
  const questions = [
    `Can you also share the ${htf} chart? I inferred the higher-timeframe bias from this ${timeframe} image — one HTF screenshot locks it in properly.`,
    `Is price currently inside ${fmt(entryZoneLow)}–${fmt(entryZoneHigh)}, or are you planning ahead? It changes the order type between a pending limit and a market trigger.`,
    `What is your account currency and broker spread on ${inputs.instrument} right now? My ${lots.toFixed(2)} lot size assumes ${spec.spread} and $${spec.usdPerLotPerUnit.toLocaleString("en-US")}/lot per 1.00 move.`,
    spec.kind === "gold"
      ? "Are you trading the London/New York overlap? Gold in the Asian session produces false breaks more often than clean setups."
      : `Are you trading ${spec.session}? Session timing matters more than the pattern on ${spec.name}.`,
  ];

  const chartHigh = Math.max(...priceCandles.map((c) => c.h), tp3, entry, stop);
  const chartLow = Math.min(...priceCandles.map((c) => c.l), tp3, entry, stop);

  return {
    generatedAt: new Date().toISOString(),
    instrument: inputs.instrument,
    instrumentName: spec.name,
    timeframe,
    style,
    digits: spec.digits,
    pip: spec.pip,
    bias,
    grade,
    confidence,
    biasScore: Number(biasScore.toFixed(3)),
    setupModel: rawPlan.model,
    orderType: rawPlan.orderType,
    trigger: rawPlan.trigger,
    levels: {
      entry,
      entryZoneLow,
      entryZoneHigh,
      stop,
      tp1,
      tp2,
      tp3,
      rr1: Number(rr(tp1).toFixed(2)),
      rr2: Number(rr(tp2).toFixed(2)),
      rr3: Number(rr(tp3).toFixed(2)),
      recommendedRR: Number(rr(tp2).toFixed(2)),
    },
    risk: {
      accountSize,
      riskPercent,
      riskAmount: Number(riskAmount.toFixed(2)),
      stopDistance: Number(riskDistance.toFixed(spec.digits)),
      stopPips: Number(stopPips.toFixed(1)),
      lots: Number(lots.toFixed(2)),
      units: Math.round(lots * unitsPerLot),
      usdPerLotPerUnit: spec.usdPerLotPerUnit,
      pipValuePerLot: Number((spec.pip * spec.usdPerLotPerUnit).toFixed(2)),
    },
    structure,
    zones,
    chart: priceCandles.slice(-140),
    chartHigh,
    chartLow,
    vision: {
      source,
      confidence: Math.round(visionConfidence),
      candlesRead: candles.length,
      bullRatio: Number(m.bullRatio.toFixed(2)),
      notes: notes.slice(0, 6),
    },
    narrative,
    checklist,
    questions,
    warnings: warnings.slice(0, 8),
    session: { name: sessionName, note: sessionNote, active: sessionActive, utcHour },
    finalSignal: {
      verdict,
      action,
      orderType: rawPlan.orderType,
      headline,
      sentence,
      conditions,
      confidence,
      grade,
    },
    meta: {
      anchorPrice: roundPrice(anchorPrice),
      rangePrice,
      trendStrength: Number(trendScore.toFixed(2)),
      volatilityLabel: volatilityLabel(m.atr, m.range),
      equalHighsPrice: m.equalHighs ? structure.swingHigh : undefined,
      equalLowsPrice: m.equalLows ? structure.swingLow : undefined,
    },
  };
}

export const isLongTrade = (report: AnalysisResult) => report.levels.entry > report.levels.stop;

import { formatPrice, getInstrument } from "./instruments";
import type { AnalysisResult, Outcome, SignalSummary } from "./types";

export function planToText(report: AnalysisResult): string {
  const s = getInstrument(report.instrument);
  const f = (v: number) => formatPrice(v, report.digits);
  const dir = report.levels.entry > report.levels.stop ? "LONG" : "SHORT";
  const lines = [
    `FXWIZZY — ${report.finalSignal.action} ${report.instrument} · ${report.timeframe} (${dir})`,
    `Setup: ${report.setupModel}`,
    `Grade ${report.grade} · Confidence ${report.confidence}% · Verdict ${report.finalSignal.verdict.toUpperCase()}`,
    `Order type: ${report.orderType}`,
    `Entry: ${f(report.levels.entry)} (zone ${f(report.levels.entryZoneLow)} – ${f(report.levels.entryZoneHigh)})`,
    `Stop loss: ${f(report.levels.stop)} (${report.risk.stopPips} ${s.kind === "fx" ? "pips" : "points"} risk)`,
    `TP1: ${f(report.levels.tp1)} · 1:${report.levels.rr1.toFixed(2)} · take 50%`,
    `TP2: ${f(report.levels.tp2)} · 1:${report.levels.rr2.toFixed(2)} · take 30%`,
    `TP3: ${f(report.levels.tp3)} · 1:${report.levels.rr3.toFixed(2)} · runner`,
    `Risk: ${report.risk.riskPercent.toFixed(2)}% of ${report.risk.accountSize.toFixed(2)} = $${report.risk.riskAmount.toFixed(2)}`,
    `Position size: ${report.risk.lots.toFixed(2)} lots (${report.risk.units.toLocaleString("en-US")} units)`,
    "",
    `Trigger: ${report.trigger}`,
    `Invalidation: ${report.narrative.invalidation}`,
    "",
    "Educational analysis, not financial advice. Use a hard stop.",
  ];
  return lines.join("\n");
}

export function summaryToText(signal: SignalSummary): string {
  const digits = getInstrument(signal.instrument).digits;
  const f = (v: number) => formatPrice(v, digits);
  return [
    `FXWIZZY — ${signal.headline}`,
    `Entry ${f(signal.entry)} · SL ${f(signal.stop)} · TP1 ${f(signal.tp1)} · TP2 ${f(signal.tp2)} · TP3 ${f(signal.tp3)}`,
    `Grade ${signal.grade} · ${signal.confidence}% confidence · 1:${signal.rr.toFixed(2)} to TP2`,
    "Educational analysis, not financial advice.",
  ].join("\n");
}

export const OUTCOME_META: Record<Outcome, { label: string; className: string }> = {
  pending: { label: "In play", className: "border-gold/40 bg-gold/10 text-gold-soft" },
  tp1: { label: "TP1 hit", className: "border-mint/40 bg-mint/10 text-mint" },
  tp2: { label: "TP2 hit", className: "border-mint/40 bg-mint/10 text-mint" },
  tp3: { label: "TP3 hit", className: "border-mint/40 bg-mint/15 text-mint" },
  sl: { label: "Stopped", className: "border-rose/40 bg-rose/10 text-rose" },
  be: { label: "Break-even", className: "border-white/20 bg-white/5 text-cream/70" },
  cancelled: { label: "Cancelled", className: "border-white/20 bg-white/5 text-muted" },
};

export function biasMeta(bias: string) {
  if (bias === "bullish") return { label: "Bullish", className: "border-mint/40 bg-mint/10 text-mint" };
  if (bias === "bearish") return { label: "Bearish", className: "border-rose/40 bg-rose/10 text-rose" };
  return { label: "Neutral", className: "border-white/20 bg-white/5 text-cream/70" };
}

export function gradeMeta(grade: string) {
  if (grade === "A+") return "border-gold/60 bg-gold/15 text-gold";
  if (grade === "A") return "border-gold/40 bg-gold/10 text-gold-soft";
  if (grade === "B") return "border-white/25 bg-white/5 text-cream/80";
  return "border-rose/35 bg-rose/10 text-rose";
}

export function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  if (!Number.isFinite(then)) return "";
  const diff = Math.max(0, Date.now() - then);
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

import {
  boolean,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import type { AnalysisResult, Bias, Grade, InstrumentCode, Outcome, Timeframe } from "@/lib/types";

export const analyses = pgTable(
  "analyses",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull().unique(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    instrument: text("instrument").notNull().$type<InstrumentCode>(),
    timeframe: text("timeframe").notNull().$type<Timeframe>(),
    bias: text("bias").notNull().$type<Bias>(),
    grade: text("grade").notNull().$type<Grade>(),
    confidence: integer("confidence").notNull(),
    entry: doublePrecision("entry").notNull(),
    stop: doublePrecision("stop").notNull(),
    tp1: doublePrecision("tp1").notNull(),
    tp2: doublePrecision("tp2").notNull(),
    tp3: doublePrecision("tp3").notNull(),
    rr: doublePrecision("rr").notNull(),
    authorName: text("author_name").notNull().default("FXWizzy trader"),
    isPublic: boolean("is_public").notNull().default(true),
    outcome: text("outcome").notNull().default("pending").$type<Outcome>(),
    outcomeR: doublePrecision("outcome_r"),
    manageToken: text("manage_token").notNull(),
    views: integer("views").notNull().default(0),
    report: jsonb("report").notNull().$type<AnalysisResult>(),
  },
  (table) => [
    index("analyses_created_at_idx").on(table.createdAt),
    index("analyses_public_idx").on(table.isPublic),
  ],
);

export type AnalysisRow = typeof analyses.$inferSelect;
export type NewAnalysisRow = typeof analyses.$inferInsert;
